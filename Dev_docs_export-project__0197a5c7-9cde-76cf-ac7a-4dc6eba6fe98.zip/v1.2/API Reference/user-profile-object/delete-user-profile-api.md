---
title: "Delete User Profile API"
slug: "delete-user-profile-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon May 07 2018 01:11:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Sep 24 2020 11:02:47 GMT+0000 (Coordinated Universal Time)"
---
# Overview

This endpoint enables you to delete a user profile.

## Base URL

<https://location.api.clevertap.com/1/delete/profiles.json>

> 📘 Note
> 
> Use the URL based on your location:
> 
> - India - in1.api.clevertap.com
> - Singapore - sg1.api.clevertap.com
> - U.S - us1.api.clevertap.com

## HTTP Method

POST

## Headers

These headers are all required. The X-CleverTap-Account-Id and X-CleverTap-Passcode are used to authenticate the request. Please see the [authentication guide](doc:authentication) to see how to get their values.

| Header                 | Description                                             | Type   | Example Value                        |
| :--------------------- | :------------------------------------------------------ | :----- | :----------------------------------- |
| X-CleverTap-Account-Id | Your CleverTap Account ID.                              | string | "X-CleverTap-Account-Id: ACCOUNT_ID" |
| X-CleverTap-Passcode   | Your CleverTap Account Passcode.                        | string | "X-CleverTap-Passcode: PASSCODE"     |
| Content-Type           | Request content-type is always set to application/json. | string | "Content-Type: application/json"     |

## Body Parameters

The body is uploaded as a JSON payload. 

| Parameter | Description                          | Required | Type         | Example Value              |
| :-------- | :----------------------------------- | :------- | :----------- | :------------------------- |
| identity  | Custom user identity defined by you. | optional | string/array | ["client-19827239", "abc"] |
| guid      | CleverTap ID.                        | optional | string/array | ["ctid123", "ctid456"]     |

Below is an example payload.

```json
{
	"identity": ["client-19827239", "abc"]
}
OR
{
	"identity": "client-19827239"
}
OR 
{
	"guid": ["ctid123", "ctid456"]
}
OR
{
	"guid": "clientid123"
}
```

## Example Request

```curl
curl -X POST -d '{"guid":"df2e224d90874887b4d61153ef3a2508"}' "https://location.api.clevertap.com/1/delete/profiles.json" \
-H "X-CleverTap-Account-Id: ACCOUNT_ID" \
-H "X-CleverTap-Passcode: PASSCODE" \
-H "Content-Type: application/json; charset=utf-8"
```
```ruby
require 'net/http'
require 'uri'
require 'json'

uri = URI.parse("https://location.api.clevertap.com/1/delete/profiles.json")
request = Net::HTTP::Post.new(uri)
request.content_type = "application/json; charset=utf-8"
request["X-Clevertap-Account-Id"] = "ACCOUNT_ID"
request["X-Clevertap-Passcode"] = "PASSCODE"
request.body = JSON.dump({
  "guid" => "df2e224d90874887b4d61153ef3a2508"
})

req_options = {
  use_ssl: uri.scheme == "https",
}

response = Net::HTTP.start(uri.hostname, uri.port, req_options) do |http|
  http.request(request)
end
```
```python
import requests

headers = {
    'X-CleverTap-Account-Id': 'ACCOUNT_ID',
    'X-CleverTap-Passcode': 'PASSCODE',
    'Content-Type': 'application/json; charset=utf-8',
}

data = '{"guid":"df2e224d90874887b4d61153ef3a2508"}'

response = requests.post('https://location.api.clevertap.com/1/delete/profiles.json', headers=headers, data=data)
```
```php
<?php
include('vendor/rmccue/requests/library/Requests.php');
Requests::register_autoloader();
$headers = array(
    'X-CleverTap-Account-Id' => 'ACCOUNT_ID',
    'X-CleverTap-Passcode' => 'PASSCODE',
    'Content-Type' => 'application/json; charset=utf-8'
);
$data = '{"guid":"df2e224d90874887b4d61153ef3a2508"}';
$response = Requests::post('https://location.api.clevertap.com/1/delete/profiles.json', $headers, $data);
```
```javascript Node.js
var request = require('request');

var headers = {
    'X-CleverTap-Account-Id': 'ACCOUNT_ID',
    'X-CleverTap-Passcode': 'PASSCODE',
    'Content-Type': 'application/json; charset=utf-8'
};

var dataString = '{"guid":"df2e224d90874887b4d61153ef3a2508"}';

var options = {
    url: 'https://location.api.clevertap.com/1/delete/profiles.json',
    method: 'POST',
    headers: headers,
    body: dataString
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
        console.log(body);
    }
}

request(options, callback);
```
```go
type Payload struct {
	GUID string `json:"guid"`
}

data := Payload{
// fill struct
}
payloadBytes, err := json.Marshal(data)
if err != nil {
	// handle err
}
body := bytes.NewReader(payloadBytes)

req, err := http.NewRequest("POST", "https://location.api.clevertap.com/1/delete/profiles.json", body)
if err != nil {
	// handle err
}
req.Header.Set("X-Clevertap-Account-Id", "ACCOUNT_ID")
req.Header.Set("X-Clevertap-Passcode", "PASSCODE")
req.Header.Set("Content-Type", "application/json; charset=utf-8")

resp, err := http.DefaultClient.Do(req)
if err != nil {
	// handle err
}
defer resp.Body.Close()
```

## Example Response

```json
{
  "status": "success"
}
```
