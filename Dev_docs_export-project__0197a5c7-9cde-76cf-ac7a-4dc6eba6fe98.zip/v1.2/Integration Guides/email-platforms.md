---
title: "Email Platforms"
slug: "email-platforms"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Sep 03 2018 05:49:30 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Sep 03 2018 06:01:10 GMT+0000 (Coordinated Universal Time)"
---
To send our emails to your users, you are required to use your own email provider. This keeps your sender reputation intact, and virtually guarantees better delivery rates. 

CleverTap supports integrations with popular transactional email service providers including:

- [Amazon Simple Email Service](doc:amazon-simple-email-service) 
- [SendGrid](doc:sendgrid) 
- [Postmark](doc:postmark) 
- [Mandrill](doc:mandrill) 
- [Gmail/Google Apps](https://docs.clevertap.com/docs/gmail-google-apps) 
- [Generic SMTP](doc:generic-smtp)
