---
title: "Setting Native Display in Android"
slug: "native-display"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Dec 03 2019 14:35:39 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Nov 18 2020 22:55:46 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://developer.clevertap.com/docs/android#section-setting-native-display-in-android"
---
