---
title: "Set the Small Notification Icon"
slug: "set-the-small-notification-icon"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Nov 18 2020 22:06:39 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Nov 18 2020 22:06:39 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://developer.clevertap.com/docs/android#section-set-the-small-notification-icon"
---
