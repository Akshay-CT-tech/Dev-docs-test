---
title: "Custom Android Push Notifications Handling"
slug: "custom-android-push-notifications-handling"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Feb 02 2018 21:09:34 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Nov 18 2020 22:45:16 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://developer.clevertap.com/docs/android#section-custom-android-push-notifications-handling"
---
