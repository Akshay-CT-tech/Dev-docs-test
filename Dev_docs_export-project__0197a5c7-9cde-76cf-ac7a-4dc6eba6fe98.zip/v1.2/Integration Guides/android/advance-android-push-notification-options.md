---
title: "Advanced Android Push Notifications Option"
slug: "advance-android-push-notification-options"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Feb 02 2018 21:09:56 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Nov 18 2020 22:54:53 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://developer.clevertap.com/docs/android#section-advanced-android-push-notification-options"
---
