---
title: "Find Your FCM Sender ID & FCM Server API Key"
slug: "find-your-fcm-sender-id-fcm-server-api-key"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 30 2018 23:14:58 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Apr 21 2020 16:45:28 GMT+0000 (Coordinated Universal Time)"
---
Firebase Cloud Messaging is service that allows you to send notifications to your applications and receive information from them. Your FCM Sender ID and API key authenticate against CleverTap allowing you to send notifications to your users from CleverTap.

To find your Sender ID and API key you have to:

- Login to the [Firebase Developer Console](https://console.firebase.google.com/) and go to your Dashboard
- Click on the “gear” icon and access “project settings” 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1a609d8-FCM_Project_Settings.png",
        "FCM_Project_Settings.png",
        1281
      ],
      "border": true
    }
  ]
}
[/block]


- Go to the “Cloud Messaging Section” and you will have access to the sender ID and the API Key. 

![](https://files.readme.io/e724e93-FCM_Server_Key.png "FCM_Server_Key.png")
