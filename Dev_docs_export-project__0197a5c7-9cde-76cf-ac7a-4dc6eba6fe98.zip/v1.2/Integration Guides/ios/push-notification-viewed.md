---
title: "Push Impressions"
slug: "push-notification-viewed"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue May 21 2019 12:25:28 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Mar 12 2020 10:36:06 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://developer.clevertap.com/docs/ios#section-push-impressions"
---
