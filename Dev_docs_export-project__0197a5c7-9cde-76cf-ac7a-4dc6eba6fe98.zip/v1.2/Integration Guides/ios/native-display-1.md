---
title: "Setting Native Display in iOS"
slug: "native-display-1"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Dec 03 2019 14:36:54 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Nov 24 2020 20:00:34 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://developer.clevertap.com/docs/ios#section-setting-native-display-in-i-os"
---
