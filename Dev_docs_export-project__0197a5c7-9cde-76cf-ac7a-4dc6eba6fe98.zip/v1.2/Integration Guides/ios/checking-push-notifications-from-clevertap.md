---
title: "Checking Push Notifications from CleverTap"
slug: "checking-push-notifications-from-clevertap"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Feb 02 2018 21:18:10 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Mar 23 2020 07:03:23 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://developer.clevertap.com/docs/ios#section-checking-push-notifications-from-clever-tap"
---
