---
title: "App Inbox"
slug: "app-inbox"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Jan 14 2019 10:30:16 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Dec 06 2019 14:43:16 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://developer.clevertap.com/v1.0/docs/ios#section-app-inbox"
---
