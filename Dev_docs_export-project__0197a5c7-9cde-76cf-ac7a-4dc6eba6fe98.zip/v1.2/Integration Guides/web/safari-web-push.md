---
title: "Safari Web Push"
slug: "safari-web-push"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Aug 24 2020 10:27:55 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Aug 24 2020 10:27:55 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://developer.clevertap.com/docs/web#section-safari-web-push"
link_external: true
---
