---
title: "Attribution Platforms"
slug: "attribution"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 09 2018 23:25:56 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Oct 15 2020 13:55:01 GMT+0000 (Coordinated Universal Time)"
---
CleverTap can help you track your app installs, measure attribution with third party sources, and view reports in the CleverTap Dashboard. 

CleverTap supports integrations with popular third-party attribution providers including:

- [Adjust](doc:adjust)
- [AppsFlyer](doc:appsflyer)
- [Branch](doc:branch)
- [Tune](doc:tune)
