---
title: "AppsFlyer"
slug: "appsflyer"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jan 12 2018 11:15:58 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Dec 01 2020 05:07:56 GMT+0000 (Coordinated Universal Time)"
---
CleverTap helps to track your app installs via AppsFlyer. This integration requires changes to both your Android and iOS app for a successful integration:

# Step 1: Add CleverTap Credentials to AppsFlyer Dashboard

On your AppsFlyer dashboard, select _Integrated Partners_ and search for CleverTap. 

Enter your _Account Details_ such as CleverTap _Account ID,_ _Account Passcode_, and _Account Token_(available in the CleverTap Settings dashboard). 

![](https://files.readme.io/02e5c32-Screen-Shot-2017-04-07-at-3.26.40-PM.png "Screen-Shot-2017-04-07-at-3.26.40-PM.png")

Check Enable and Save. All AppsFlyer parameters will now be sent to CleverTap.

# Step 2: Integration

**Android App**  
In your Android app, open the file where you have added your AppsFlyer integration. Add the following code below it.

If you haven't already integrated AppsFlyer, you will first need to follow [this guide](https://support.appsflyer.com/hc/en-us/articles/207032126-AppsFlyer-SDK-Integration-Android).

```java
String attributionID = cleverTapInstance.getCleverTapAttributionIdentifier();
appsFlyerLib.setCustomerUserId(attributionID);
```

**iOS App**  
In your iOS app code, add the following code:

```objectivec
[CleverTap autoIntegrate];
[[AppsFlyerTracker sharedTracker] setCustomerUserID:[[CleverTap sharedInstance] profileGetCleverTapAttributionIdentifier]];
```

**React-Native App**  
In your React-Native App, add the following code:

```javascript
CleverTap.profileGetCleverTapAttributionIdentifier((err, res) => { 

const userId = res;

appsFlyer.setCustomerUserId(userId, (response) => {   

//.. });

});
```

# Step 3: View Data in Dashboard

After you integrate, AppsFlyer will push data into your CleverTap dashboard. You can view it under event UTM Visited filtered by event property, UTM_source, UTM_medium or UTM_campaign.

> 📘 Note:
> 
> CleverTap accepts only non-organic installs from Appsflyer.
