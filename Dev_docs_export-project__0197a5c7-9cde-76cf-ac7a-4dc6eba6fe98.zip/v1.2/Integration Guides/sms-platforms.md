---
title: "SMS Platforms"
slug: "sms-platforms"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Sep 03 2018 05:59:41 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Dec 06 2019 14:43:16 GMT+0000 (Coordinated Universal Time)"
---
CleverTap supports sending SMS to your users through many popular SMS service providers:

- [Twilio](doc:twilio) 
- [Exotel](doc:exotel) 
- [Netcore](doc:netcore) 
- [MSG91](doc:msg91) 
- [TextLocal](doc:textlocal) 
- [Nimbus SMS](doc:nimbus-sms) 
- [Plivo](doc:plivo) 
- [BulkSMS](doc:bulksms) 
- [SMSINDIAHUB](doc:smsindiahub) 

This guide shows how to do a [generic SMS](doc:generic-sms) integration.
