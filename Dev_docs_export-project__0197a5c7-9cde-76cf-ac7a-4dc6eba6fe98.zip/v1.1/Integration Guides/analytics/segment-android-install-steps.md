---
title: "Segment - Android Install Steps"
slug: "segment-android-install-steps"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Sat Feb 03 2018 00:05:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 25 2025 06:30:12 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://github.com/CleverTap/clevertap-segment-android"
---
CleverTap helps you to track your app installs via AppsFlyer. This integration requires changes to both your Android and iOS app for a successful integration:

CleverTap/Segment Android Integration  
[CleverTap/Segment Android Integration GitHub repo](https://github.com/CleverTap/clevertap-segment-android)  
CleverTap/Segment iOS Integration  
[CleverTap/Segment iOS Integration GitHub repo](https://github.com/CleverTap/clevertap-segment-ios)
