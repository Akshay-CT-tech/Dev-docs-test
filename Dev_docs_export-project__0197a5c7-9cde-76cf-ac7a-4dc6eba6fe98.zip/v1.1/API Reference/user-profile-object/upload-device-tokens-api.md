---
title: "Upload Device Tokens API"
slug: "upload-device-tokens-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 09 2018 16:34:52 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 25 2025 06:30:12 GMT+0000 (Coordinated Universal Time)"
---
The Upload Device Tokens API enables developers to add an existing device token to a CleverTap user profile. 

For example, you can use this API to add a GCM or APNS token to a user profile. Adding this information will let you send push notifications to that device. 

# Overview

Uploading device tokens to CleverTap requires a POST request with a JSON payload specifying the device token information. 100 device token records can be sent per API call. 

## Base URL

<https://api.clevertap.com/1/upload>

## HTTP Method

POST

## Headers

These headers are all required. The X-CleverTap-Account-Id and X-CleverTap-Passcode are used to authenticate the request. Please see the [authentication guide](doc:authentication) to see how to get their values.

| Header                 | Description                                                            | Type   | Example Value                                   |
| :--------------------- | :--------------------------------------------------------------------- | :----- | :---------------------------------------------- |
| X-CleverTap-Account-Id | Your CleverTap Account ID.                                             | string | "X-CleverTap-Account-Id: ACCOUNT_ID"            |
| X-CleverTap-Passcode   | Your CleverTap Account Passcode.                                       | string | "X-CleverTap-Passcode: PASSCODE"                |
| Content-Type           | Request content-type is always set to application/json; charset=utf-8. | string | "Content-Type: application/json; charset=utf-8" |

## Body Parameters

Device tokens are uploaded as a JSON payload. The payload is an object keyed with “d” whose value is an array describing the device tokens.

For each device token, objectId is required. objectId is CleverTap’s user identifier, which we will use to find the user and add the device token to their profile.

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Description",
    "h-2": "Type",
    "h-3": "Example Value",
    "0-0": "type",
    "0-1": "Set to token. Required.",
    "0-2": "string",
    "0-3": "“token”",
    "1-0": "tokenData",
    "1-1": "Device token properties. Passed as key/value pairs. Required.  \nId and type are required properties of tokenData. They are passed as strings.",
    "1-2": "object",
    "1-3": "{  \n    \"d\": [  \n                {  \n            \"type\": \"token\",  \n            \"tokenData\": {  \n                \"id\": \"dYfuuBmHLGI:APA91bEfAq1b6NAmz0uhUbVxwSLqgKF25zDb7vhgajzS-bOAEUKekH_jbzO5oU1Qip-ZLvDpwKccxAxVNjC3rUUJnFTKDUiBcF9AtuG03_PRfjoUxLKHMR9qykK22SiubrLirNzQtNnO\",  \n                \"type\": \"fcm\"  \n            },  \n            \"objectId\": \"__gc4grg4053N1eYkW6OBH71jhFev7b1iP\"  \n        },  \n        {  \n            \"type\": \"token\",  \n            \"tokenData\": {  \n                \"id\": \"frfsgvrwe:APfdsafsgdfsgghfgfgjkhfsfgdhjhbvcvnetry767456fxsasdf\",  \n                \"type\": \"gcm\"  \n            }  \n    ]  \n}",
    "2-0": "objectId",
    "2-1": "Identify a unique user by CleverTap Global Object ID.  \nYou have to set a value for one of these parameters to identify the user: identity, FBID, GPID, or objectId.",
    "2-2": "string",
    "2-3": "“34322425\""
  },
  "cols": 4,
  "rows": 3,
  "align": [
    "left",
    "left",
    "left",
    "left"
  ]
}
[/block]


Here is an example JSON payload for iOS/Android/Windows.

```json
{
    "d": [
        {
            "type": "token",
            "tokenData": {
                "id": <Device Token>,
                "type": apns/gcm/fcm/wns/mpns
            },
            "objectId": <ClevertapId/GUID>
        }
    ]
}
```

Here is an example JSON payload for Chrome.

```json
{
    "type": "token",
    "tokenData": {
        "id": <DeviceToken>,
        "type": "chrome",
        "keys": {
            "p256dh": <>,
            "auth": <>
        }
    },
    "objectId": <ClevertapId/GUID>
}
```

Here is an example JSON payload for adding device tokens for multiple OS types.

```json
{
    "d": [
        {
            "type": "token",
            "tokenData": {
                "id": "frfsgvrwe:APfdsafsgdfsgghfgfgjkhfsfgdhjhbvcvnetry767456fxsasdf",
                "type": "chrome",
                "keys": {
                    "p256dh": "BLc4xRzKlKORKWlbdgFaBrrPK3ydWAHo4M0gs0i1oEKgPpWC5cW8OCzVrOQRv-1npXRWk8udnW3oYhIO4475rds=",
                    "auth": "5I2Bu2oKdyy9CwL8QVF0NQ=="
                }
            },
            "objectId": "QBOpVJZmKilRAzfaiVS86Tovxm75lHxg"
        },
        {
            "type": "token",
            "tokenData": {
                "id": "dYfuuBmHLGI:APA91bEfAq1b6NAmz0uhUbVxwSLqgKF25zDb7vhgajzS-bOAEUKekH_jbzO5oU1Qip-ZLvDpwKccxAxVNjC3rUUJnFTKDUiBcF9AtuG03_PRfjoUxLKHMR9qykK22SiubrLirNzQtNnO",
                "type": "fcm"
            },
            "objectId": "__gc4grg4053N1eYkW6OBH71jhFev7b1iP"
        },
        {
            "type": "token",
            "tokenData": {
                "id": "frfsgvrwe:APfdsafsgdfsgghfgfgjkhfsfgdhjhbvcvnetry767456fxsasdf",
                "type": "gcm"
            },
            "objectId": "__QlXHaDHBZxZPLEMpPo6VvwdZ7FnbGvWA"
        },
        {
            "type": "token",
            "tokenData": {
                "id": "frfsgvrwe:APfdsafsgdfsgghfgfgjkhfsfgdhjhbvcvnetry767456fxsasdf",
                "type": "apns"
            },
            "objectId": "-HwB9gZWb3RcKhXCQ222FhAhkjeYQs0Hj"
        },
        {
            "type": "token",
            "tokenData": {
                "id": "frfsgvrwe:APfdsafsgdfsgghfgfgjkhfsfgdhjhbvcvnetry767456fxsasdf",
                "type": "wns"
            },
            "objectId": "~9XrS4Dy6GsnDbdX98Ijs63kEtJDQbhJA"
        },
        {
            "type": "token",
            "tokenData": {
                "id": "frfsgvrwe:APfdsafsgdfsgghfgfgjkhfsfgdhjhbvcvnetry767456fxsasdf",
                "type": "mpns"
            },
            "objectId": "~y9MqjkDGRfbzwwH8fZI6LIXgTKaEPxHr"
        }
    ]
}
```

## Example Request

```curl
curl -X POST -d '{"d": [{"type": "token","tokenData": {"id": "dYfuuBmHLGI:APA91bEfAq1b6NAmz0uhUbVxwSLqgKF25zDb7vhgajzS-bOAEUKekH_jbzO5oU1Qip-ZLvDpwKccxAxVNjC3rUUJnFTKDUiBcF9AtuG03_PRfjoUxLKHMR9qykK22SiubrLirNzQtNnO","type": "gcm"},"objectId": "37b08803c1af4e10849f530264bac7f8"}]}' "https://api.clevertap.com/1/upload" \
-H "X-CleverTap-Account-Id: ACCOUNT_ID" \
-H "X-CleverTap-Passcode: PASSCODE" \
-H "Content-Type: application/json; charset=utf-8"
```

## Example Response

```json
{
    "status": "success",
    "processed": 1,
    "unprocessed": []
}
```

## Debugging

Requests with processing errors will be returned in the API call response as shown in the example below.

```json
{
    "status":<success, partial, fail>, 
    "processed":<count>, 
    "unprocessed": [{"status":"fail", "code":<error code>, "error":<error msg>, "record":<record>}]
}
```

To test if your data will be submitted without errors, you can add the parameter dryRun=1 to the URL. This will validate the input without submitting the data to CleverTap.  
A list of errors code for this API can be found on the [errors page](doc:api-errors).

## Notes

- A device token can be updated against a CleverTap Id (objectId), but not against an email ID or a custom-defined user identity. If given profile already has a token, it will not be updated and an error will be reported into Live Error Stream.
- Concurrent requests are limited to 3 per account. Requests that exceed the limit will return a 429 HTTP response code.

# Next Steps

Now that you’ve learned how to import device tokens with the CleverTap API, learn how to use the [Counts API]\(link to the Counts API page] to get aggregate metrics for specific event types.
