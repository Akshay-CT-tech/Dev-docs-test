---
title: "Delete User Profile API"
slug: "delete-user-profile-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon May 07 2018 01:11:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 25 2025 06:30:12 GMT+0000 (Coordinated Universal Time)"
---
# Overview

This endpoint enables you to delete a user profile.

## Base URL

<http://eu1.wzrkt.com/1/delete/profiles.json>

## HTTP Method

POST

## Headers

These headers are all required. The X-CleverTap-Account-Id and X-CleverTap-Passcode are used to authenticate the request. Please see the [authentication guide](doc:authentication) to see how to get their values.

| Header                 | Description                                             | Type   | Example Value                        |
| :--------------------- | :------------------------------------------------------ | :----- | :----------------------------------- |
| X-CleverTap-Account-Id | Your CleverTap Account ID.                              | string | "X-CleverTap-Account-Id: ACCOUNT_ID" |
| X-CleverTap-Passcode   | Your CleverTap Account Passcode.                        | string | "X-CleverTap-Passcode: PASSCODE"     |
| Content-Type           | Request content-type is always set to application/json. | string | "Content-Type: application/json"     |

## Body Parameters

The body is uploaded as a JSON payload. 

| Parameter | Description                          | Required | Type   | Example Value                      |
| :-------- | :----------------------------------- | :------- | :----- | :--------------------------------- |
| identity  | Custom user identity defined by you. | optional | string | “5555555555”                       |
| objectId  | CleverTap ID.                        | optional | string | “1a063854f83a4c6484285039ecff87cb” |

Below is an example payload.

```json
{
    "guid":"df2e224d90874887b4d61153ef3a2508"
}
```

## Example Response

```json
{
  "status": "success",
  "count": 7138
}
```
