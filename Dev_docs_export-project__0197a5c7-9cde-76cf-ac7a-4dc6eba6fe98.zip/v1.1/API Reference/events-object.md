---
title: "Event API Endpoints"
slug: "events-object"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 09 2018 16:47:50 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 25 2025 06:30:12 GMT+0000 (Coordinated Universal Time)"
---
Events represent the actions users take with your product. Examples are standard events like app launches and custom events you define like product views. 

Here are the API endpoints available to interact with the event object:

- [Get Events API](doc:get-events-api)  
  The Get Events API lets you download user events from CleverTap. For example, you can use this API to get a list of Purchase events in the past week.
- [Upload Events API](doc:upload-events-api)  
  The Upload Events API enables you to upload user events from external systems to CleverTap. You can use this API to store user events, such as phone calls and purchases. Storing user events in CleverTap enables you to create richer segments and run targeted campaigns.  
- [Get Event Count API](doc:get-event-count-api)  
  This Get Event Count lets you get a count of a specific event that occured during a time period you define.
