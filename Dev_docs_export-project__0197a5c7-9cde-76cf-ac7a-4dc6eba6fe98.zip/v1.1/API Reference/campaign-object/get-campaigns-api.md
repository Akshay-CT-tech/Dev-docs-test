---
title: "Get Campaigns API"
slug: "get-campaigns-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Sat Mar 24 2018 01:08:00 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 25 2025 06:30:12 GMT+0000 (Coordinated Universal Time)"
---
# Overview

The Get Campaigns API lets you get a list of campaigns created using the API.

# Base URL

<https://api.clevertap.com/1/targets/list.json>

# HTTP Method

POST

# Headers

These headers are all required. The X-CleverTap-Account-Id and X-CleverTap-Passcode are used to authenticate the request. Please see the [authentication guide](doc:authentication) to see how to get their values.

| Header                 | Description                                             | Type   | Example Value                        |
| :--------------------- | :------------------------------------------------------ | :----- | :----------------------------------- |
| X-CleverTap-Account-Id | Your CleverTap Account ID.                              | string | "X-CleverTap-Account-Id: ACCOUNT_ID" |
| X-CleverTap-Passcode   | Your CleverTap Account Passcode.                        | string | "X-CleverTap-Passcode: PASSCODE"     |
| Content-Type           | Request content-type is always set to application/json. | string | "Content-Type: application/json"     |

# Body Parameters

The body is uploaded as a JSON payload.

| Parameter | Description                                                                | Type | Example Value |
| :-------- | :------------------------------------------------------------------------- | :--- | :------------ |
| from      | Start of date range for events needed. Value specified in format YYYYMMDD. | int  | 20171201      |
| to        | End of date range for events needed. Value specified in format YYYYMMDD.   | int  | 20171225      |

Below is an example payload.

```json
{
    "from": 20160101,
    "to": 20160101
}
```

# Example Request

```curl
curl -X POST -d '{"from": 20160101,"to": 20160101}' "https://api.clevertap.com/1/targets/list.json" \
-H "X-CleverTap-Account-Id: ACCOUNT_ID" \
-H "X-CleverTap-Passcode: PASSCODE" \
-H "Content-Type: application/json"
```

# Example Response

```json
{
    "status": "success",
    "targets": [
        {
            "id": 1457429935,
            "name": "My API Campaign",
            "scheduled_on": 201703081508,
            "status": "pending"
        },
        {
            "id": 1457432766,
            "name": "My API Campaign 2",
            "scheduled_on": 201603081556,
            "status": "completed"
        }
    ]
}
```
