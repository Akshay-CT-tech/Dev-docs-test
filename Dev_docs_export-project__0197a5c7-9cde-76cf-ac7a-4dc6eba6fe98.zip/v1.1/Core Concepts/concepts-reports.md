---
title: "Reports"
slug: "concepts-reports"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Feb 06 2018 01:30:24 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 25 2025 06:30:12 GMT+0000 (Coordinated Universal Time)"
---
# Overview

CleverTap provides aggregate metrics for users, events, and campaigns. You can use these metrics to analyze your user engagement and guide product decisions. 

You can use our Reports feature through the [CleverTap dashboard](https://docs.clevertap.com/docs/intro-to-reports) or through the [Report API Endpoints](doc:report-object).
