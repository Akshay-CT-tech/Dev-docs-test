---
title: "User Data Policy for Google Play Store"
slug: "google-play-user-data-policy"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Mar 07 2018 04:49:14 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Dec 06 2019 14:43:16 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://clevertap.com/blog/update-on-googleplay-store-privacy-requirements/"
---
