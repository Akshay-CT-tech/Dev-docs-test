---
title: "Customer Data Platforms"
slug: "customer-data-platforms"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 09 2018 23:29:09 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 16 2020 14:31:31 GMT+0000 (Coordinated Universal Time)"
---
CleverTap integrates with Customer Data Platforms, so you can send your user data to any system.

- [Segment](doc:segment)
- [Segment - Android Install](doc:segment-android-install)
- [Segment - iOS Install](doc:segment-ios-install)
- [mParticle](doc:mparticle)
