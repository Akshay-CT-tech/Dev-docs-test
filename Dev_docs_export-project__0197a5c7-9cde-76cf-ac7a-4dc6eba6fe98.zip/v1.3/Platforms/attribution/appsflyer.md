---
title: "AppsFlyer"
slug: "appsflyer"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jan 12 2018 11:15:58 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jul 15 2021 12:09:33 GMT+0000 (Coordinated Universal Time)"
---
CleverTap helps to track your app installs via AppsFlyer. This integration requires changes to both your Android and iOS app for successful integration:

# Step 1: Add CleverTap Credentials to AppsFlyer Dashboard

On your AppsFlyer dashboard, select _Integrated Partners_ and search for CleverTap. 

Enter your _Account Details_ such as CleverTap _Account ID,_ _Account Passcode_, and _Account Token_(available in the CleverTap Settings dashboard). 

![](https://files.readme.io/02e5c32-Screen-Shot-2017-04-07-at-3.26.40-PM.png "Screen-Shot-2017-04-07-at-3.26.40-PM.png")

Check Enable and Save. All AppsFlyer parameters will now be sent to CleverTap.

# Step 2: Integration

**Android App**  
If you haven't already integrated AppsFlyer, you will first need to follow [this guide](https://support.appsflyer.com/hc/en-us/articles/207032126-AppsFlyer-SDK-Integration-Android).

In your Android app, open the file where you have added your AppsFlyer integration. Add the following code below it.

## SDK version 4.2.0 and above

The `getCleverTapAttributionIdentifier` method is deprecated for CleverTap Android SDKs version 4.2.0 and above. Use the new `getCleverTapID` method to get the CleverTap ID on the `OnInitCleverTapIDListener` to set `CustomerUserId` method of AppsFlyer.

```java
cleverTapInstance.getCleverTapID(new OnInitCleverTapIDListener() {
   @Override
   public void onInitCleverTapID(final String cleverTapID) {
       // Callback on main thread
       appsFlyerLib.setCustomerUserId(cleverTapID);
   }   
});
```
```kotlin
cleverTapInstance?.getCleverTapID {
  // Callback on main thread
  appsFlyerLib.setCustomerUserId(it)
}
```

## SDK version 4.1.1 and below

```java
String attributionID = cleverTapInstance.getCleverTapAttributionIdentifier();
appsFlyerLib.setCustomerUserId(attributionID);
```
```kotlin
appsFlyerLib.setCustomerUserId(cleverTapInstance?.cleverTapAttributionIdentifier)
```

**iOS App**  
In your iOS app code, add the following code:

```objectivec
[CleverTap autoIntegrate];
[[AppsFlyerTracker sharedTracker] setCustomerUserID:[[CleverTap sharedInstance] profileGetCleverTapAttributionIdentifier]];
```

**React-Native App**  
In your React-Native App, add the following code:

```javascript
CleverTap.profileGetCleverTapAttributionIdentifier((err, res) => { 

const userId = res;

appsFlyer.setCustomerUserId(userId, (response) => {   

//.. });

});
```

# Step 3: View Data in Dashboard

After you integrate, AppsFlyer will push data into your CleverTap dashboard. You can view it under event UTM Visited filtered by event property, UTM_source, UTM_medium or UTM_campaign.

> 📘 Note:
> 
> CleverTap accepts only non-organic installs from Appsflyer.
