---
title: "How to Create an Apple Push Notification Service Certificate"
slug: "how-to-create-an-ios-apns-certificate"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Jan 31 2018 00:22:47 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sat Feb 06 2021 00:58:35 GMT+0000 (Coordinated Universal Time)"
---
## Overview

Apple Push Notification service (APNs) is a platform notification service that enables third-party application developers to send notification data to applications installed on Apple devices. iOS applications that use APNs need to have a certificate. This section explains how to generate an APNs certificate for your application.

# Create a Certificate Signing Request (CSR) from Keychain

1. On your MAC open _Keychain Access_ and navigate to _Certificate Assistant_.
2. Select _Request a Certificate From a Certificate Authority_.

![](https://files.readme.io/217563c-cer1.png "cer1.png")

Selecting this option directs you to the _Certificate Assistant_.

3. Select _Request is_ > _Saved to Disk_ and leave the email address blank as shown below.

![](https://files.readme.io/00bef1c-cer2.png "cer2.png")

4. Click **Continue** to save the file. 

## Download an APNs Certificate from Your Account

1. Log in to [developer.apple.com](https://developer.apple.com/), and navigate to the _Member Center_ and select_ Certificates, Identifiers & Profiles_.

![](https://files.readme.io/a68a27e-cer3.png "cer3.png")

![](https://files.readme.io/b2d368f-cer4.png "cer4.png")

2. Select _Certificates_ under _iOS Apps_.

![](https://files.readme.io/3ac9f6b-cer5.png "cer5.png")

3. Select _Development/Production_ under certificates.
4. Click **+** to add a certificate.

![](https://files.readme.io/eb674e5-cer6.png "cer6.png")

5. Select _Apple Push Notification service SSL (Sandbox)_.
6. Click **Continue** and select the _Application ID_ for which you want to create the certificate.
7. Upload the CSR file created on the first step and download the certificate you generated.

## Convert the .cer File to a .p12 Certificate

1. Open the .cer file you downloaded; it will open _Keychain Access_.

![](https://files.readme.io/cb1478e-cer7.png "cer7.png")

2. Select your certificate, right-click, and export your certificate in a .p12 format.
