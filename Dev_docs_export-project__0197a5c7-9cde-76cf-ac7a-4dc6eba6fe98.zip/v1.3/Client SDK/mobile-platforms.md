---
title: "Additional Mobile Platform"
slug: "mobile-platforms"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 09 2018 23:34:24 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri May 07 2021 17:10:56 GMT+0000 (Coordinated Universal Time)"
---
## Overview

CleverTap provides [SDKs](doc:clevertap-sdks) that enables app developers to track, segment, and engage their users. 

Learn how to integrate the CleverTap SDK into your app with [KaiOS](https://developer.clevertap.com/docs/kaios).
