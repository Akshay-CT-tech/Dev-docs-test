---
title: "Android SDK Quick Start Guide"
slug: "android-quickstart-guide"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 09 2018 15:15:12 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jul 15 2021 12:17:20 GMT+0000 (Coordinated Universal Time)"
---
## Overview

This section shows how to install the CleverTap SDK, track your first user event, and see this information within the CleverTap dashboard in less than ten minutes. CleverTap provides an Android SDK that enables app developers to track, segment, and engage their users. 

# Install SDK

To use the CleverTap Android SDK, you have two options. You can install it automatically using Gradle in Android Studio or manually install it by including the SDK source code in your Android Studio project. 

## Option A: Install using Android Studio and Gradle (Recommended) 

CleverTap supports Firebase Cloud Messaging (FCM). 

1. For FCM, add the dependencies below in your application’s build.gradle file. You will also have to add the FCM generated google-services.json file to your project. 

```groovy
dependencies {
    implementation 'com.clevertap.android:clevertap-android-sdk:4.2.0'
    implementation 'com.google.firebase:firebase-messaging:20.2.4'
		implementation 'androidx.core:core:1.3.0'
  //Mandatory for CleverTap Android SDK v3.6.4 and above add the following -
		implementation 'com.android.installreferrer:installreferrer:2.1'
}
// at the end of the build.gradle file
apply plugin: 'com.google.gms.google-services'
```

2. Add the following configuration to your gradle properties file. 

```groovy
android.useAndroidX=true
```

3. Once you have updated your build.gradle file, sync your project by clicking on Sync Project With Gradle Files button. You can find this button by navigating to the _Tools_ menu, then the Android sub-menu.

![](https://files.readme.io/001ca2d-image3.png "image3.png")

## Option B: Manual Install

For a manual install, follow these steps:

1. [Download](https://github.com/CleverTap/clevertap-android-sdk/releases/download/core-v4.2.0/clevertap-android-sdk-4.2.0.aar) this AAR file.
2. Copy the AAR file to the `/libs` directory of your project.
3. Add it as a dependency to your project.

# Add Your CleverTap Credentials in AndroidManifest.xml

To associate your Android app with your CleverTap account, you need to add your CleverTap credentials in the AndroidManifest.xml file in your application.

1. Navigate to the AndroidManifest.xml file in your project navigator. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/be3caa0-android-2018-1.png",
        "android-2018-1.png",
        1027
      ],
      "border": true
    }
  ]
}
[/block]


2. Add your CleverTap Account ID and Token to your AndroidManifest.xml within the <application></application> tags.

```xml
<meta-data
    android:name="CLEVERTAP_ACCOUNT_ID"
    android:value="Your CleverTap Account ID"/>
<meta-data
    android:name="CLEVERTAP_TOKEN"
    android:value="Your CleverTap Account Token"/>
<!-- IMPORTANT: To force use Google AD ID to uniquely identify  users, use the following meta tag. GDPR mandates that if you are using this tag, there is prominent disclousure to your end customer in their application. Read more about GDPR here - https://clevertap.com/blog/in-preparation-of-gdpr-compliance/ -->
<meta-data
    android:name="CLEVERTAP_USE_GOOGLE_AD_ID"
    android:value="1"/>
```

> 🚧 Using Google AD ID to uniquely identify users
> 
> GDPR mandates that if you are using Google AD ID to uniquely identify users, there should be prominent disclosure in your application that explains this to your end customer. For more information, refer to this [GDPR article](https://clevertap.com/blog/in-preparation-of-gdpr-compliance/). 
> 
> Note: If you still want to use Google AD ID to generate a user's identity, so that you can identify users across re-installs, add the meta tag that forces the use of the Google AD ID to generate an identity in CleverTap.

3. Insert the account ID and account token values from your CleverTap account. These values are available on the _Settings_ page at the bottom left-hand corner of your dashboard. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d1467d9-2.png",
        "2.png",
        1449
      ],
      "sizing": "80",
      "border": true
    }
  ]
}
[/block]


# Enable Tracking by Adding Permissions

To enable tracking by adding permissions with the following steps:

1. In your AndroidManifest.xml file, add the following snippet within the <application></application> tags.

```xml
<application
    android:label="@string/app_name"
    android:icon="@drawable/ic_launcher"
    android:name="com.clevertap.android.sdk.Application">
```

![](https://files.readme.io/319c1ad-image6.png "image6.png")

2. Next, add the snippet below in the same file, so the CleverTap SDK can access the internet.

```xml
<!-- Required to allow the app to send events and user profile information -->
<uses-permission android:name="android.permission.INTERNET"/>
<!-- Recommended so that CleverTap knows when to attempt a network call -->
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
```

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/da53966-image2.png",
        "image2.png",
        935
      ],
      "border": true
    }
  ]
}
[/block]


> 🚧 Custom Application Class
> 
> If you have a custom application class, call ActivityLifecycleCallback.register(this); before super.onCreate() in your class.

# Initialize the CleverTap SDK

In the onCreate() method of your application’s main activity, include the code below. This code initializes the CleverTap SDK.

```java JAVA
CleverTapAPI clevertapDefaultInstance = CleverTapAPI.getDefaultInstance(getApplicationContext());
```
```kotlin Kotlin
var cleverTapDefaultInstance: CleverTapAPI? = null
cleverTapDefaultInstance = CleverTapAPI.getDefaultInstance(applicationContext)
```

# Run Your Application

To build and run your application, follow these steps:

1. Navigate to your CleverTap dashboard > _Boards_ > _Mobile App_. If you successfully integrated the CleverTap SDK, you will see a new active user.

![](https://files.readme.io/9e07e5a-New_mobile_users.png "New mobile users.png")

# Identify Users

A user profile is automatically created in CleverTap for each user launching your application.

Initially, the user profile starts out as anonymous which means the profile does not contain any identifiable information about the user. You can enrich the profile with pre-defined attributes from the CleverTap data model, such as name and email. You can also add custom attributes that you define to extend the CleverTap data model.

Sending user profile information to CleverTap using our Android SDK requires two steps:

1. You have to build a HashMap with the profile properties. 
2. You have to call the SDK's `OnUserLogin` method and pass the HashMap you created as a parameter. 

```java JAVA
// each of the below mentioned fields are optional
HashMap<String, Object> profileUpdate = new HashMap<String, Object>();
profileUpdate.put("Name", "Jack Montana");    // String
profileUpdate.put("Identity", 61026032);      // String or number
profileUpdate.put("Email", "jack@gmail.com"); // Email address of the user
profileUpdate.put("Phone", "+14155551234");   // Phone (with the country code, starting with +)
profileUpdate.put("Gender", "M");             // Can be either M or F
profileUpdate.put("DOB", new Date());         // Date of Birth. Set the Date object to the appropriate value first
// optional fields. controls whether the user will be sent email, push etc.
profileUpdate.put("MSG-email", false);        // Disable email notifications
profileUpdate.put("MSG-push", true);          // Enable push notifications
profileUpdate.put("MSG-sms", false);          // Disable SMS notifications
profileUpdate.put("MSG-whatsapp", true);      // Enable WhatsApp notifications
ArrayList<String> stuff = new ArrayList<String>();
stuff.add("bag");
stuff.add("shoes");
profileUpdate.put("MyStuff", stuff);                        //ArrayList of Strings
String[] otherStuff = {"Jeans","Perfume"};
profileUpdate.put("MyStuff", otherStuff);                   //String Array
CleverTapAPI.getInstance(getApplicationContext()).onUserLogin(profileUpdate);
```
```kotlin Kotlin
// each of the below mentioned fields are optional
val profileUpdate = HashMap<String, Any>()
profileUpdate["Name"] = "Jack Montana" // String
profileUpdate["Identity"] = 61026032 // String or number
profileUpdate["Email"] = "jack@gmail.com" // Email address of the user
profileUpdate["Phone"] = "+14155551234" // Phone (with the country code, starting with +)
profileUpdate["Gender"] = "M" // Can be either M or F
profileUpdate["DOB"] = Date() // Date of Birth. Set the Date object to the appropriate value first
// optional fields. controls whether the user will be sent email, push etc.
// optional fields. controls whether the user will be sent email, push etc.
profileUpdate["MSG-email"] = false // Disable email notifications
profileUpdate["MSG-push"] = true // Enable push notifications
profileUpdate["MSG-sms"] = false // Disable SMS notifications
profileUpdate["MSG-whatsapp"] = true // Enable WhatsApp notifications
val stuff = ArrayList<String>()
stuff.add("bag")
stuff.add("shoes")
profileUpdate["MyStuff"] = stuff //ArrayList of Strings
val otherStuff = arrayOf("Jeans", "Perfume")
profileUpdate["MyStuff"] = otherStuff //String Array
CleverTapAPI.getDefaultInstance(applicationContext)?.onUserLogin(profileUpdate)
```

When the `OnUserLogin` method is called, the user profile information will be sent to CleverTap.

To see how this information displays within the CleverTap dashboard, perform the following:

1. Navigate to _Segments_ > _Find People_.
2. In the _By Identity_ box, enter the email you set on the user profile record, then click the **Find** button.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f0467dc-1_By_identity_search_box.png",
        "1 By identity search box.png",
        1407
      ],
      "border": true
    }
  ]
}
[/block]


If CleverTap finds a user profile with this email, you will be taken to that user record. On that page, you will see the name and email as pre-defined fields, and _Customer type_ and _Age_ as custom fields.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c635bdd-2_User_Profile.png",
        "2_User_Profile.png",
        2912
      ],
      "border": true
    }
  ]
}
[/block]


# Track Custom Events

Once you integrate the CleverTap SDK, we automatically start tracking events, such as _App Launch_ and _Notification Viewed_. In addition to the [default events tracked by CleverTap](https://developer.clevertap.com/docs/concepts-events), you can also track custom events.

To send custom events to CleverTap using our Android SDK, you have to call the pushEvent method with the name of the custom event you want to track. 

```java JAVA
clevertapDefaultInstance.pushEvent("Product viewed");
```
```kotlin Kotlin
clevertapDefaultInstance?.pushEvent("Product viewed")
```

To take a look at the same user profile in CleverTap from the last section, click on the **Activity** button within the user profile record. This shows a list of activities associated with the user profile. 

If the custom event was successfully sent from your application to CleverTap, you will see it in this list.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1a8aecb-3_User_Activities.png",
        "3_User_Activities.png",
        2756
      ],
      "border": true
    }
  ]
}
[/block]


# Next Steps 

By completing this guide, you are automatically tracking user events like app launches, and associating that information with profiles for each of your users. You also learned how to add information to a user profile and how to track custom events. You now have integrated CleverTap into your Android application

In the [next Android guide](doc:android), you will learn more advanced options for tracking custom events and enriching user profiles.
