---
title: "Geofencing"
slug: "geofencing"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Aug 27 2020 16:18:48 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Sep 02 2020 15:22:33 GMT+0000 (Coordinated Universal Time)"
---
CleverTap offers geofencing which is a location-based service that customers can use to engage their audience by sending relevant messages to [Android](https://developer.clevertap.com/docs/geofence-android) and [iOS](https://developer.clevertap.com/docs/geofence-ios) users who enter or exit a pre-defined location or geographic area.
