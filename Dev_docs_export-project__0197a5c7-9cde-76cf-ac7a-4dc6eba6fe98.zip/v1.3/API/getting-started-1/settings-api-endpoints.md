---
title: "Settings API Endpoints"
slug: "settings-api-endpoints"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Aug 19 2020 14:47:09 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Aug 19 2020 14:47:09 GMT+0000 (Coordinated Universal Time)"
---
These endpoints allow you to both fetch data about dashboard settings and also allow you to setup/update existing dashboard settings

# Subscription Groups

You can use this API to get the list of all subscription groups created on the dashboard

### Base Method

<https://api.clevertap.com/category-groups>

### HTTP Method

GET

### Headers

These headers are all required. The X-CleverTap-Account-Id and X-CleverTap-Passcode are used to authenticate the request. Please see the [authentication guide](doc:authentication) to see how to get their values.

| Header                 | Description                                             | Type   | Example Value                        |
| :--------------------- | :------------------------------------------------------ | :----- | :----------------------------------- |
| X-CleverTap-Account-Id | Your CleverTap Account ID.                              | String | "X-CleverTap-Account-Id: ACCOUNT_ID" |
| X-CleverTap-Passcode   | Your CleverTap Account Passcode.                        | String | "X-CleverTap-Passcode: PASSCODE"     |
| Content-Type           | Request content-type is always set to application/json. | String | "Content-Type: application/json"     |

### Example Response

```json
//response will be in the below format
{
   "list": [
       {
           "name": "Newsletter",
           "key": 1,
           "description": "Newslettter",
           "channels": [
               "Email"
           ],
           "updated_on": 1597812749,
           "created_on": 1597812749
       },
       {
           "name": "Product Updates",
           "key": 2,
           "description": "Product Updates",
           "channels": [
               "Email"
           ],
           "updated_on": 1597826038,
           "created_on": 1597826038
       }
   ],
   "status": "success"
}
```
