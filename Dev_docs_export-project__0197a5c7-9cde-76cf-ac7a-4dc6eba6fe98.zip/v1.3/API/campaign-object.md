---
title: "Campaign API"
slug: "campaign-object"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 09 2018 16:48:38 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sat Feb 20 2021 00:00:25 GMT+0000 (Coordinated Universal Time)"
---
CleverTap campaigns enable you to communicate with your users at scale. For example, you can set up a campaign to send a push notification with a discount code to users who have viewed a certain product.

Here are the API endpoints available to interact with the campaign object:

- [Create Campaign API](doc:create-campaign-api)  
  The Create Campaign API lets you create campaigns in CleverTap. For example, you can use this endpoint to send a push notification to a specific set of users based on their past behaviour in the app. You can also target your campaigns based on segments that match user profile properties you define. 
- [Stop Campaign API](doc:stop-campaign-api)  
  The Stop Campaign API enables you to stop scheduled/running campaigns. 
- [Get Campaign Report API](doc:get-campaign-report-api)  
  The Get Campaign Report API lets you get performance metrics about a specific campaign.
- [Get Campaigns API](doc:get-campaigns-api)  
  The Get Campaigns API lets you get a list of campaigns created using the API.
