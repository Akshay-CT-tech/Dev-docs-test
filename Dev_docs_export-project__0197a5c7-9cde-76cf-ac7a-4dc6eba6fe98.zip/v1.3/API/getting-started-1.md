---
title: "Getting Started"
slug: "getting-started-1"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Feb 19 2021 23:51:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sat Feb 20 2021 00:13:15 GMT+0000 (Coordinated Universal Time)"
---
## Overview

To get started with APIs, explore the following sections:

- [API Overview](https://developer.clevertap.com/docs/api-overview)
- [API Quick Start Guide](https://developer.clevertap.com/docs/api-quickstart-guide)
- [Event API](https://developer.clevertap.com/docs/events-object)
- [Profile API](https://developer.clevertap.com/docs/user-profile-object)
- [Campaign API](https://developer.clevertap.com/docs/campaign-object)
- [Report API](https://developer.clevertap.com/docs/report-object)
