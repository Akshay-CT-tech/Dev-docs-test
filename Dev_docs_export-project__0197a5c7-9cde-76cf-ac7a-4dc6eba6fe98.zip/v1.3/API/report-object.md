---
title: "Report API"
slug: "report-object"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 09 2018 16:51:46 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sat Feb 20 2021 00:00:33 GMT+0000 (Coordinated Universal Time)"
---
CleverTap provides aggregate metrics for users, events, and campaigns. You can use these metrics to analyze your user engagement and guide product decisions. CleverTap customers often use the endpoints below to include users, events, and campaigns metrics into an internal dashboard, so they get an entire view of all the systems they are using. 

Here are the API endpoints available to interact with the report object:

- [Get Message Reports API](doc:get-message-reports-api)  
  The Get Message Reports API lets you download a list of messages sent by CleverTap. For example, you can this API to get a report of how many in-app messages and push notifications were sent to users in the past week. 
- [Real-Time Counts API](doc:real-time-counts-api)  
  The Real-Time Counts API can be used to get a real-time count of active users in the past five minutes including information about those users, such as UTM source.
- [Top Property Counts API](doc:top-property-counts-api)  
  The Top Property Counts API lets you get counts for the most and least frequently occurring properties for a particular event in a specified duration.
- [Trends API](doc:trends-api)  
  The Trends API lets you get a daily, weekly, and monthly event trends in a specified duration.
