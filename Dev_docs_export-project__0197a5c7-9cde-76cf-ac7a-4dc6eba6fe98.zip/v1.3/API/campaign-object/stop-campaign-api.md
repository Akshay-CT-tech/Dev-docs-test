---
title: "Stop Scheduled Campaign API"
slug: "stop-campaign-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 09 2018 16:43:09 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Feb 05 2019 08:16:24 GMT+0000 (Coordinated Universal Time)"
---
# Overview

The Stop Scheduled Campaign API lets you stop a scheduled/running campaign.

## Base URL

<https://api.clevertap.com/1/targets/stop.json>

## HTTP Method

POST

## Headers

These headers are all required. The X-CleverTap-Account-Id and X-CleverTap-Passcode are used to authenticate the request. Please see the [authentication guide](doc:authentication) to see how to get their values.

| Header                 | Description                                             | Type   | Example Value                        |
| :--------------------- | :------------------------------------------------------ | :----- | :----------------------------------- |
| X-CleverTap-Account-Id | Your CleverTap Account ID.                              | string | "X-CleverTap-Account-Id: ACCOUNT_ID" |
| X-CleverTap-Passcode   | Your CleverTap Account Passcode.                        | string | "X-CleverTap-Passcode: PASSCODE"     |
| Content-Type           | Request content-type is always set to application/json. | string | "Content-Type: application/json"     |

## Body Parameter

The body is uploaded as a JSON payload.

| Parameter | Description                                                                                                                       | Type | Example Value |
| :-------- | :-------------------------------------------------------------------------------------------------------------------------------- | :--- | :------------ |
| id        | CleverTap ID of the scheduled campaign you want to stop. You can find this id in your CleverTap dashboard under the push section. | int  | 1457432766    |

Below is an example payload.

```json
{
    "id": 1457432766
}
```

## Example Request

```curl
curl -X POST -d '{ "id": 1457432766}' "https://api.clevertap.com/1/targets/stop.json" \
-H "X-CleverTap-Account-Id: ACCOUNT_ID" \
-H "X-CleverTap-Passcode: PASSCODE" \
-H "Content-Type: application/json"
```
```ruby
require 'net/http'
require 'uri'
require 'json'

uri = URI.parse("https://api.clevertap.com/1/targets/stop.json")
request = Net::HTTP::Post.new(uri)
request.content_type = "application/json"
request["X-Clevertap-Account-Id"] = "ACCOUNT_ID"
request["X-Clevertap-Passcode"] = "PASSCODE"
request.body = JSON.dump({
  "id" => 1457432766
})

req_options = {
  use_ssl: uri.scheme == "https",
}

response = Net::HTTP.start(uri.hostname, uri.port, req_options) do |http|
  http.request(request)
end
```
```python
import requests

headers = {
    'X-CleverTap-Account-Id': 'ACCOUNT_ID',
    'X-CleverTap-Passcode': 'PASSCODE',
    'Content-Type': 'application/json',
}

data = '{ "id": 1457432766}'

response = requests.post('https://api.clevertap.com/1/targets/stop.json', headers=headers, data=data)
```
```php
<?php
include('vendor/rmccue/requests/library/Requests.php');
Requests::register_autoloader();
$headers = array(
    'X-CleverTap-Account-Id' => 'ACCOUNT_ID',
    'X-CleverTap-Passcode' => 'PASSCODE',
    'Content-Type' => 'application/json'
);
$data = '{ "id": 1457432766}';
$response = Requests::post('https://api.clevertap.com/1/targets/stop.json', $headers, $data);
```
```javascript Node.js
var request = require('request');

var headers = {
    'X-CleverTap-Account-Id': 'ACCOUNT_ID',
    'X-CleverTap-Passcode': 'PASSCODE',
    'Content-Type': 'application/json'
};

var dataString = '{ "id": 1457432766}';

var options = {
    url: 'https://api.clevertap.com/1/targets/stop.json',
    method: 'POST',
    headers: headers,
    body: dataString
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
        console.log(body);
    }
}

request(options, callback);
```

## Example Response

```json
{
    "status": "success"
}
```
