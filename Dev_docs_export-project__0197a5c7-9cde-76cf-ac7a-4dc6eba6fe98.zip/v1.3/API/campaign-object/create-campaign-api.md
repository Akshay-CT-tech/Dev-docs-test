---
title: "Create Campaign API"
slug: "create-campaign-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Feb 27 2020 01:32:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue May 25 2021 16:58:58 GMT+0000 (Coordinated Universal Time)"
---
# Overview

The Create Campaign API lets you send messages to your users. You can specify the audience for your message in two ways. The first option is to target people based on user events and properties. The second option is to target people based on their user ids.

For example, you can use this API to send a price drop alert as a [push notification](https://docs.clevertap.com/docs/push) to users who have viewed a certain product in the past week. If you have thousands of products and hundreds of thousands of users, this API lets you create a scalable and targeted way to notify your users of price drop alerts.

# Create Campaign API - Target User Events & Properties

To create a campaign, you have to specify the message, channel, and people to target by their user events and properties. For example, a user event could be a purchase event and the user property could be their location.

This endpoint is limited to 1 request per second.

## Base URL - Target User Events & Properties

<https://location.api.clevertap.com/1/targets/create.json>

> 📘 Note
> 
> Use the URL based on your location:
> 
> - India - in1.api.clevertap.com
> - Singapore - sg1.api.clevertap.com
> - U.S - us1.api.clevertap.com

## HTTP Method - Target User Events & Properties

POST

## Headers - Target User Events & Properties

These headers are all required. The X-CleverTap-Account-Id and X-CleverTap-Passcode are used to authenticate the request. Please see the [authentication guide](doc:authentication) to see how to get their values.

| Header                 | Description                                             | Type   | Example Value                        |
| :--------------------- | :------------------------------------------------------ | :----- | :----------------------------------- |
| X-CleverTap-Account-Id | Your CleverTap Account ID.                              | string | "X-CleverTap-Account-Id: ACCOUNT_ID" |
| X-CleverTap-Passcode   | Your CleverTap Account Passcode.                        | string | "X-CleverTap-Passcode: PASSCODE"     |
| Content-Type           | Request content-type is always set to application/json. | string | "Content-Type: application/json"     |

## Body Parameters - Target User Events & Properties

The body is uploaded as a JSON payload. name, when, title, body, subject, sender_name, target_mode, and where are required parameters. The where parameter is an object that has optional child properties including event_name, from, to, and profile_fields.

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Description",
    "h-2": "Required",
    "h-3": "Type",
    "h-4": "Example Value",
    "0-0": "name",
    "0-1": "The name of your campaign that will be shown in the CleverTap dashboard.",
    "0-2": "required",
    "0-3": "string",
    "0-4": "“My Campaign”",
    "1-0": "when",
    "1-1": "When you want to send out the messages. Valid inputs are now (to send the notification right away) or YYYYMMDD HH:MM to schedule the messages for a specific date and time in the future.",
    "1-2": "required",
    "1-3": "string",
    "1-4": "“now”",
    "2-0": "content",
    "2-1": "Object that defines the content for your message.",
    "2-2": "required",
    "2-3": "string",
    "2-4": "\"content\": {  \n        \"subject\": \"Welcome\",  \n        \"body\": \"<div>Your HTML content for the email</div>\",  \n        \"sender_name\": \"CleverTap\"  \n    }",
    "3-0": "content.title",
    "3-1": "Title content of your push notification message & web push message which is sent to the user.",
    "3-2": "required",
    "3-3": "string",
    "3-4": "“Hi”",
    "4-0": "content.body",
    "4-1": "Body content of your push notification, web push, email and sms which is sent to the user.",
    "4-2": "required",
    "4-3": "string",
    "4-4": "“Have you seen the special offer?”",
    "5-0": "content.subject",
    "5-1": "Subject content of your email which is sent to the user.",
    "5-2": "required",
    "5-3": "string",
    "5-4": "“Subject”",
    "6-0": "content._sender_name_ ",
    "6-1": "Sender name for your email which is sent to the user.",
    "6-2": "required",
    "6-3": "string",
    "6-4": "“Onboarding”",
    "7-0": "content.template_name",
    "7-1": "Namespace of the Whatsapp template you want to choose. This is available in settings for all our added Whatsapp templates.",
    "7-2": "required",
    "7-3": "string",
    "7-4": "\"662da022_5583_406d_9c71_428d5e3164bb:ticket_update\"",
    "8-0": "content.replacements",
    "8-1": "Add values that will replace the placeholders in the templates.",
    "8-2": "required",
    "8-3": "string",
    "8-4": "\"replacements\" : {  \n           \"1\" : <value>,  \n           \"2\" : <value>,  \n           \"3\" : <value>  \n}",
    "9-0": "content.attachments",
    "9-1": "Allows you to attach images, videos, documents, and locations to your Whatsapp message based on the attachment defined in your template.",
    "9-2": "required",
    "9-3": "string",
    "9-4": "\"attachments\": {  \n           \"type\": \"Document\",  \n            \"value\": \"<http://www.refworld.org/pdfid/4d3025492.pdf\">  \n        }\"  \n  \n\"attachments\": {  \n            \"type\": \"Location\",  \n            \"value\":{  \n                \"latitude\": \"19.8876\",  \n                \"longitude\": \"86.0945\"  \n            }  \n        }",
    "10-0": "provider_nick_name",
    "10-1": "Allows you to specify which vendor/provider to use for your campaign. For each target_mode, you can have multiple providers integrated with CleverTap, and this parameter lets you select which provider to use for the campaign. For example, let's say you select target_mode = email and you have integrated both SendGrid and Amazon SNS with CleverTap to send emails. In this scenario, you can set provider_nick_name = SendGrid to send the campaign through SendGrid.",
    "10-2": "optional",
    "10-3": "string",
    "10-4": "\"Provider 1\"",
    "11-0": "provider_group_nickname",
    "11-1": "Allows you to specify which provider group to use for your SMS campaign.  \nPlease use the name as added in your account settings",
    "11-2": "optional",
    "11-3": "String",
    "11-4": "\"NewTestSMSProviderGroup\"",
    "12-0": "where",
    "12-1": "Allows you to filter of target base by user events and profile properties. Send an empty object ({}) to target your entire user base.",
    "12-2": "required",
    "12-3": "object",
    "12-4": "\"where\": {  \n        \"event_name\": \"Charged\",  \n        \"from\": 20171001,  \n        \"to\": 20171220,  \n      \"common_profile_properties\": {  \n            \"profile_fields\": [  \n                {  \n                    \"name\": \"Customer Type\",  \n                    \"operator\":\"equals\",  \n                    \"value\": \"Platinum\"  \n                }  \n            ]  \n        }  \n    }",
    "13-0": "where.event_name",
    "13-1": "Allows you to target users based on an event they have performed.",
    "13-2": "optional",
    "13-3": "string",
    "13-4": "\"Charged\"",
    "14-0": "where.from",
    "14-1": "Start of date range for event needed. Value specified in format YYYYMMDD.",
    "14-2": "optional",
    "14-3": "int",
    "14-4": "20171001",
    "15-0": "where.to",
    "15-1": "End of date range for event needed. Value specified in format YYYYMMDD.",
    "15-2": "optional",
    "15-3": "int",
    "15-4": "20171220",
    "16-0": "where.profile_fields",
    "16-1": "Allows you to target users based on the values of their profile fields.",
    "16-2": "optional",
    "16-3": "string",
    "16-4": "\"common_profile_properties\": {  \n            \"profile_fields\": [  \n                {  \n                    \"name\": \"Customer Type\",  \n                    \"operator\":\"equals\",  \n                    \"value\": \"Platinum\"  \n                }  \n            ]  \n        }",
    "17-0": "respect_frequency_caps",
    "17-1": "Set to false if you want to override frequency caps.",
    "17-2": "optional",
    "17-3": "boolean",
    "17-4": "true",
    "18-0": "estimate_only",
    "18-1": "If this parameter is set to true the request will return an estimated reach of the campaign, which is the number of users who will get the notification when you send it out. Setting this parameter to true will not create the campaign.",
    "18-2": "optional",
    "18-3": "boolean",
    "18-4": "false",
    "19-0": "async_estimate",
    "19-1": "This allows setting of the estimate_only flag in the asynchronously. If this parameter is set to true, it will return a request ID that can be passed in the subsequent API call.",
    "19-2": "optional",
    "19-3": "boolean",
    "19-4": "",
    "20-0": "ttl",
    "20-1": "This allows setting of time of live for push notifications for android. The value has to be entered in hours which can range from 0 to 672 (i.e. 28 days). Default is 24 hours",
    "20-2": "optional",
    "20-3": "int",
    "20-4": "",
    "21-0": "wzrk_cid",
    "21-1": "Platform specific key that is required to target users on devices running Android O - can be used to determine notification channel to which a given push notification must belong.  \n  \nIf a Notification ID is mandatory then the channel ID is expected. An error occurs if a valid channel ID is not received.",
    "21-2": "optional / mandatory (Configurable)",
    "21-3": "string",
    "21-4": "",
    "22-0": "wzrk_bc",
    "22-1": "Platform specific key that can be used while targeting users on devices running Android O - can be used to determine the notification count shown on the app icon",
    "22-2": "optional",
    "22-3": "int",
    "22-4": "",
    "23-0": "wzrk_bi",
    "23-1": "Platform specific key that can be used while targeting users on devices running Android O - can be used to determine which icon should be used.  \n  \nAccepted values  \n`app icon`  \n`notification icon`",
    "23-2": "optional",
    "23-3": "string",
    "23-4": "",
    "24-0": "system_control_group_include",
    "24-1": "If the system control group is enabled from the dashboard, you can choose to use the control group for API campaigns",
    "24-2": "optional",
    "24-3": "boolean (true/false)",
    "24-4": "",
    "25-0": "control_group",
    "25-1": "If the custom control group is enabled from the dashboard, you can choose to use the control group for API campaigns",
    "25-2": "optional",
    "25-3": "string",
    "25-4": "\"control_group\": {  \n\"type\": \"custom\"  \n\"name\": \"_name of control group_\"  \n}",
    "26-0": "control_group",
    "26-1": "You can create a campaign control group via API by specifying the % as described on the left",
    "26-2": "optional",
    "26-3": "integer",
    "26-4": "\"control_group\": {  \n\"type\": \"campaign\"  \n\"percentage\": 5  \n}",
    "27-0": "wzrk_acts",
    "27-1": "Android Action Buttons  \n\"l\"= Action Title, \"dl\" = Deep link, \"id\" = Action id, \"ico\" = icon resource identifier",
    "27-2": "optional",
    "27-3": "string",
    "27-4": "wzrk_acts: \"[{\"l\":\"Action-1\",\"dl\":\"\",\"id\":\"01\",\"ico\":\"\"},  \n{\"l\":\"Action-2\",\"dl\":\"\",\"id\":\"02\",\"ico\":\"\"},  \n{\"l\":\"Action-3\",\"dl\":\"\",\"id\":\"03\",\"ico\":\"\"}]",
    "28-0": "respect_throttle",
    "28-1": "Toggle this flag to true if you want to enable throttle limits for the campaign.",
    "28-2": "optional",
    "28-3": "boolean",
    "28-4": "\"respect_throttle\":true",
    "29-0": "skip_estimate",
    "29-1": "Toggle this flag to true if you do not want to estimate the reach. This will lead to faster campaign delivery.",
    "29-2": "optional",
    "29-3": "boolean",
    "29-4": "\"skip_estimate\":true",
    "30-0": "send_to_all_devices",
    "30-1": "The flag is set to false by default. If no value is specified, then the notification is sent to the last active device. Toggle this flag to true if you wish to send notification to all active devices.",
    "30-2": "optional",
    "30-3": "boolean",
    "30-4": "false",
    "31-0": "segment",
    "31-1": "The campaign is created only if the segment is processed. You do not need to mention \"where\" when using segment.",
    "31-2": "optional",
    "31-3": "integer",
    "31-4": "",
    "32-0": "platform_specific",
    "32-1": "The platform specific details for Web Push notification",
    "32-2": "optional",
    "32-3": "String",
    "32-4": "",
    "33-0": "content.sms.template_id",
    "33-1": "Template ID (required for sending SMS to phone numbers of India",
    "33-2": "optional",
    "33-3": "String",
    "33-4": ""
  },
  "cols": 5,
  "rows": 34,
  "align": [
    "left",
    "left",
    "left",
    "left",
    "left"
  ]
}
[/block]


Example Payloads : 

```json Web Push Notification
{
    "name": "My Webpush API campaign",
    "estimate_only": true,
    "target_mode":"webpush",
    "where": {
        "event_name": "Charged",
        "from": 20171001,
        "to": 20171220, 
      "common_profile_properties": {
            "profile_fields": [
                {
                    "name": "Customer Type",
                    "operator":"equals",
                    "value": "Platinum"
                }
            ]
        }
    },
    "respect_frequency_caps": false,
    "content": {
        "title": "Hi!",
        "body": "How are you doing today?",
       "platform_specific": {
            "safari": {
                "deep_link": "https://www.google.com",
                "ttl":10
            },
            "chrome": {
              "image": "https://www.exampleImage.com",
              "icon":"https://www.exampleIcon.com",
              "deep_link": "http://www.example.com",
              "ttl":10,
              "require_interaction":true,
              "cta_title1":"title",
              "cta_link1":"http://www.example2.com",
              "cta_iconlink1":"https://www.exampleIcon2.com"
            },
            "firefox": {
            	"icon":"https://www.exampleIcon.com",
                "deep_link": "https://www.google.com",
                "ttl":10
            }
        }
    },
    "when": "now"
}
```
```json Mobile Push Notification
{
    "name": "My API Campaign",
    "estimate_only": true,
    "target_mode":"push",
    "where": {
        "event_name": "App Launched",
        "from": 20150101,
        "to": 20150303,
        "common_profile_properties": {
            "profile_fields": [
                {
                    "name": "Customer Type",
                    "operator":"equals",
                    "value": "Platinum"
                }
            ]
        }
    },
    "respect_frequency_caps": false,
    "content": {
        "title": "Hi!",
        "body": "How are you doing today?",
        "platform_specific": {
            "ios": {
                "mutable-content": "true", 
                "deep_link": "example.com",
                "sound_file": "example.caf",
                "category": "application category//Books",
                "badge_count": 1,
                "Key": "Value_ios"
            },
            "android": {
                "background_image": "http://example.jpg",
                "default_sound": true,
                "deep_link": "example.com",
                "large_icon": "http://example.png",
                "Key": "Value_android",
                "ttl":24
            }
        }
    },
    "devices": [
        "android",
        "ios"
    ],
    "when": "now"
}
```
```json Email
{
    "name": "My Email API campaign",
    "estimate_only": true,
    "target_mode":"email",
    "where": {
        "event_name": "Charged",
        "from": 20171001,
        "to": 20171220, 
      "common_profile_properties": {
            "profile_fields": [
                {
                    "name": "Customer Type",
                    "operator":"equals",
                    "value": "Platinum"
                }
            ]
        }
    },
    "respect_frequency_caps": false,
    "content": {
        "subject": "Welcome",
        "body": "<div>Your HTML content for the email</div>",
        "sender_name": "CleverTap"
    },
    "when": "now"
}
```
```json SMS
{
    "name": "My Sms API campaign",
    "estimate_only": true,
    "target_mode":"sms",
    "where": {
        "event_name": "Charged",
        "from": 20171001,
        "to": 20171220, 
      "common_profile_properties": {
            "profile_fields": [
                {
                    "name": "Customer Type",
                    "operator":"equals",
                    "value": "Platinum"
                }
            ]
        }
    },
    "respect_frequency_caps": false,
    "content": {
        "body": "Sms body"
    },
    "when": "now"
}
```
```json Webhooks
{
    "name": "My Webhook Campaign",
    "estimate_only": true,
    "target_mode":"webhook",
    "where": {
        "event_name": "Charged",
        "from": 20190101,
        "to": 20191220
    },
    "respect_frequency_caps": false,
    "webhook_endpoint_name":"Recommendation Endpoint",
    "webhook_fields":["profile-attributes","tokens","identities"],
    "webhook_key_value" : {
        "k1":"v1",
        "k2":"v2"
    },
    "when": "now"
}
```
```json App Inbox - Simple Message
{    
    "name": "api simple test",
    "estimate_only": false,
    "target_mode":"notificationinbox",
    "where": {
        "event_name": "Charged",
        "from": 20150101,
        "to": 20150303
    },
    "respect_frequency_caps": false,
    "send_to_all_devices": true,
    "template_type":"simple", // mandatory
    "content": [
        {
            "message":{
                "text":"MessageText"
            },
            "title":{
                "text":"titleText"
            },
            "action":{    
                "url":{
                    "android":{
                        "text":"andmurl"    
                    },
                    "ios":{
                        "text":"iosmurl"    
                    }
                },
                "links":[
                    {
                        "type":"copy",
                        "text":"linkText",
                        "copyText":{
                            "text":"copyText"
                        }
                    },
                    {
                        "type":"url",
                        "text":"linkText",
                        "url":{
                            "android":{
                                "text":"andLinkurl"    
                            },
                            "ios":{
                                "text":"iosLinkurl"
                            }
                        }    
                    }
                    ]
            },
            "media":{
                "content_type":"image/jpeg",
                "url":"example.com"
            }
        }
        ],
    "time_to_live":50,    
    "tags":[
        "abc",
        "bcd"
        ],
    "devices": [
        "ios",
        "android"
    ],
    "when": "now"
}
```
```json App Inbox - Carousel
{    
    "name": "api simple test",
    "estimate_only": false,
    "target_mode":"notificationinbox",
    "where": {
        "event_name": "Charged",
        "from": 20150101,
        "to": 20150303
    },
    "respect_frequency_caps": false,
    "send_to_all_devices": true,
    "template_type":"carousel",
    "orientation": "p",
    "content": [
        {
            "message":{
                "text":"Message1"
            },
            "title":{
                "text":"title1"
            },
            "action":{
                "url":{
                    "android":{
                        "text":"andurl1"
                    },
                    "ios":{
                        "text":"iosmurl1"    
                    }
                }
            },
            "media":{
                "content_type":"image/jpg",
                "url":"example.com"
            }
        },
        {
            "message":{
                "text":"Message2"
            },
            "title":{
                "text":"title2"
            },
            "action":{
                "url":{
                    "android":{
                        "text":"andurl2"
                    },
                    "ios":{
                        "text":"iosmurl2"    
                    }
                }
            },
            "media":{
                "content_type":"image/jpg",
                "url":"example.com"
            }
        }
        ],
    "time_to_live":8,
    "tags":[
        "abc",
        "bcd"
        ],
    "devices": [
        "ios",
        "android"
    ],
    "when": "now"
}


// media & template_type is mandatory
```
```json App Inbox - Carousel Image
{    
    "name": "api simple test",
    "estimate_only": false,
    "target_mode":"notificationinbox",
    "where": {
        "event_name": "Charged",
        "from": 20150101,
        "to": 20150303
    },
    "respect_frequency_caps": false,
    "send_to_all_devices": true,
    "template_type":"carousel-image",
    "orientation": "p",
    "content": [
        {
            "action":{
                "url":{
                    "android":{
                        "text":"andurl1"
                    },
                    "ios":{
                        "text":"iosmurl1"    
                    }
                }
            },
            "media":{
                "content_type":"image/jpg",
                "url":"example.com"
            }
        },
        {
            "message":{
                "text":"Message2"
            },
            "title":{
                "text":"title2"
            },
            "action":{
                "url":{
                    "android":{
                        "text":"andurl2"
                    },
                    "ios":{
                        "text":"iosmurl2"    
                    }
                }
            },
            "media":{
                "content_type":"image/jpg",
                "url":"example.com"
            }
        }
        ],
    "time_to_live":8,
    "tags":[
        "abc",
        "bcd"
        ],
    "devices": [
        "ios",
        "android"
    ],
    "when": "now"
}


// media & template_type is mandatory
```
```json App Inbox - Message with icon
{    
    "name": "api app inbox icon",
    "estimate_only": false,
    "target_mode":"notificationinbox",
    "where": {
        "event_name": "App Launched",
        "from": 20190101,
        "to": 20190418
    },
    "respect_frequency_caps": false,
    "send_to_all_devices": true,  
    "template_type":"message-icon",
    "orientation": "p",
    "content": [
        {
            "message":{
                "text":"MessageTexticon"
            },
            "title":{
                "text":"titleTextIcon"
            },
            "action":{
                "url":{
                    "android":{
                        "text":"andmurl"
                    },
                    "ios":{
                        "text":"iosmurl"    
                    }
                },
                "links":[
                    {
                        "type":"url",
                        "text":"linktextIcon",
                        "color":"#000000",
                        "bg":"#ffff",
                        "url":{
                            "android":{
                                "text":"andlurl"
                            },
                            "ios":{
                                "text":"ioslurl"
                            }
                        }
                    }
                    ]
            },
            "media":{
                "content_type":"image/jpg",
                "url":"https://s3.amazonaws.com/ct-demo-images/landscape-2.jpg"
            },
            "icon":{
                "content_type":"image/jpg",
                "url":"https://s3.amazonaws.com/ct-demo-images/landscape-2.jpg"
            }
        }
        ],
    "time_to_live":50,    
   
    "devices": [
        "ios",
        "android"
    ],
    "when": "now"
}

// template_type is mandatory
```
```json Whatsapp
{
    "name": "PBS document whatsapp campaign",
    "estimate_only": false,
    "target_mode": "whatsapp",
    "where": {
        "event_name": "Added To Cart",
        "from": 20200610,
        "to": 20200619,
        "common_profile_properties": {
            "profile_fields": [
                {
                    "name": "Fruit",
                    "operator":"equals",
                    "value": "Apple"
                }
            ]
        }
    },
    "respect_frequency_caps": false,
    
    "system_control_group_include": false,
    "content": {
        "template_name": "662da022_5583_406d_9c71_428d5e3164bb:ticket_update",
        "replacements": {
            "1": "buddy",
            "2":"Где ты се, Pад познакомиться."
            
        },
        "attachments": {
            "type": "Document",
            "value": "http://www.refworld.org/pdfid/4d3025492.pdf"
        }
    },
    "when": "now"
}
```

## Example Request - Target User Events & Properties

```curl
curl -X POST -d ' {"name": "My Sms API campaign","estimate_only": true,"target_mode":"sms", "where":{"event_name":"Charged","from":20171001,"to":20171220,"common_profile_properties":{"profile_fields": [ {"name": "Customer Type","operator":"equals","value": "Platinum"}]}},"respect_frequency_caps": false,"content": { "body": "Sms body"},"when": "now"}' \
"https://location.api.clevertap.com/1/targets/create.json" \
-H "X-CleverTap-Account-Id: ACCOUNT_ID" \
-H "X-CleverTap-Passcode: PASSCODE" \
-H "Content-Type: application/json"
```
```ruby
require 'net/http'
require 'uri'
require 'json'

uri = URI.parse("https://location.api.clevertap.com/1/targets/create.json ")
request = Net::HTTP::Post.new(uri)
request.content_type = "application/json"
request["X-Clevertap-Account-Id"] = "ACCOUNT_ID"
request["X-Clevertap-Passcode"] = "PASSCODE"
request.body = JSON.dump({
  "name" => "My Sms API campaign",
  "estimate_only" => true,
  "target_mode" => "sms",
  "where" => {
    "event_name" => "Charged",
    "from" => 20171001,
    "to" => 20171220,
    "common_profile_properties" => {
      "profile_fields" => [
        {
          "name" => "Customer Type",
          "operator" => "equals",
          "value" => "Platinum"
        }
      ]
    }
  },
  "respect_frequency_caps" => false,
  "content" => {
    "body" => "Sms body"
  },
  "when" => "now"
})

req_options = {
  use_ssl: uri.scheme == "https",
}

response = Net::HTTP.start(uri.hostname, uri.port, req_options) do |http|
  http.request(request)
end
```
```python
import requests

headers = {
    'X-CleverTap-Account-Id': 'ACCOUNT_ID',
    'X-CleverTap-Passcode': 'PASSCODE',
    'Content-Type': 'application/json',
}

data = ' {"name": "My Sms API campaign","estimate_only": true,"target_mode":"sms", "where":{"event_name":"Charged","from":20171001,"to":20171220,"common_profile_properties":{"profile_fields": [ {"name": "Customer Type","operator":"equals","value": "Platinum"}]}},"respect_frequency_caps": false,"content": { "body": "Sms body"},"when": "now"}'

response = requests.post('https://location.api.clevertap.com/1/targets/create.json', headers=headers, data=data)
```
```php
<?php
include('vendor/rmccue/requests/library/Requests.php');
Requests::register_autoloader();
$headers = array(
    'X-CleverTap-Account-Id' => 'ACCOUNT_ID',
    'X-CleverTap-Passcode' => 'PASSCODE',
    'Content-Type' => 'application/json'
);
$data = ' {"name": "My Sms API campaign","estimate_only": true,"target_mode":"sms", "where":{"event_name":"Charged","from":20171001,"to":20171220,"common_profile_properties":{"profile_fields": [ {"name": "Customer Type","operator":"equals","value": "Platinum"}]}},"respect_frequency_caps": false,"content": { "body": "Sms body"},"when": "now"}';
$response = Requests::post('https://location.api.clevertap.com/1/targets/create.json', $headers, $data);
```
```javascript Node.js
var request = require('request');

var headers = {
    'X-CleverTap-Account-Id': 'ACCOUNT_ID',
    'X-CleverTap-Passcode': 'PASSCODE',
    'Content-Type': 'application/json'
};

var dataString = ' {"name": "My Sms API campaign","estimate_only": true,"target_mode":"sms", "where":{"event_name":"Charged","from":20171001,"to":20171220,"common_profile_properties":{"profile_fields": [ {"name": "Customer Type","operator":"equals","value": "Platinum"}]}},"respect_frequency_caps": false,"content": { "body": "Sms body"},"when": "now"}';

var options = {
    url: 'https://location.api.clevertap.com/1/targets/create.json ',
    method: 'POST',
    headers: headers,
    body: dataString
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
        console.log(body);
    }
}

request(options, callback);
```

## Example Response - Target User Events & Properties

```json
{
  "status": "success",
  "estimates": {
    "web": 2
  }
}
```

## Example Request - Event Occurrence

```json
{
    "advanced_query": {
        "did_all": [
            {
                "event_name": "App Launched",
                "from": 20200101,
                "to": 20200218,
                "operator": "greater_than_equals",
                "value": 5,
            }
        ]
    }
}
```

# Create Campaign API - Target Users by their Identities

You can send notifications to your users based on their Facebook ID, Email ID, custom-defined identity, or CleverTap ID.

You can message 1000 users per API request.

## Base URL - Target Users by their Identities

The endpoint is different based on the channel you are sending the message. 

**SMS**  
<https://location.api.clevertap.com/1/send/sms.json>

**Push**  
<https://location.api.clevertap.com/1/send/push.json>

> ❗️ The push.json API currently does not support Push Amplification.

**Web Push**  
<https://location.api.clevertap.com/1/send/webpush.json>

**Email**  
<https://location.api.clevertap.com/1/send/email.json>

## HTTP Method - Target Users by their Identities

POST

## Headers - Target Users by their Identities

These headers are all required. The X-CleverTap-Account-Id and X-CleverTap-Passcode are used to authenticate the request. Please see the [authentication guide](doc:authentication) to see how to get their values.

| Header                 | Description                                                                | Type   | Example Value                                  |
| :--------------------- | :------------------------------------------------------------------------- | :----- | :--------------------------------------------- |
| X-CleverTap-Account-Id | Your CleverTap Account ID.                                                 | string | "X-CleverTap-Account-Id: ACCOUNT_ID"           |
| X-CleverTap-Passcode   | Your CleverTap Account Passcode.                                           | string | "X-CleverTap-Passcode: PASSCODE"               |
| Content-Type           | Request content-type should always set to application/json; charset=utf-8. | string | "Content-Type: application/json;charset=utf-8" |

## Body Parameters - Target Users by their Identities

The body is uploaded as a JSON payload. 

to, name, title, body, subject, sender_name, and  target_mode are required parameters. 

The to parameter is an object that has the following child properties: FBID, Email, Identity, objectId, which are used as identifiers to target your users. Each request can contain a max of 1000 users across these identifiers. 

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Description",
    "h-2": "Required",
    "h-3": "Type",
    "h-4": "Example Value",
    "0-0": "to",
    "0-1": "Used to define which users will receive the message.",
    "0-2": "required",
    "0-3": "object",
    "0-4": "\"to\": {  \n        \"FBID\": [  \n            \"102029292929388\",  \n            \"114342342453463\"  \n        ],  \n  \n        \"Email\": [  \n            \"john@doe.com\",  \n            \"jane@doe.com\"  \n        ],  \n        \"Identity\": [  \n            \"JohnDoe\"  \n        ],  \n        \"objectId\": [  \n            \"_asdnkansdjknaskdjnasjkndja\",  \n            \"-adffajjdfoaiaefiohnefwprjf\"  \n        ]  \n    }",
    "1-0": "to.FBID",
    "1-1": "Facebook ID for user.",
    "1-2": "required",
    "1-3": "array of strings",
    "1-4": "\"to\": {  \n        \"FBID\": [  \n            \"102029292929388\",  \n            \"114342342453463\"  \n        ]  \n}",
    "2-0": "to.Email",
    "2-1": "Email identifier for user.",
    "2-2": "required",
    "2-3": "array of strings",
    "2-4": "{  \n    \"to\": {  \n        \"Email\": [  \n            \"john@doe.com\",  \n            \"jan@doe.com\"  \n        ]  \n}",
    "3-0": "to.Identity",
    "3-1": "Custom-defined identifier for user.",
    "3-2": "required",
    "3-3": "array of strings",
    "3-4": "{  \n    \"to\": {  \n      \"Identity\": [  \n            \"JohnDoe\"  \n        ]  \n}",
    "4-0": "to.objectId",
    "4-1": "CleverTap identifier for user.",
    "4-2": "required",
    "4-3": "array of strings",
    "4-4": "{  \n    \"to\": {  \n        \"objectId\": [  \n \"sdnkansdjknaskdjnasjkndja\",     \"dffajjdfoaiaefiohnefwprjf\"  \n        ]  \n}",
    "5-0": "tag_group",
    "5-1": "Each message can be tagged into a tag group. Metrics, such as sent and viewed, will be shown against each tag group in the CleverTap dashboard. Max 500 groups. If not specified, the merics will be shown against the “Not Tagged” tag.",
    "5-2": "optional (either use tag \\_group or campaign_id)",
    "5-3": "string",
    "5-4": "\"my tag group\"",
    "6-0": "content",
    "6-1": "Object that defines the content for your message.",
    "6-2": "required",
    "6-3": "object",
    "6-4": "\"content\": {  \n        \"subject\": \"Welcome\",  \n        \"body\": \"<div>Your HTML content for the email</div>\",  \n        \"sender_name\": \"CleverTap\"  \n    }",
    "7-0": "content.title",
    "7-1": "Title content of your push notification message and web push message which is sent to the user.",
    "7-2": "required",
    "7-3": "string",
    "7-4": "\"Hi\"",
    "8-0": "content.body",
    "8-1": "Body content of your push notification, web push, email and sms which is sent to the user.",
    "8-2": "required",
    "8-3": "string",
    "8-4": "“Have you seen the special offer?”",
    "9-0": "content.subject",
    "9-1": "Subject content of your email which is sent to the user.",
    "9-2": "required",
    "9-3": "string",
    "9-4": "\"Subject\"",
    "10-0": "content.sender_name",
    "10-1": "Sender name for your email which is sent to the user.",
    "10-2": "required",
    "10-3": "string",
    "10-4": "“Onboarding”",
    "11-0": "provider_nick_name",
    "11-1": "Allows you to specify which vendor/provider to use for your campaign. For each target_mode, you can have multiple providers integrated with CleverTap, and this parameter lets you select which provider to use for the campaign. For example, let's say you select target_mode = email and you have integrated both SendGrid and Amazon SNS with CleverTap to send emails. In this scenario, you can set provider_nick_name = SendGrid to send the campaign through SendGrid.",
    "11-2": "optional",
    "11-3": "string",
    "11-4": "\"Provider 1\"",
    "12-0": "respect_frequency_caps",
    "12-1": "Set to false if you want to override frequency caps.",
    "12-2": "optional",
    "12-3": "boolean",
    "12-4": "false",
    "13-0": "wzrk_cid",
    "13-1": "Platform specific key that is required to target users on devices running Android O - can be used to determine notification channel to which a given push notification must belong.  \n  \nIf a Notification ID is mandatory then the channel ID is expected. An error occurs if a valid channel ID is not received.",
    "13-2": "optional / mandatory (configurable)",
    "13-3": "string",
    "13-4": "",
    "14-0": "badge_id",
    "14-1": "Platform specific key that can be used while targeting users on devices running Android O - can be used to determine the notification count shown on the app icon",
    "14-2": "optional",
    "14-3": "int",
    "14-4": "",
    "15-0": "badge_icon",
    "15-1": "Platform specific key that can be used while targeting users on devices running Android O - can be used to determine which icon should be used.  \n  \nAccepted values  \n`app icon`  \n`notification icon`",
    "15-2": "optional",
    "15-3": "string",
    "15-4": "",
    "16-0": "mutable-content",
    "16-1": "To raise Notification viewed event for Push notifications, raise the flag to \"true\" in the platform_specific: ios section of the request payload.",
    "16-2": "optional",
    "16-3": "boolean",
    "16-4": "",
    "17-0": "platform_specific",
    "17-1": "The platform specific details for Web Push notification",
    "17-2": "optional",
    "17-3": "string",
    "17-4": ""
  },
  "cols": 5,
  "rows": 18,
  "align": [
    "left",
    "left",
    "left",
    "left",
    "left"
  ]
}
[/block]


Below are example payloads for web push, push, email, and SMS.

```json Web Push
{
    "to": {
        "FBID": [
            "102029292929388",
            "114342342453463"
        ],
       
        "Email": [
            "john@doe.com",
            "jane@doe.com"
        ],
        "Identity": [
            "JohnDoe"
        ],
        "objectId": [
            "_asdnkansdjknaskdjnasjkndja",
            "-adffajjdfoaiaefiohnefwprjf"
        ]
    },
    "tag_group": "my tag group",
		"campaign_id": 1000000043,
    "respect_frequency_caps": false,
     "content": {
        "title": "Hi!",
        "body": "How are you doing today?",
       "platform_specific": {
            "safari": {
                "deep_link": "https://www.google.com",
                "ttl":10
            },
            "chrome": {
              "image": "https://www.exampleImage.com",
              "icon":"https://www.exampleIcon.com",
              "deep_link": "http://www.example.com",
              "ttl":10,
              "require_interaction":true,
              "cta_title1":"title",
              "cta_link1":"http://www.example2.com",
              "cta_iconlink1":"https://www.exampleIcon2.com"
            },
            "firefox": {
            	"icon":"https://www.exampleIcon.com",
                "deep_link": "https://www.google.com",
                "ttl":10
            }
        }
    }
}
```
```json Push
{
    "to": {
        "FBID": [
            "102029292929388",
            "114342342453463"
        ],
        "GPID": [
            "1928288389299292"
        ],
        "Email": [
            "john@doe.com",
            "jane@doe.com"
        ],
        "Identity": [
            "JohnDoe"
        ],
        "objectId": [
            "_asdnkansdjknaskdjnasjkndja",
            "-adffajjdfoaiaefiohnefwprjf"
        ]
    },
    "tag_group": "my tag group",
    "respect_frequency_caps": false,
    "content": {
        "title": "Welcome",
        "body": "Hello world!",
        "platform_specific": {
            "ios": {
                "deep_link": "example.com",
                "sound_file": "example.caf",
                "category": "notification category",
                "badge_count": 1,
                "key": "value_ios"
            },
            "android": {
                "background_image": "http://example.jpg",
                "default_sound": true,
                "deep_link": "example.com",
                "large_icon": "http://example.png",
                "key": "value_android"
            }
        }
    }
}
```
```json Email
{
    "to": {
        "FBID": [
            "102029292929388",
            "114342342453463"
        ],
        "GPID": [
            "1928288389299292"
        ],
        "Email": [
            "john@doe.com",
            "jane@doe.com"
        ],
        "Identity": [
            "JohnDoe"
        ],
        "objectId": [
            "_asdnkansdjknaskdjnasjkndja",
            "-adffajjdfoaiaefiohnefwprjf"
        ]
    },
    "tag_group": "my tag group",
    "respect_frequency_caps": false,
    "content": {
        "subject": "Welcome",
        "body": "<div>Your HTML content for the email</div>",
        "sender_name": "CleverTap"
    }
}
```
```json SMS
{
    "to": {
        "FBID": [
            "102029292929388",
            "114342342453463"
        ],
        "GPID": [
            "1928288389299292"
        ],
        "Email": [
            "john@doe.com",
            "jane@doe.com"
        ],
        "Identity": [
            "JohnDoe"
        ],
        "objectId": [
            "_asdnkansdjknaskdjnasjkndja",
            "-adffajjdfoaiaefiohnefwprjf"
        ]
    },
    "tag_group": "my tag group",
    "respect_frequency_caps": false,
     "content": {
        "body": "Sms body"
    }
}
```

## Example Request - Target Users by their Identities

```curl
curl -X POST -d '{"to":{"FBID":["102029292929388","114342342453463"],"Email":["john@doe.com","jane@doe.com"],"Identity":["JohnDoe"],"objectId":["_asdnkansdjknaskdjnasjkndja","-adffajjdfoaiaefiohnefwprjf"]},"campaign_id":1000000043,"tag_group":"mytaggroup","respect_frequency_caps":false,"content":{"body":"Smsbody"}}' \
"https://location.api.clevertap.com/1/send/sms.json" \
-H "X-CleverTap-Account-Id: ACCOUNT_ID" \
-H "X-CleverTap-Passcode: PASSCODE" \
-H "Content-Type: application/json"
```
```ruby
require 'net/http'
require 'uri'
require 'json'

uri = URI.parse("https://location.api.clevertap.com/1/send/sms.json")
request = Net::HTTP::Post.new(uri)
request.content_type = "application/json"
request["X-Clevertap-Account-Id"] = "ACCOUNT_ID"
request["X-Clevertap-Passcode"] = "PASSCODE"
request.body = JSON.dump({
  "to" => {
    "FBID" => [
      "102029292929388",
      "114342342453463"
    ],
   
    "Email" => [
      "john@doe.com",
      "jane@doe.com"
    ],
    "Identity" => [
      "JohnDoe"
    ],
    "objectId" => [
      "_asdnkansdjknaskdjnasjkndja",
      "-adffajjdfoaiaefiohnefwprjf"
    ]
  },
  "tag_group" => "mytaggroup",
  "respect_frequency_caps" => false,
  "content" => {
    "body" => "Smsbody"
  }
})

req_options = {
  use_ssl: uri.scheme == "https",
}

response = Net::HTTP.start(uri.hostname, uri.port, req_options) do |http|
  http.request(request)
end
```
```python
import requests

headers = {
    'X-CleverTap-Account-Id': 'ACCOUNT_ID',
    'X-CleverTap-Passcode': 'PASSCODE',
    'Content-Type': 'application/json',
}

data = '{"to":{"FBID":["102029292929388","114342342453463"],"Email":["john@doe.com","jane@doe.com"],"Identity":["JohnDoe"],"objectId":["_asdnkansdjknaskdjnasjkndja","-adffajjdfoaiaefiohnefwprjf"]},"tag_group":"mytaggroup","respect_frequency_caps":false,"content":{"body":"Smsbody"}}'

response = requests.post('https://location.api.clevertap.com/1/send/sms.json', headers=headers, data=data)
```
```php
<?php
include('vendor/rmccue/requests/library/Requests.php');
Requests::register_autoloader();
$headers = array(
    'X-CleverTap-Account-Id' => 'ACCOUNT_ID',
    'X-CleverTap-Passcode' => 'PASSCODE',
    'Content-Type' => 'application/json'
);
$data = '{"to":{"FBID":["102029292929388","114342342453463"],"Email":["john@doe.com","jane@doe.com"],"Identity":["JohnDoe"],"objectId":["_asdnkansdjknaskdjnasjkndja","-adffajjdfoaiaefiohnefwprjf"]},"tag_group":"mytaggroup","respect_frequency_caps":false,"content":{"body":"Smsbody"}}';
$response = Requests::post('https://location.api.clevertap.com/1/send/sms.json', $headers, $data);
```
```javascript Node.js
var request = require('request');

var headers = {
    'X-CleverTap-Account-Id': 'ACCOUNT_ID',
    'X-CleverTap-Passcode': 'PASSCODE',
    'Content-Type': 'application/json'
};

var dataString = '{"to":{"FBID":["102029292929388","114342342453463"],"GPID":["1928288389299292"],"Email":["john@doe.com","jane@doe.com"],"Identity":["JohnDoe"],"objectId":["_asdnkansdjknaskdjnasjkndja","-adffajjdfoaiaefiohnefwprjf"]},"tag_group":"mytaggroup","respect_frequency_caps":false,"content":{"body":"Smsbody"}}';

var options = {
    url: 'https://location.api.clevertap.com/1/send/sms.json',
    method: 'POST',
    headers: headers,
    body: dataString
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
        console.log(body);
    }
}

request(options, callback);
```

## Example Response - Target Users by their Identities

```json
{
    "status": "success",
    "message": "Added to queue for processing"
}
```

A success response implies payload validity and addition to the processing queue. Message delivery is handled by the provider (push or email) and depends on if you provided a valid recipient id.

## Notes

If there are errors, you will receive a response in the format below. 

```json
{
    "status": "fail",
    "error": "<error message here>",
    "code": <error code here>
}
```

Here are the possible error codes.  
21 – to is a mandatory field  
84 – Invalid recipients”  
73 – “respect_frequency_caps” must be a Boolean  
78 – Invalid JSON payload  
89 – Unexpected error, please try again

# Unsubscribe Link for Emails

If you’re using Amazon SES or your own SMTP gateway, you’ll have to follow the steps [listed on this page](https://docs.clevertap.com/docs/handling-unsubscribes) to enable your users to unsubscribe from your email notifications.
