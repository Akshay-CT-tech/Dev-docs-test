---
title: "Authentication"
slug: "authentication"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 09 2018 15:25:57 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Dec 01 2020 11:21:35 GMT+0000 (Coordinated Universal Time)"
---
CleverTap uses a header based authentication model to authenticate requests to the API. 

# Overview

Every CleverTap API call should include both your _Account ID_ and _Account Passcode_ as the request headers. If your CleverTap admin has opted for _User-Passcode_ instead of _Account Passcode_, you have to use your _User-Passcode_ instead in the passcode header. The CleverTap API expects these values to be keyed as X-CleverTap-Account-Id and X-CleverTap-Passcode. 

# Getting Your Account Credentials

Your CleverTap _Account ID_ and _Account/User Passcode_ are available on the _Settings_ page. To navigate to the _Settings_ page, log in to [your CleverTap account](https://eu1.dashboard.clevertap.com/login.html), click on the gear icon on the bottom left navigation, and select _Settings_ dashboard.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/8e1be5f-1202933.png",
        "1,20,29,33.png",
        1088
      ],
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/94a65ee-2273034.png",
        "2,27,30,34.png",
        1449
      ],
      "sizing": "80",
      "border": true
    }
  ]
}
[/block]


# Example

Here is an example cURL request to the _Events_ API showing the headers needed to authenticate the request.

```curl
curl "https://location.api.clevertap.com/1/events.json?cursor=CURSOR_VALUE" \
-H "X-CleverTap-Account-Id: YOUR_ACCOUNT_ID" \
-H "X-CleverTap-Passcode: YOUR_ACCOUNT_PASSCODE" OR "YOUR_USER_PASSCODE" \
-H "Content-Type: application/json"
```
```ruby
require 'net/http'
require 'uri'
uri = URI.parse("https://api.clevertap.com/1/events.json?cursor=CURSOR_VALUE")
request = Net::HTTP::Get.new(uri)
request.content_type = "application/json"
request["X-Clevertap-Account-Id"] = "YOUR_ACCOUNT_ID"
request["X-Clevertap-Passcode"] = "YOUR_ACCOUNT_PASSCODE"
req_options = {
  use_ssl: uri.scheme == "https",
}
response = Net::HTTP.start(uri.hostname, uri.port, req_options) do |http|
  http.request(request)
end
puts response.body
```

> 📘 Note
> 
> Use the URL based on your location:
> 
> - India - in1.api.clevertap.com
> - Singapore - sg1.api.clevertap.com
> - U.S. - us1.api.clevertap.com

# Next Steps

Now that you understand how to authenticate with the CleverTap API, you are ready to make your first API call. 

Start with [Get Events API](doc:get-events-api) which shows you how to request _App Launch_ events from CleverTap.

## User Passcode for APIs

You can enforce dashboard users to use _user passcode_ rather than _account passcode_ for API authentication. User passcode offers a better security standard while using CleverTap APIs. 

User passcodes are unique to each user and granted by admin to users.

## How To Enable User Passcode For a User

If you are an admin user, to enable using user passcode, go to _Settings_ > _Users_. Pick a user from the list and click on **Grant** as shown below: 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/10e7053-35.png",
        "35.png",
        2284
      ],
      "border": true
    }
  ]
}
[/block]


## User Passcode TTL (Time To Live)

When you grant the passcode to a user, you need to specify the time period until which the passcode remains valid. You can choose between _Finite_ (1-365 days) and _Infinite_ (never expire passcode).

Once you grant the user a user passcode, the user can see their user passcode on the _Settings_ page as shown below:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/08f0429-227303436.png",
        "2,27,30,34,36.png",
        1449
      ],
      "sizing": "80",
      "border": true
    }
  ]
}
[/block]


## Resetting and Revoking User Passcode

An admin can reset or revoke an existing user passcode by going to the user's page and clicking on one of the following options:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/9f0237e-37.png",
        "37.png",
        2284
      ],
      "border": true
    }
  ]
}
[/block]


![](https://files.readme.io/99a5814-38.png "38.png")

_Reset_ passcode will generate a fresh new passcode for the user. Post resetting the user will have to incorporate the new passcode to APIs.  
_Revoke_ passcode will invalidate the existing passcode for the user and the user can no longer fire API calls using their passcode.

> 📘 When to use user passcodes instead of account passcodes?
> 
> There can be situations where it becomes risky to give away account passcode of your CleverTap account to people inside and outside of your organization. It exposes your account to security risks. Therefore, it is best to grant user passcodes to specific users who would use CleverTap APIs instead of account passcode.
