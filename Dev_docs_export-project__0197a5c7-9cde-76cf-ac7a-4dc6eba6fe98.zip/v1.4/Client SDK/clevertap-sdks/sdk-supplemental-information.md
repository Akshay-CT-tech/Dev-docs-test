---
title: "SDK Supplemental Information"
slug: "sdk-supplemental-information"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Aug 04 2021 07:22:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Aug 04 2021 07:41:20 GMT+0000 (Coordinated Universal Time)"
---
1. Uninstall Tracking
2. App Personalization
3. Server-Side Lib
4. Client Side Lib
5. Deprecated - A/b Test
