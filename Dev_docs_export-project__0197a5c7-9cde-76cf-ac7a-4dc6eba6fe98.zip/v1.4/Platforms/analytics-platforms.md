---
title: "Analytics Platforms"
slug: "analytics-platforms"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Oct 14 2020 13:47:20 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Oct 21 2020 06:46:46 GMT+0000 (Coordinated Universal Time)"
---
You can import your event and profile data from other platforms to CleverTap. This data can be used in CleverTap to run analytics, segments, campaigns, or journeys. 

- [Mixpanel - Import Data](doc:mixpanel-import-data) 
- [Amplitude - Import Data](doc:amplitude-import-data)
