---
title: "Download User Profiles by Identity"
slug: "get_1-profile-json"
excerpt: "https://developer.clevertap.com/docs/upload-device-tokens-api"
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Feb 06 2023 06:31:48 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Feb 06 2023 06:31:48 GMT+0000 (Coordinated Universal Time)"
---
