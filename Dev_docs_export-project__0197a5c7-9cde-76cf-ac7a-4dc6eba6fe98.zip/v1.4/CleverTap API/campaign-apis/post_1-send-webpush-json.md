---
title: "Create Campaign - Target Users by their Identities(WEB PUSH)"
slug: "post_1-send-webpush-json"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Feb 06 2023 06:31:48 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Feb 06 2023 06:31:48 GMT+0000 (Coordinated Universal Time)"
---
