---
title: "Create Campaign - Target User Events & Properties"
slug: "post_1-targets-create-json"
excerpt: "https://developer.clevertap.com/docs/create-campaign-api#section-create-campaign-api-target-user-events-properties"
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Feb 06 2023 06:31:48 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Feb 06 2023 06:31:48 GMT+0000 (Coordinated Universal Time)"
---
