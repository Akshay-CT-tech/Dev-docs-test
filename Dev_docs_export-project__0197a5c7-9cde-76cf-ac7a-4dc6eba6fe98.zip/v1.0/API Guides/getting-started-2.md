---
title: "Getting Started"
slug: "getting-started-2"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Feb 20 2023 05:51:23 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Feb 20 2023 06:26:21 GMT+0000 (Coordinated Universal Time)"
---
## Overview

To get started with APIs, explore the following sections:

- [API Overview](https://developer.clevertap.com/reference/api-overview-1)
- [API Quick Start Guide](https://developer.clevertap.com/reference/api-quick-start-guide)
- [API Authentication](https://developer.clevertap.com/reference/api-authentication)
- [API Errors](https://developer.clevertap.com/reference/api-errors-1)
- [API Rate Limit](https://developer.clevertap.com/reference/api-rate-limit-1) 
- [CleverTap Query Language](https://developer.clevertap.com/reference/clevertap-query-language-1)
- [Common API Components](https://developer.clevertap.com/reference/common-api-components-1)
