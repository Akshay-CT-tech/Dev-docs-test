---
title: "Campaigns"
slug: "concepts-campaigns"
excerpt: ""
hidden: false
createdAt: "Tue Feb 06 2018 01:30:19 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:43 GMT+0000 (Coordinated Universal Time)"
---
# Overview

CleverTap offers nine different messaging channels that provide the capability to create engagement strategies to reach users with a personalized message at the right time.

> 👍 Campaign Example
> 
> You can set up a campaign to send a push notification with a discount code to users who have viewed a certain product.

You can use our Campaigns feature through the [CleverTap dashboard](https://docs.clevertap.com/docs/intro-to-campaigns) or through the [campaign API endpoints](doc:campaign-object).
