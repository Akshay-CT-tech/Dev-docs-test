---
title: "Flutter Resources"
slug: "flutter-resources"
excerpt: "View our sample app, usage document, and changelog."
hidden: false
createdAt: "Tue Sep 21 2021 08:33:20 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:42 GMT+0000 (Coordinated Universal Time)"
---
# Sample App

Check out our [Example Flutter project](https://github.com/CleverTap/clevertap-flutter/tree/master/example)

# Changelog

Refer to the [CleverTap Flutter SDK Change Log](https://github.com/CleverTap/clevertap-flutter/tree/master/CHANGELOG.md).

# FAQ

Q. How to manage the `onSelectNotification` callback function issue while using the `flutter_local_notifications` package in iOS?  
A. For iOS, you can remove `[CleverTap autoIntegrate]` from the `AppDelegate` file and manually handle the notifications. This solves the `onSelectNotification` callback function issue.
