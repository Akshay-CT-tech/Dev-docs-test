---
title: "Unity SDK"
slug: "unity"
excerpt: "Learn how to install and integrate your app with Unity SDK."
hidden: false
createdAt: "Mon May 02 2022 06:48:13 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jun 05 2025 18:58:39 GMT+0000 (Coordinated Universal Time)"
---
# Overview

CleverTap provides a [Unity Plugin](https://github.com/CleverTap/clevertap-unity-sdk) that enables app developers to track, segment, and engage their users.

# Prerequisites

Ensure you have the following prerequisites to start the Unity integration:

| Platform | Prerequisite                                                                                                                                            |
| :------- | :------------------------------------------------------------------------------------------------------------------------------------------------------ |
| All      | CleverTap Account                                                                                                                                       |
| iOS      | Apple Xcode                                                                                                                                             |
| Android  | Optional: Android Studio                                                                                                                                |
| Unity    | Ensure you have the latest supported LTS version of Unity, v2022.2.13f1 or higher, from the [Unity website](https://unity.com/releases/editor/archive). |

# Supported Versions

The CleverTap Unity SDK from 2.4.0 and above supports Unity LTS versions 2023.2.x and 2022.3.x.

> 🚧 Need Help with Unity Version Support?
> 
> If you're unsure which Unity version is supported or are using a version earlier than v2022.2.13f1, refer to the [CleverTap Developer Documentation](doc:getting-started) or reach out to our Support team via the Support section on your CleverTap dashboard.

# Unity SDK Versions and Size

Refer to the following table for Unity SDK versions and Unity SDK code sizes:

| SDK                 | Version | Code Size |
| :------------------ | :------ | :-------- |
| CleverTap Unity SDK | 5.2.0   | 2.1 MB    |

# Integrate the Unity SDK

Refer to our quick start guide to get started with the Unity integration:

[block:parameters]
{
  "data": {
    "h-0": "Steps",
    "h-1": "Procedure",
    "0-0": "**Step 1**",
    "0-1": "[Install the SDK](doc:unity-sdk-quick-start-guide-sdk-v300#install)",
    "1-0": "**Step 2**",
    "1-1": "<ul><li>[iOS Specific Instructions](doc:unity-sdk-quick-start-guide-sdk-v300#ios-specific-instructions)</li><li>[Android Specific Instructions](doc:unity-sdk-quick-start-guide-sdk-v300#android-specific-instructions)</li>"
  },
  "cols": 2,
  "rows": 2,
  "align": [
    "left",
    "left"
  ]
}
[/block]


# Unity SDK Resources

The following table lists all the Unity SDK resources:

| Resources                                                                                    | Description                                                                                                      |
| :------------------------------------------------------------------------------------------- | :--------------------------------------------------------------------------------------------------------------- |
| [Unity GitHub Repository](https://github.com/CleverTap/clevertap-unity-sdk)                  | Provides all the resources required to integrate CleverTap Unity SDK.                                            |
| [Sample Application](https://github.com/CleverTap/clevertap-unity-sdk/tree/master/CTExample) | Provides a sample application to demonstrate the integration of our Unity SDK.                                   |
| [Unity Advanced Features](https://developer.clevertap.com/docs/unity-advanced-features)      | Provides all the advanced features related to Unity.                                                             |
| [Go Live Checklist ](https://developer.clevertap.com/docs/go-live-checklist)                 | Provides a list of actions to be performed before you launch your application.                                   |
| [Changelog](https://github.com/CleverTap/clevertap-android-sdk/blob/master/CHANGELOG.md)     | Provides details about the most recent updates to our SDKs, including bug fixes, new features, and enhancements. |

# Additional Reference

Use the following resources to implement and troubleshoot the CleverTap Unity SDK. These references cover core integration areas like data tracking, push notifications, In-App messaging, and common troubleshooting scenarios to help maximise your Unity integration.

[block:html]
{
  "html": "<div class=\"two-col-container\">\n  <div class=\"link-content\">\n    <h4 class=\"custom-heading\">Unity Data Tracking</h4>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/unity-user-profiles\" target=\"_blank\" rel=\"noopener noreferrer\">Unity User Profile</a></p>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/unity-user-events\" target=\"_blank\" rel=\"noopener noreferrer\">Unity User Events</a></p>\n  </div>\n  <div class=\"link-content\">\n    <h4 class=\"custom-heading\">Unity Push</h4>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/unity-push\" target=\"_blank\" rel=\"noopener noreferrer\">Unity Push Notifications</a></p>\n  </div>\n  <div class=\"link-content\">\n    <h4 class=\"custom-heading\">Unity SDK Features</h4>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/unity-inapp\" target=\"_blank\" rel=\"noopener noreferrer\">Unity In-App Notification</a></p>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/unity-app-inbox\" target=\"_blank\" rel=\"noopener noreferrer\">Unity App Inbox</a></p>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/unity-advanced-features\" target=\"_blank\" rel=\"noopener noreferrer\">Unity Advanced Features</a></p>    \n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/unity-remote-config-sdk-v300\" target=\"_blank\" rel=\"noopener noreferrer\">Unity Product Experiences</a></p>    \n  </div>\n  <div class=\"link-content\">\n    <h4 class=\"custom-heading\">Troubleshooting & FAQs</h4>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/unity-troubleshooting-and-faqs\">Unity Troubleshooting and FAQs</a></p>\n  </div>\n</div>"
}
[/block]
