---
title: "Geofence Android SDK"
slug: "geofence-android-sdk"
excerpt: ""
hidden: false
createdAt: "Thu Sep 15 2022 15:25:22 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:42 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://developer.clevertap.com/docs/geofence-android"
---
