---
title: "Android Resources"
slug: "android-resources"
excerpt: "View our sample app, usage document, and changelog."
hidden: false
createdAt: "Mon Dec 13 2021 15:07:07 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:42 GMT+0000 (Coordinated Universal Time)"
---
# Sample App and Live demo

Refer to our [example Android project](https://github.com/CleverTap/clevertap-android-sdk/tree/master/sample). You can build the app via AndroidStudio and run it on any device or emulator. When opened, the app shows an interactive list of all the features provided by the CleverTap Android SDK. Clicking each feature runs the associated feature's code and generates the results in AndroidStudio's LogCat window.

# Usage Documentation

Refer to our [CleverTap Android Usage documentation](https://github.com/CleverTap/clevertap-android-sdk)

# Changelog

Refer to the [CleverTap Android SDK Change Log](https://github.com/CleverTap/clevertap-android-sdk/blob/master/CHANGELOG.md).
