---
title: "Android In-App"
slug: "android-in-app-notifications"
excerpt: "Learn how to send and control In-App notifications."
hidden: false
createdAt: "Wed Dec 08 2021 15:24:03 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 21 2025 20:49:49 GMT+0000 (Coordinated Universal Time)"
---
# Overview

CleverTap provides the capability to send In-App messages with images, GIFs, video, and audio. You can also do A/B testing on your In-App.

> 📘 Note
> 
> Ensure your activities extend FragmentActivity.

## Exclude In-App from Android Activity

If your application has a splash screen (for example, logo screen or loading page) displayed on app launch, then the In-App triggered on _App Launch_ would be attempted to be displayed on this screen. As soon as this screen is dismissed, the In-App will be dismissed, too.

In these types of cases, the splash screen must be excluded. Mention the _Activities_ on which you do not want In-App notifications to show in the android: value of the metadata tag in the AndroidManifest.xml file.

```xml
<meta-data
    android:name="CLEVERTAP_INAPP_EXCLUDE"
    android:value="YourSplashActivity1, YourSplashActivity2" />
```

## Control In-App Notifications

With CleverTap Android SDK 4.2.0 and above, you can control the rendering of In-App notifications by calling the following methods:

### Suspend

Suspends and saves In-App notifications until `resumeInAppNotifications` method is called for the current session.

```kotlin
CleverTapAPI.getDefaultInstance(ctx)!!.suspendInAppNotifications()
```
```java
CleverTapSingleton.getDefaultInstance(ctx).suspendInAppNotifications();
```

### Discard

Suspends the display of In-App Notifications and discards the display of any new In-App notification. It also discards In-App notifications until `resumeInAppNotifications`  method is called for the current session.

```kotlin
CleverTapAPI.getDefaultInstance(ctx)!!.discardInAppNotifications()
```
```java
CleverTapSingleton.getDefaultInstance(ctx).discardInAppNotifications();
```

### Resume

The `resumeInAppNotifications` method resumes displaying in-app notifications.

If you call this method after the `discardInAppNotifications()` method, it resumes the In-App notifications for events raised after the call is performed. 

However, if you call the `resumeInAppNotifications` method after the `suspendInAppNotifications()` method, then it displays all queued In-App notifications and also resumes In-App notifications for events raised after the call is performed. 

```kotlin
CleverTapAPI.getDefaultInstance(ctx)!!.resumeInAppNotifications()
```
```java
CleverTapSingleton.getDefaultInstance(ctx).resumeInAppNotifications();
```

## Callbacks for In-App Notifications

Implement the `InAppNotificationListener` interface to control and respond to the In-App notification lifecycle. This includes rendering logic, display tracking, and dismissal handling.

### In-App Notification `beforeShow`callback

Called before an In-App notification is displayed. Use this callback to determine whether the notification should be shown.

```kotlin
/**
 * Called before an In-App notification is displayed.
 * Return `false` to suppress the notification.
 *
 * @param extras A map of key-value pairs configured in the CleverTap dashboard for this notification.
 * @return `true` to render the notification; `false` to suppress it.
 */
fun beforeShow(extras: Map<String, Any>): Boolean
```
```java
/**
 * Called before an in-app notification is displayed.
 * Return {@code false} to suppress the notification.
 *
 * @param extras A map of key/value pairs configured in the CleverTap dashboard for this notification.
 * @return {@code true} to render the notification, {@code false} to prevent it from being displayed.
 */
boolean beforeShow(Map<String, Object> extras);
```

### In-App Notification`onShow` callback

Called when an In-App notification is displayed to the user.

```kotlin
/**
 * Called when the In-App notification is rendered on screen.
 *
 * @param ctInAppNotification The [CTInAppNotification] object representing the displayed content.
 */
fun onShow(ctInAppNotification: CTInAppNotification)
```
```java
/**
 * Called when the in-app notification is rendered on screen.
 *
 * @param ctInAppNotification The CTInAppNotification object representing the displayed content.
 */
void onShow(CTInAppNotification ctInAppNotification);
```

### In-App Notification `onDismissed` callback

Called after the In-App notification is dismissed through user interaction or auto-close.

```kotlin
/**
 * Called when the In-App notification is dismissed.
 *
 * @param extras A map of key-value pairs set in the dashboard for this notification.
 * @param actionExtras A map of key-value pairs from the selected action, if any. Can be null.
 */
fun onDismissed(
    extras: Map<String, Any>,
    actionExtras: Map<String, Any>?
)
```
```java
/**
 * Called when the in-app notification is dismissed.
 *
 * @param extras       The key/value pairs set in the dashboard for this notification.
 * @param actionExtras The key/value pairs from the selected action (if any). May be null.
 */
void onDismissed(Map<String, Object> extras, @Nullable Map<String, Object> actionExtras);
```

## Javascript Support in In-App Notifications

Android SDK v3.5.0 and above supports embedding JavaScript code inside custom In-Apps. To ensure your JavaScript code works on the app while creating the In-App campaign, select the checkbox for _Enabling JavaScript during the In-App campaign_ creation.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/185fa3f-image_1.png",
        "Custom HTML Template in In-App Notifications",
        "Custom HTML Template in In-App Notifications"
      ],
      "align": "center",
      "border": true,
      "caption": "Custom HTML Template in In-App Notifications"
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3edcde1-image_2.png",
        "Include JavaScript in In-App Notifications",
        "Include JavaScript in In-App Notifications"
      ],
      "align": "center",
      "border": true,
      "caption": "Include JavaScript in In-App Notifications"
    }
  ]
}
[/block]


Consider the following methods explained with examples:

```javascript Javascript
//Recording a User Event called Product Viewed in JS enabled custom In-Apps
if (window.CleverTap) {
  // Call Android interface             
 CleverTap.pushEvent("Product Viewed");          
}

//Recording a User Event called Product Viewed with properties, in JS enabled custom In-Apps
var props = {foo: 'xyz', lang: 'French'};
if (window.CleverTap) {
  // Call Android interface             
 CleverTap.pushEvent("Product Viewed",JSON.stringify(props));
           }

//Updating profile properties of the User in JS enabled custom In-Apps
var props = {foo: 'xyz', lang: 'French'};
if (window.CleverTap) {
  // Call Android interface             
 CleverTap.pushProfile(JSON.stringify(props));          
}

//Adding user property for the User in JS enabled custom In-Apps
if (window.CleverTap) {
  // Call Android interface 
CleverTap.addMultiValueForKey('membership', 'gold');
}

//Adding multiple user properties for the User in JS enabled custom In-Apps
var cars = ['Saab', 'Volvo', 'BMW', 'Kia'];
if (window.CleverTap) {
  // Call Android interface 
CleverTap.addMultiValuesForKey('Cars', JSON.stringify(cars));
}

//removing a user property for a specific key in JS enabled custom In-Apps
if (window.CleverTap) {
// Call Android interface 
CleverTap.removeMultiValueForKey(‘Cars’, 'Saab');
}

//Removing multiple user properties for a specific key in JS enabled custom In-Apps
var cars = ['BMW', 'Kia'];
if (window.CleverTap) {
  // Call Android interface 
CleverTap.removeMultiValuesForKey('Cars', JSON.stringify(cars));
}

//Removing a user property by specifying a key in JS enabled custom In-Apps
if (window.CleverTap) {
  // Call Android interface 
CleverTap.removeValueForKey('Cars');
}

//Setting a user property by specifying the key in JS enabled custom In-Apps

var values = ['Mercedes','Bentley']
if (window.CleverTap) {
  // Call Android interface 
CleverTap.setMultiValueForKey('Cars', JSON.stringify(values));
}


// Increment user property value by specifying the key in JS enabled custom In-Apps

if (window.CleverTap) {
  // Call Android interface 
CleverTap.incrementValue('Cars',2);
}

// Decrement user property value by specifying the key in JS enabled custom In-Apps

if (window.CleverTap) {
  // Call Android interface 
CleverTap.decrementValue('Cars',2)
}

//Calling onUserLogin 

var props = {Identity: '12434', Email: 'xyz@xyz.com'};
if (window.CleverTap) {
  // Call Android interface 
CleverTap.onUserLogin(JSON.stringify(props));
}
```

## In-App Notification Button onClick Callbacks

Android SDK v3.6.1 and above supports callback on the click of In-App notification buttons by returning a map of key-value pairs. To use this, make sure your activity implements the `InAppNotificationButtonListener` and override the following method: 

```kotlin Kotlin
override fun onInAppButtonClick(hashMap: HashMap<String, String>?) {
        // Read the values
    }
```
```java JAVA
@Override
public void onInAppButtonClick(HashMap<String, String> hashMap) {
  if(hashMap != null){
    //Read the values
  }
}
```

Set the `InAppNotificationButtonListener` using the following code:

```text Kotlin
cleverTapDefaultInstance?.apply {
       setInAppNotificationButtonListener(this@YourAndroidActivity)
   }
```
```java JAVA
cleverTapInstance.setInAppNotificationButtonListener(this);
```

Also please note that you must define custom key value pairs to receive this callback.

## Android Push Primer

A _Push Primer_ can explain to your users the need for push notifications and help improve your engagement rates. It is an In-App notification that shows your users the details of message types they can expect before requesting notification permission. It helps with the following:

- Educates your users about the purpose of requesting this permission before invoking a system dialog that asks the user to allow/deny this permission.
- Acts as a precursor to the hard system dialog and thus allows you to ask for permission multiple times if previously denied without making your users search the device settings.

For more information on push primer, refer to [Push Notification Permission](https://developer.clevertap.com/docs/android-push#push-notification-permission). 

### Push Primer using Half-Interstitial InApp

This template can send a customized push primer notification, such as displaying an image and modifying the text, button, and background color.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1919d3a-push_primer_half_interstitial.png",
        "Push Primer Using Half-Interstitial InApp",
        398
      ],
      "align": "center",
      "sizing": "smart",
      "border": true,
      "caption": "Push Primer Using Half-Interstitial InApp"
    }
  ]
}
[/block]


Use the following to create your template:

```kotlin
val builder = CTLocalInApp.builder()
    .setInAppType(CTLocalInApp.InAppType.HALF_INTERSTITIAL)
    .setTitleText("Get Notified")
    .setMessageText("Please enable notifications on your device to use Push Notifications.")
    .followDeviceOrientation(true)
    .setPositiveBtnText("Allow")
    .setNegativeBtnText("Cancel")
    .setBackgroundColor(Constants.WHITE)
    .setBtnBorderColor(Constants.BLUE)
    .setTitleTextColor(Constants.BLUE)
    .setMessageTextColor(Constants.BLACK)
    .setBtnTextColor(Constants.WHITE)
    .setBtnBackgroundColor(Constants.BLUE)
    .build()
cleverTapAPI.promptPushPrimer(builder)
```
```java
JSONObject jsonObject = CTLocalInApp.builder()
        .setInAppType(CTLocalInApp.InAppType.HALF_INTERSTITIAL)
        .setTitleText("Get Notified")
        .setMessageText("Please enable notifications on your device to use Push Notifications.")
        .followDeviceOrientation(true)
        .setPositiveBtnText("Allow")
        .setNegativeBtnText("Cancel")
        .setBackgroundColor(Constants.WHITE)
        .setBtnBorderColor(Constants.BLUE)
        .setTitleTextColor(Constants.BLUE)
        .setMessageTextColor(Constants.BLACK)
        .setBtnTextColor(Constants.WHITE)
        .setImageUrl("https://icons.iconarchive.com/icons/treetog/junior/64/camera-icon.png")
        .setBtnBackgroundColor(Constants.BLUE)
        .build();
cleverTapAPI.promptPushPrimer(jsonObject);
```

### Push Primer using Alert InApp

You can use this template to send a basic push primer notification with a title, message, and two buttons.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/682aa29-Alert_push_primer.png",
        "Push Primer Using Alert InApp",
        398
      ],
      "align": "center",
      "sizing": "smart",
      "border": true,
      "caption": "Push Primer Using Alert In-App"
    }
  ]
}
[/block]


Use the following to create your template:

```kotlin
val builder = CTLocalInApp.builder()
    .setInAppType(CTLocalInApp.InAppType.ALERT)
    .setTitleText("Get Notified")
    .setMessageText("Enable Notification permission")
    .followDeviceOrientation(true)
    .setPositiveBtnText("Allow")
    .setNegativeBtnText("Cancel")
    .build()
cleverTapAPI.promptPushPrimer(builder)
```
```java
JSONObject jsonObject = CTLocalInApp.builder()
        .setInAppType(CTLocalInApp.InAppType.ALERT)
        .setTitleText("Get Notified")
        .setMessageText("Enable Notification permission")
        .followDeviceOrientation(true)
        .setPositiveBtnText("Allow")
        .setNegativeBtnText("Cancel")
        .build();
cleverTapAPI.promptPushPrimer(jsonObject);
```

### Method Description

The following is a description of all the methods used to create In-App templates. 

```java
setInAppType(InAppType)
//Required param
//InAppType - CTLocalInApp.InAppType.HALF_INTERSTITIAL & CTLocalInApp.InAppType.ALERT
//Description - Accepts only HALF_INTERSTITIAL & ALERT type to display the type of InApp.

setFallbackToSettings(Boolean)
//Optional param
//Boolean - true/false
//Description - If true and the permission  is denied then we fallback to app’s notification settings, if it’s false then we just throw a verbose log saying permission is denied.

setTitleText(String)
//Required param
//String - Text
//Description - Sets the title of the local InApp.

setMessageText(String)
//Required param
//String - Text
//Description - Sets the subtitle of the local InApp.

followDeviceOrientation(Boolean)
//Required param
//Boolean - true/false
//Description - If true then the local InApp is shown for both portrait and landscape. If it sets false then local InApp only displays for portrait mode.

setPositiveBtnText(String)
//Required param
//String - Text
//Description - Sets the text of the positive button.

setNegativeBtnText(String)
//Required param
//String - Text
//Description - Sets the text of the negative button.

setBackgroundColor(String)
//Optional param
//String - Accepts Hex color as String
//Description - Sets the background color of the local InApp.

setBtnBorderColor(String)
//Optional param
//String - Accepts Hex color as String
//Description - Sets the border color of both positive/negative buttons.

setTitleTextColor(String)
//Optional param
//String - Accepts Hex color as String
//Description - Sets the title color of the local InApp.

setMessageTextColor(String)
//Optional param
//String - Accepts Hex color as String
//Description - Sets the sub-title color of the local InApp.

setBtnTextColor(String)
//Optional param
//String - Accepts Hex color as String
//Description - Sets the color of text for both positive/negative buttons.

setBtnBackgroundColor(String)
//Optional param
//String - Accepts Hex color as String
//Description - Sets the background color for both positive/negative buttons.

setBtnBorderRadius(String)
//Optional param
//String - String
//Description - Sets the radius for both positive/negative buttons. Default radius is “2” if not set.
```

### Call Android System Permission Flow from Web Interface (All types of HTML InApp)

The following two public methods are available to call the Android system permission flow from HTML InApp:

- `promptPushPermission(boolean shouldShowFallbackSettings)` - Used to trigger OS notification dialog.
- `dismissInAppNotification()` - Used to dismiss the current InApp.

The following is the sample code to request permission on button clicks for HTML campaigns:

```java
<script>
document.querySelector('#bt_gnp').addEventListener(
	'click',e => {
if(window.CleverTap){
 		CleverTap.promptPushPermission(true); // true/false on whether to show app’s notification        page if permission is denied.
	}
       })</script>
```
