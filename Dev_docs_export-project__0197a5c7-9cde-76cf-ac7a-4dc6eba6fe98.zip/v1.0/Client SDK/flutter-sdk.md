---
title: "Flutter SDK"
slug: "flutter-sdk"
excerpt: "Learn how to install and integrate your app with Flutter SDK."
hidden: false
createdAt: "Mon Sep 20 2021 14:29:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 21 2025 20:29:31 GMT+0000 (Coordinated Universal Time)"
---
# Overview

Flutter is an open-source mobile application development framework created by Google.  The framework allows you to create an application using the same codebase for various platforms. Flutter applications are written in the Dart programming language and use the same tools and APIs as their native counterparts. CleverTap supports integrating your application with Flutter and making the most of the native iOS and Android platforms.

Before getting started, refer to [Flutter Quick Start Guide](https://developer.clevertap.com/docs/flutter-quick-start-guide) for more details.

# Prerequisites

Ensure you have the following prerequisites to integrate CleverTap Flutter SDK with your app:

- CleverTap account
- Flutter Integrated Development Environment (IDE) such as VS Code, Emacs
- Android Studio IDE
- Apple Xcode IDE

# Supported Versions

- For [Android 15](https://developer.android.com/about/versions/15/summary), we recommend using the CleverTap Flutter SDK v3.2.0 or higher.
- For [Android 14](https://developer.android.com/about/versions/14/summary), we recommend using the CleverTap Flutter SDK v3.1.0 or below.
- The supported Dart SDK versions are from 2.12.0 to 4.0.0.
- The supported Flutter SDK version is 1.17.0 and higher.

# Flutter SDK Versions and Size

Refer to the following table for the Flutter SDK version and the corresponding SDK code size:

| SDK     | Version | Code Size |
| :------ | :------ | :-------- |
| Flutter | 3.3.1   | 274 KB    |

# Integrate the Flutter SDK

Refer to our quick start guide to get started with the Flutter integration:

| Steps  | Procedure                                                                                                   |
| :----- | :---------------------------------------------------------------------------------------------------------- |
| Step 1 | [Install Flutter SDK](https://developer.clevertap.com/docs/flutter-quick-start-guide#install)               |
| Step 2 | [Android Integration](https://developer.clevertap.com/docs/flutter-quick-start-guide#android-integration)   |
| Step 3 | [iOS Integration](https://developer.clevertap.com/docs/flutter-quick-start-guide#ios-integration)           |
| Step 4 | [Web Integration](https://developer.clevertap.com/docs/flutter-quick-start-guide#web-integration)           |
| Step 5 | [Run your Application](https://developer.clevertap.com/docs/flutter-quick-start-guide#run-your-application) |
| Step 6 | [Flutter Integration](https://developer.clevertap.com/docs/flutter-quick-start-guide#flutter-integration)   |

# Flutter SDK Resources

The following table lists all the Flutter SDK resources:

| Resources                                                                                | Description                                                                                                      |
| :--------------------------------------------------------------------------------------- | :--------------------------------------------------------------------------------------------------------------- |
| [Sample Application](https://github.com/CleverTap/clevertap-flutter/tree/master/example) | Provides a sample application to demonstrate the integration of our Flutter SDK.                                 |
| [Advanced Features](https://developer.clevertap.com/docs/flutter-advanced-features)      | Provides all the advanced features related to Flutter SDK.                                                       |
| [Go Live Checklist ](https://developer.clevertap.com/docs/go-live-checklist)             | Provides a list of actions to be performed before you launch your application.                                   |
| [Changelog](https://github.com/CleverTap/clevertap-flutter/blob/master/CHANGELOG.md)     | Provides details about the most recent updates to our SDKs, including bug fixes, new features, and enhancements. |

# Additional Reference

Refer to the following for additional Flutter SDK references:

[block:html]
{
  "html": "<div class=\"two-col-container\">\n  <div class=\"link-content\">\n    <h4 class=\"custom-heading\">Flutter Data Tracking</h4>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/user-profiles-flutter\" target=\"_blank\" rel=\"noopener noreferrer\">Flutter User Profile</a></p>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/user-events-flutter\" target=\"_blank\" rel=\"noopener noreferrer\">Flutter User Events</a></p>\n  </div>\n  <div class=\"link-content\">\n    <h4 class=\"custom-heading\">Flutter Push</h4>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/flutter-push-notification\" target=\"_blank\" rel=\"noopener noreferrer\">Flutter Push Notifications\n      </a></p>\n  </div>\n  <div class=\"link-content\">\n    <h4 class=\"custom-heading\">Flutter SDK Features</h4>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/flutter-in-app\" target=\"_blank\" rel=\"noopener noreferrer\">Flutter In-App Notification\n      </a></p>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/flutter-app-inbox\" target=\"_blank\" rel=\"noopener noreferrer\">Flutter App Inbox\n      </a></p>\n  </div> \n</div>"
}
[/block]
