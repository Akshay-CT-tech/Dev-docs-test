---
title: "iOS SDK"
slug: "ios"
excerpt: "Learn how to install and integrate your iOS app."
hidden: false
createdAt: "Tue Jan 09 2018 23:25:23 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri May 30 2025 13:31:03 GMT+0000 (Coordinated Universal Time)"
---
# Overview

This section shows you how to track custom events, enrich user profiles, and send push notifications with the CleverTap iOS SDK in your iOS app. Before getting started, refer to [iOS SDK Quick Start Guide](doc:ios-quickstart-guide). This guide shows you how to install the CleverTap SDK, track your first user event, and view this information on the CleverTap dashboard.

# Prerequisites

Ensure you have the following prerequisites to start the iOS integration:

- CleverTap account
- Apple Xcode IDE

# Supported Versions

The CleverTap iOS SDK supports the following versions:

- iOS 9.0 or later
- tvOS 9.0 or later

# iOS SDK Versions and Size

Refer to the following table for iOS SDK versions and iOS SDK code sizes:

| SDK                                                           | Version | Code Size |
| :------------------------------------------------------------ | :------ | :-------- |
| Core iOS                                                      | 7.2.0   | 1757 KB   |
| [Geofence](https://developer.clevertap.com/docs/geofence-ios) | 1.0.6   | 4.6 MB    |
| CTNotificationService                                         | 0.1.7   | 13.4 KB   |
| CTNotificationContent                                         | 0.3.0   | 237 KB    |

# Integrate the iOS SDK

Perform the following steps to get started with the iOS integration:

| Steps      | Procedure                                                                                                                                            |
| :--------- | :--------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Step 1** | [Install SDK](https://developer.clevertap.com/docs/ios-quickstart-guide#install-sdk)                                                                 |
| **Step 2** | [Integrate CleverTap SDK in iOS Applications](https://developer.clevertap.com/docs/ios-quickstart-guide#integrate-clevertap-sdk-in-ios-applications) |
| **Step 3** | [Run your Application](https://developer.clevertap.com/docs/ios-quickstart-guide#run-your-application)                                               |

# iOS SDK Resources

The following table lists all the iOS SDK resources:

| Resources                                                                               | Description                                                                                                 |
| :-------------------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------- |
| [GitHub Repository](https://github.com/CleverTap/clevertap-ios-sdk)                     | Provides all the resources required to integrate CleverTap iOS SDK.                                         |
| [SDK Direct Download](https://github.com/CleverTap/clevertap-ios-sdk/archive/3.7.0.zip) | Provides the downloaded iOS SDK source file.                                                                |
| [Sample Applications](https://developer.clevertap.com/docs/ios-resources#sample-app)    | Provides a sample application to demonstrate the integration of our iOS SDK.                                |
| [Advanced Features](https://developer.clevertap.com/docs/advanced-options-ios)          | Provides all the advanced features related to iOS.                                                          |
| [Go Live Checklist ](https://developer.clevertap.com/docs/go-live-checklist)            | Provides a list of actions to be performed before you launch your application.                              |
| [Changelog](https://github.com/CleverTap/clevertap-ios-sdk/blob/master/CHANGELOG.md)    | Provides details about most recent updates to iOS SDK, including bug fixes, new features, and enhancements. |

# Additional Reference

Following are the additional iOS SDK references:

[block:html]
{
  "html": "<div class=\"two-col-container\">\n  <div class=\"link-content\">\n    <h4 class=\"custom-heading\">iOS Data Tracking</h4>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/user-profiles-ios\" target=\"_blank\" rel=\"noopener noreferrer\">iOS User Profile</a></p>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/user-events-ios\" target=\"_blank\" rel=\"noopener noreferrer\">iOS User Events</a></p>\n  </div>\n  <div class=\"link-content\">\n    <h4 class=\"custom-heading\">iOS Push</h4>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/push-notifications-ios\" target=\"_blank\" rel=\"noopener noreferrer\">iOS Push Notifications\n      </a></p>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/rich-push-notifications\" target=\"_blank\" rel=\"noopener noreferrer\">iOS Rich Push Notifications\n</a></p>\n  </div>\n  <div class=\"link-content\">\n    <h4 class=\"custom-heading\">iOS SDK Features</h4>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/in-app-notification-ios\" target=\"_blank\" rel=\"noopener noreferrer\">iOS In App Notification\n      </a></p>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/app-inbox-ios\" target=\"_blank\" rel=\"noopener noreferrer\">iOS App Inbox\n      </a></p>\n    <a class=\"links\" href=\"https://developer.clevertap.com/docs/native-display-ios\" target=\"_blank\" rel=\"noopener noreferrer\">iOS Native Display\n     </a>\n  </div>\n  <div class=\"link-content\">\n    <h4 class=\"custom-heading\">iOS Product Experience and Custom Proxy Domain</h4>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/product-experiences-ios\" target=\"_blank\" rel=\"noopener noreferrer\">iOS Product Experiences\n      </a></p>\n    <p><a class=\"links\" href=\"https://developer.clevertap.com/docs/ios-custom-proxy-domain\" target=\"_blank\" rel=\"noopener noreferrer\">iOS Custom Proxy Domain\n      </a></p>\n  </div>\n</div>"
}
[/block]
