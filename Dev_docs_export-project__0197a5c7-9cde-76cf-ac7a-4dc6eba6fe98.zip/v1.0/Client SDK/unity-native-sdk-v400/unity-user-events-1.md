---
title: "Unity User Events"
slug: "unity-user-events-1"
excerpt: ""
hidden: true
createdAt: "Thu Jun 05 2025 12:31:50 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jun 05 2025 12:31:51 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://developer.clevertap.com/docs/unity-user-events"
link_external: true
---
