---
title: "CleverTap GTM Web Integration"
slug: "gtm-web"
excerpt: "Learn how to send your website events to CleverTap via GTM"
hidden: false
createdAt: "Tue Oct 04 2022 12:30:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:43 GMT+0000 (Coordinated Universal Time)"
---
# Overview

This SDK integration sends data from your website to your CleverTap account.

# Integration

The following are the four major steps to perform this integration:

1. [Initialize the SDK](doc:gtm-web#initialize-the-sdk).
2. [Call CleverTap Methods](doc:gtm-web#call-clevertap-methods).
3. [Create Variables for Passing Parameters](doc:gtm-web#create-variables-for-passing-parameters).
4. [Update Values of Variables before CleverTap Methods are Triggered](doc:gtm-web#update-values-of-variables-before-clevertap-methods-are-triggered)

## Initialize the SDK

Ensure you integrate the [Web SDK](doc:web-quickstart-guide#section-step-1-add-the-clever-tap-java-script-library-to-your-website) from the developer docs to all your web pages. One way to achieve this is by creating custom HTML tags. Refer to the example shown in the following figure:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/013d66b-web_1.png",
        "Custom HTML Tags",
        1590
      ],
      "align": "center",
      "border": true,
      "caption": "Custom HTML Tags"
    }
  ]
}
[/block]


## Call CleverTap Methods

To implement CleverTap methods such as OnUserLogin(), event.push(), or profile.push(), you can create custom HTML tags with variables and define the appropriate triggers. Refer to the example shown in the following figure:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/10dce99-web_2.png",
        "Call CleverTap Methods",
        1460
      ],
      "align": "center",
      "border": true,
      "caption": "Call CleverTap Methods"
    }
  ]
}
[/block]


## Create Variables for Passing Parameters

You can use the data layer to pass variables to CleverTap functions. For instance, for the above custom HTML to work, you must create the variables first in your GTM container.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4fd71dc-WEB_2.png",
        "User-Defined Variables",
        1476
      ],
      "align": "center",
      "border": true,
      "caption": "User-Defined Variables"
    }
  ]
}
[/block]


## Update Values of Variables before CleverTap Methods are Triggered

From your code, you must push these variables to the GTM dataLayer. For working with the GTM data layer, refer to the official [Google documentation](https://developers.google.com/tag-manager/devguide#datalayer).

For example, to update the email variable in the data layer, you must call that in your code.

```java
dataLayer.push({'email': 'satyajeet@clevertap.com'});
```
