---
title: "KaiOS SDK"
slug: "kaios"
excerpt: ""
hidden: false
createdAt: "Tue Apr 06 2021 18:49:03 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:43 GMT+0000 (Coordinated Universal Time)"
---
## Overview

KaiOS is a Linux-based mobile operating system for keypad feature phones. This OS supports 4G LTE E, VoLTE, GPS, and Wi-Fi; with HTML5-based apps. It also enables a longer battery life for non-touchscreen devices with an optimized user interface, less memory, and energy consumption. This mobile operating system requires fewer hardware resources and can run on devices with memory as low as 256 megabytes (MB). 

CleverTap supports KaiOS as a part of its engagement platform. You can identify users and track their events using our KaiOS SDK. After integrating KaiOS SDK, you can create new web push campaigns to engage users.
