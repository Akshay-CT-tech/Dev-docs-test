---
title: "Unreal SDK"
slug: "unreal-sdk"
excerpt: "Learn how to integrate and use the CleverTap Unreal Engine SDK"
hidden: false
createdAt: "Fri Apr 18 2025 12:08:29 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 21 2025 09:42:34 GMT+0000 (Coordinated Universal Time)"
---
# Overview

The CleverTap Unreal SDK brings powerful analytics and engagement capabilities to games and applications built using Unreal Engine (UE4/UE5). With this SDK, you can:

- Track in-game user behavior and milestones
- Enrich user profiles with custom attributes
- Log transactional data such as purchases
- Trigger personalized campaigns based on real-time user actions

Designed to be lightweight and developer-friendly, the Unreal SDK allows seamless integration with CleverTap’s platform and your existing Unreal Engine game architecture without affecting game performance.

Before proceeding with the integration, refer to [Unreal SDK Quick Start Guide](doc:unreal-quick-start-guide) for more details.

# Prerequisites

To use the CleverTap Unreal SDK, check that you have:

- A CleverTap account with a valid **Project ID**, **Project Token**, and **Region Code**.
- An Unreal Engine project written in C++ (UE4 or UE5).

# Unreal SDK Versions and Size

The following table outlines the code size for the current version of the CleverTap Unreal SDK:

| SDK                  | Version | Code Size |
| :------------------- | :------ | :-------- |
| CleverTap Unreal SDK | 0.0.2   | 1.4 MB    |

# Supported Platforms

- [Android](doc:android)
- [iOS](doc:ios)

# CleverTap Unreal SDK Resources

The following table lists resources to support your integration and testing efforts:

| Resources                                                                                    | Description                                                         |
| :------------------------------------------------------------------------------------------- | :------------------------------------------------------------------ |
| [CleverTap Unreal SDK](https://github.com/CleverTap/clevertap-unreal-sdk/blob/dev/README.md) | Provides source code and GitHub documentation for the SDK.          |
| [Go Live Checklist](doc:go-live-checklist)                                                   | Lists critical steps to complete before launching your application. |
| [Changelog](doc:changelog)                                                                   | Details of recent SDK updates, new features, and bug fixes.         |

# Additional References

Refer to the following for additional CleverTap Unreal SDK references:

- [CleverTap Developer Docs](https://developer.clevertap.com/docs)
- [Unreal Engine Plugin Guide (Epic Games)](https://docs.unrealengine.com/5.0/en-US/plugins-in-unreal-engine/)
- [Region Codes for Integration](doc:idc#enable-clevertap-region)
- [CleverTap Support](https://support.clevertap.com/)
