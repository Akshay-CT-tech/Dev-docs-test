---
title: "Signed Call™ Freshworks Custom App"
slug: "signed-call-freshworks-custom-app"
excerpt: "Learn how to integrate Signed Call™ Freshworks SDK in your app."
hidden: true
createdAt: "Mon Jan 13 2025 07:15:58 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 03 2025 10:20:22 GMT+0000 (Coordinated Universal Time)"
---
# Overview

This document provides a step-by-step walkthrough for installing and using the Signed Call™ [Freshworks](https://www.freshworks.com/?tactic_id=6525630&utm_source=google-adwords&utm_medium=FWorks-Search-Brand-Core-India&utm_campaign=FWorks-Search-Brand-Core-India&utm_term=freshworks&device=c&matchtype=e&network=g&gclid=Cj0KCQiAvbm7BhC5ARIsAFjwNHt8rRH_Q4WLOKUpsnX27hVWKDpuu1P2mfARzaT2p3uWd4Gq72oTd1AaApe4EALw_wcB&gad_source=1&gbraid=0AAAAADKtyUf-lvejC8m1kaZiGJS78l1w3) Custom App. The SDK extends the [SignedCall Web SDK](doc:signed-call-web-sdk), enabling Freshworks CRM agents to call end users on Android, iOS, or Web devices.

# Prerequisites

Before you begin, ensure you have the following setup:

- An activated Freshworks/Freshsales account.
- CleverTap Account ID along with Signed Call Account ID and API Key.
- CUID (A unique identifier for the person you want to contact and context information for usage).
- Context (The reason for initiating the call, as a Signed Call emphasizes contextual calling).

# Install Signed Call Freshworks Custom App

To install the SignedCall Freshworks Custom App:

1. Log in to the Freshworks/Freshsales portal.
2. Go to _Settings_ by clicking the gear icon on the left menu bar.
3. Select _Apps and Integrations_.   

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4acc486b929668ca072b555b024f4b2401afe0d639eb11ad5bedc35bae6e6341-2025-01-10_15-15-22.png",
        null,
        "Freshworks Dashboard"
      ],
      "align": "center",
      "border": true,
      "caption": "Freshworks Dashboard"
    }
  ]
}
[/block]


4. Select _Marketplace Apps_.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e2dcf4d20a33040a3b5bb0769795918bb4fb353b4ba0717d9e36bcdc03d3c9f5-2025-01-10_14-35-30.png",
        null,
        "Manage Apps"
      ],
      "align": "center",
      "border": true,
      "caption": "Manage Apps"
    }
  ]
}
[/block]


5. Go to the _Manage Apps_ section and click **Go to Developer Portal**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d03527fe4e4bac2c16a1c0a2f10eb7c4f49f3cdac497d6c2fedc4eabfe078832-2025-01-10_14-35-30.png",
        null,
        "Click on Developer Portal"
      ],
      "align": "center",
      "border": true,
      "caption": "Click Developer Portal"
    }
  ]
}
[/block]


6. Click **New App** and select _Custom App_.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fe97504cbe3770751e7ec6ab340459b38b076eea80a7eb8dc177e42121ed8dcd-neww.png",
        null,
        "Custom App"
      ],
      "align": "center",
      "border": true,
      "caption": "Custom App"
    }
  ]
}
[/block]


7. Upload the zip file provided by the Signed Call team.
8. Name the app and click **Save and Continue**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1e0d2b7e91a9faf9534a9d3b36ca96b106cc851ec455e294b42c2fbec7ef5847-hi.png",
        null,
        "Upload the Zip File"
      ],
      "align": "center",
      "border": true,
      "caption": "Upload the Zip File"
    }
  ]
}
[/block]


9. Enter a description for the app and click **Save and Continue**.
10. Enter support details such as _Support Email_, _Support URL_, and _Alternate Email_, and click **Save and Publish**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/bd1a66d2cfcc0b87112311e612b5fed4f64393203f8a4bc94f06f0a1a76ca026-hi.png",
        null,
        "Support Details"
      ],
      "align": "center",
      "border": true,
      "caption": "Enter Support Details"
    }
  ]
}
[/block]


11. Return to the _Manage Apps_ section on the Freshworks/Freshsales portal. Ensure that you are in the primary portal rather than the Developer Portal.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/2d8adb577f16a4334e488f6bac35c3bc5493072fdbf85d4dbac3427eeaec4495-hii.png",
        null,
        "Manage App"
      ],
      "align": "center",
      "border": true,
      "caption": "Manage App"
    }
  ]
}
[/block]


12. Locate the custom app under the _Custom Apps_ tab and click **Install**.
13. Enter the details the Signed Call team provided and click **Install** to finalize the setup.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/6b9195e7b99d97ee066aa012afe9e123b1c789f9553a84cbfa79a3425b1f24c5-hiii.png",
        null,
        "Final Installation"
      ],
      "align": "center",
      "border": true,
      "caption": "Final Installation"
    }
  ]
}
[/block]


# Make a Call

To make a call with Signed Call Freshworks Custom App:

1. Go to _Conversations_ from your Freshworks or Freshsales portal.
2. Go to _Chat_ and click **Chat Inbox**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3c09f6c62e149b4dfa23e6dd3fa7fec213fbf39605d2ca3b54ab05224ce68d8f-newww.png",
        null,
        "Chat Inbox"
      ],
      "align": "center",
      "border": true,
      "caption": "Chat Inbox"
    }
  ]
}
[/block]


3. Click the desired conversation and locate the widget at the bottom right of the screen.  
4. Enter the _CUID_, a unique identifier of the person you want to contact.
5. Enter the _Context_, the reason for the call.
6. Click **Call Now** to start the call once the required fields are filled,.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f9c1d26647b89ec4c56442cdb6fa6af93798ec5e4cab5736089841b5cfc643df-newwwww.png",
        null,
        "Conversation Window"
      ],
      "align": "center",
      "border": true,
      "caption": "Conversation Window"
    }
  ]
}
[/block]


If you need further assistance, contact the CleverTap support team. For more information, refer to [Signed Call SDKs](doc:signed-call-sdk).
