---
title: "Signed Call™ Android SDK for M2P Campaigns"
slug: "signed-call-android-sdk-for-m2p-campaigns"
excerpt: "Learn how to integrate Signed Call™ Android SDK in the application to enable the Signed Call feature for Machine-to-Person (M2P) campaigns."
hidden: true
createdAt: "Wed Apr 16 2025 11:04:00 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 03 2025 10:18:02 GMT+0000 (Coordinated Universal Time)"
---
# Overview

CleverTap enables In-App calling via the Signed Call™ feature, allowing businesses to initiate secure, in-app voice calls (that is, Machine to Person (M2P) calls) to users directly within any Android application. With the Signed Call Android SDK integrated and an active internet connection, users can receive calls initiated by backend systems—such as customer support, service updates, appointment notifications, or payment reminders—without requiring the users to switch apps or respond through the native dialer.

This document covers the following for M2P campaigns:

- Integrating Signed Call Android SDK
- Managing Signed Calls in your Android application

For more information, refer to [Signed Call](https://docs.clevertap.com/docs/signed-call-machine-to-person).

# Prerequisites

Ensure your application meets the following basic requirements before integrating Signed Call Android SDK  
for M2P campaigns:

- Minimum SDK level: 21
- Java version 11 and above
- Application permissions:
  - Notification (Required for [Android 13](doc:signed-call-android-sdk-for-m2p-campaigns#permission-management) and above)
  - Read Phone State (Optional)

# Integrate Signed Call Android SDK

The process of integration is divided into the following five key steps:

1. [Install Signed Call Android SDK](doc:signed-call-android-sdk-for-m2p-campaigns#install-signed-call-android-sdk)
2. [Add Signed Call SDK Dependencies](doc:signed-call-android-sdk-for-m2p-campaigns#add-signed-call-sdk-dependencies)
3. [Initialize Signed Call Android SDK](doc:signed-call-android-sdk-for-m2p-campaigns#initialize-signed-call-android-sdk)
4. [Set Up FCM for Signed Call](doc:signed-call-android-sdk-for-m2p-campaigns#set-up-fcm-for-signed-call) 
5. [Configure Machine-to-Person (M2P) Feature](doc:signed-call-android-sdk-for-m2p-campaigns#configure-machine-to-person-m2p-feature)

## Install Signed Call Android SDK

To download the latest version of the Signed Call Android SDK from`mavenCentral`, perform the following steps:

1. Include `mavenCentral` in your project-level `build.gradle` file as follows:

```groovy
allprojects {
    repositories {
        mavenCentral()
    }
}
```

2. Include SDK **0.0.7.1-m2p-beta** with the following code in the `build.gradle` file of your  application module:
   ```groovy
   implementation "com.clevertap.android:clevertap-signedcall-sdk:0.0.7.1-m2p-beta"
   ```

## Add Signed Call SDK Dependencies

To enable voice calling with the Signed Call Android SDK, you must add the following dependencies to the `build.gradle` file of your application module:

- [CleverTap Android SDK](doc:signed-call-android-sdk-for-m2p-campaigns#clevertap-android-sdk)
- [Firebase Cloud Messaging (FCM)](doc:signed-call-android-sdk-for-m2p-campaigns#firebase-cloud-messaging-fcm)
- [Socket-IO Client](doc:signed-call-android-sdk-for-m2p-campaigns#socket-io-client)
- [Glide](doc:signed-call-android-sdk-for-m2p-campaigns#glide)
- [Work Manager](doc:signed-call-android-sdk-for-m2p-campaigns#work-manager)
- [Constraint Layout](signed-call-android-sdk-for-m2p-campaigns#constraint-layout)

### CleverTap Android SDK

The Signed Call Android SDK uses CleverTap Android SDK for analytics. It requires an active `CleverTapAPI` instance as a parameter during the SDK initialization. 

To integrate the CleverTap Android SDK, refer to [CleverTap Android SDK Integration](doc:android-quickstart-guide).

> 📘 Minimum Supported Version
> 
> The Signed Call Android SDK integrates with CleverTap Android SDK **v7.3.1** or higher.

### Firebase Cloud Messaging (FCM)

The Signed Call Android SDK uses FCM dependency to get the FCM token of the device which is required for the successful SDK initialization.

To add the FCM dependency to your application, perform the following steps:

1. To add Firebase to your project if you have not already added it, refer to the [Firebase Integration Guide](https://firebase.google.com/docs/android/setup) 
2. Add the following code to the dependency element of the application module:

```groovy
implementation 'com.google.firebase:firebase-messaging:21.0.0'
```

> 📘 FCM Version
> 
> For Signed Call Android SDK, the minimum supported version of FCM is **v21.0.0**.

### Socket-IO Client

The Signed Call Android SDK uses a Socket-IO client library to enable the socket-based signaling channel for voice calls.

To add the Socket-IO client dependency to your application, add the following line to the application module dependency element:

```groovy
implementation('io.socket:socket.io-client:2.1.0') {
        exclude group: 'org.json', module: 'json'
}
```

### Glide

The Signed Call Android SDK uses a Glide library for loading the image assets on the call screen. 

To add the Glide dependency to your application, add the following line to the application module's dependency element:

```groovy
implementation 'com.github.bumptech.glide:glide:4.12.0'
```

### Work Manager

The Signed Call Android SDK uses a Work Manager dependency to process the incoming call push for the receiver. 

To add the Work Manager dependency to your application, add the following line to the dependency element of the application module:

```groovy
implementation 'androidx.work:work-runtime:2.7.1'
```

### Constraint Layout

The Signed Call Android SDK uses a Constraint Layout dependency to build a responsive UI for the call screens. 

To add the `constraintLayout` dependency to your application, add the following line to the dependency element of the application module:

```groovy
implementation 'androidx.constraintlayout:constraintlayout:2.1.3'
```

## Upgrade Java Compatibility

The Signed Call Android SDK source and target compatibility is set to Java version 8.  
To upgrade your application to target Java version 8, use the following code snippet:

```groovy
android {
	compileOptions {
		sourceCompatibility JavaVersion.VERSION_1_8
		targetCompatibility JavaVersion.VERSION_1_8
	}
}
```

After updating your `build.gradle` file, sync your project by clicking **Sync Project**.

## Initialize Signed Call Android SDK

Initialize the Signed Call Android SDK using the following `SignedCallAPI` class instance:

```java
SignedCallInitResponse signedCallInitListener = new SignedCallInitResponse() {
      @Override
      public void onSuccess() {
          //App is notified on the main thread when the Signed Call SDK is initialized
      }

      @Override
      public void onFailure(@NonNull InitException initException) {
          //App is notified on the main thread when the initialization is failed
          Log.d("SignedCall: ", "error code: " + initException.getErrorCode()
                 + "\n error message: " + initException.getMessage()
                 + "\n error explanation: " + initException.getExplanation());

          if (initException.getErrorCode() == InitException.SdkNotInitializedException.getErrorCode()) {
             //Handle this error here
          }
      }
};

//Create a Builder instance of SignedCallInitConfiguration and pass it inside the init() method
SignedCallInitConfiguration initConfiguration = new SignedCallInitConfiguration.Builder(initOptions)
         .build();

SignedCallAPI.getInstance().init(getApplicationContext(), initConfiguration, cleverTapAPI, signedCallInitListener);
```
```kotlin
val signedCallInitListener: SignedCallInitResponse = object : SignedCallInitResponse {
    override fun onSuccess() {
        //App is notified on the main thread when the Signed Call SDK is initialized
    }

    override fun onFailure(initException: InitException) {
        //App is notified on the main thread when the initialization is failed
        Log.d("SignedCall: ", "error code: " + initException.errorCode
                 + "\n error message: " + initException.message
                 + "\n error explanation: " + initException.explanation)

        if (initException.errorCode == InitException.SdkNotInitializedException.errorCode) 
        {
           //Handle this error here
        }
    }
}

//Create a Builder instance of SignedCallInitConfiguration and pass it inside the init() method
val initConfiguration = SignedCallInitConfiguration.Builder(initOptions, allowPersistSocketConnection)
    .build()

SignedCallAPI.getInstance().init(applicationContext, initConfiguration, cleverTapAPI, signedCallInitListener)
```

### `initOptions`

The `initOptions` is a JSON object that is passed inside the constructor of `SignedCallInitConfiguration.Builder` with the following properties:

[block:parameters]
{
  "data": {
    "h-0": "<p>Property</p>",
    "h-1": "<p>Description</p>",
    "h-2": "<p>Type</p>",
    "h-3": "<p>Notes</p>",
    "0-0": "`accountId`",
    "0-1": "<ul><li>Unique identity of your CleverTap account.</li><li>Available from the CleverTap dashboard.</li></ul>",
    "0-2": "String",
    "0-3": "Required",
    "1-0": "`apiKey`",
    "1-1": "<ul><li>Unique identity of your CleverTap account. </li><li>Available from the CleverTap dashboard.</li></ul>",
    "1-2": "String",
    "1-3": "Required",
    "2-0": "`cuid`",
    "2-1": "Unique identity of the user.",
    "2-2": "String",
    "2-3": "Required",
    "3-0": "`appId`",
    "3-1": "<ul><li>Application ID of the app. </li><li>Use the `BuildConfig.APPLICATION_ID` to retrieve your application ID.</li></ul>",
    "3-2": "String",
    "3-3": "Optional",
    "4-0": "`name`",
    "4-1": "<ul><li>Name of the user.</li><li> Must range between 3 and 25 characters.</li></ul>",
    "4-2": "String",
    "4-3": "Optional",
    "5-0": "`ringtone`",
    "5-1": "URL of the ringtone played on the caller's end during the outgoing call.  \n**Note**: The default ringtone plays if this parameter is not set.",
    "5-2": "String",
    "5-3": "Optional"
  },
  "cols": 4,
  "rows": 6,
  "align": [
    "left",
    "left",
    "left",
    "left"
  ]
}
[/block]


> 📘 CUID Validation Rules
> 
> The following rules apply to the `cuid` parameter:
> 
> - Must range between 5 and 50 characters.
> - Must start with either an alphabet or number.
> - Must be alphanumeric.
> - Must contain at least 1 alphabet. 
> - The name is case-sensitive. Only '\_' is allowed as a special character.
> - The `cuid` parameter cannot be of type number-number, that is, a number followed by a special character, which is again followed by another number.  
>   For example, org_25 is allowed, but 91_8899555 is not permitted.
> - Must be unique for every user.
> - Must be unique for every device to support multiple logins for the user from different devices. In such cases, the user has multiple `cuid`s. If the same CUID is associated with multiple devices, the device with the most recent SignedCall initialization is prioritized to receive the call.

The syntax for `initOptions` is as follows:

```java
JSONObject initOptions = new JSONObject();
try {
    initOptions.put("accountId", <string>);
    initOptions.put("apiKey", <string>);
    initOptions.put("cuid", <string>);
    initOptions.put("appId", <string / optional>);
    initOptions.put("name", <string / optional>);
    initOptions.put("ringtone", <string / optional>);
} catch (JSONException e) {
    e.printStackTrace();
}
```
```kotlin
val initOptions = JSONObject();
try {
    initOptions.put("accountId", <string>);
    initOptions.put("apiKey", <string>);
    initOptions.put("cuid", <string>);
    initOptions.put("appId", <string / optional>);
    initOptions.put("name", <string / optional>);
    initOptions.put("ringtone", <string / optional>);
} catch (e: JSONException) {
    e.printStackTrace();
}
```

## Set Up FCM for Signed Call

Signed Call uses the FCM routing channel to receive M2P campaign calls at the receiver's end.

> 📘 FCM Version
> 
> The minimum supported version of FCM must be v21.0.0 or above to integrate with your Android platform.

To enable the FCM channel, perform the following steps:

1. Add your FCM Server Key to the Signed Call section of the CleverTap dashboard. Skip this step if already configured.
2. Add the following code to your Application class:
   ```java
   CleverTapAPI.setSignedCallNotificationHandler(new SignedCallNotificationHandler());
   ```
   ```kotlin
   CleverTapAPI.setSignedCallNotificationHandler(SignedCallNotificationHandler())
   ```
3. Add the following code inside your `FirebaseMessagingService`:

   ```java
   public class MyFcmMessageListenerService extends FirebaseMessagingService {
       @Override
       public void onMessageReceived(RemoteMessage message){
           new CTFcmMessageHandler().createNotification(getApplicationContext(), message);
       }
   }
   ```
   ```kotlin Kotlin
   class MyFcmMessageListenerService : FirebaseMessagingService() {

       override fun onMessageReceived(message: RemoteMessage) {
           super.onMessageReceived(message)
           CTFcmMessageHandler().createNotification(applicationContext, message)
       }
   }
   ```

The setup for campaign calls via the FCM channel is now complete.

> 📘 Note
> 
> If you use the [CleverTap Listener Service](doc:android-push#section-add-clever-taps-fcm-message-listener-service) to handle push notifications, you can skip step 3. However, if both the CleverTap Listener Service and the Signed Call Android SDK are used simultaneously, it’s possible for the SDK to receive duplicate push notifications for the same VoIP call. In such cases, the SDK rejects the duplicate push, which results in the call initiator to incorrectly see the receiver as “busy on another call” — even though the receiver is still able to answer the original VoIP call.

# Configure Machine-to-Person (M2P) Feature

The Signed Call Android SDK runs a foreground service to communicate with the server before initiating a call. During this process, the SDK:

- Retrieves campaign metadata and flow details. 
- Displays a foreground notification to the user. 
- Replaces this notification with an incoming call notification once the processing is complete.

The foreground service keeps the application in a wake state, minimizing the likelihood of communication failures due to network constraints or device restrictions imposed by the Android OS or OEM.

To configure this behavior, use the `setM2PConfiguration(M2PConfiguration config)` method from the `SignedCallInitConfiguration.Builder class`. This method requires an instance of the `M2PConfiguration` class, as shown in the following code:

```java
M2PConfiguration m2pConfiguration;
try {
   M2PNotification m2pNotification = new M2PNotification(title, subtitle);
   m2pNotification.setLargeIcon(largeIcon);
   m2pNotification.setCancelCtaLabel(cancelCta);
   m2pConfiguration = new M2PConfiguration.Builder(m2pNotification)
            build();
} catch (Exception e) {
   e.printStackTrace();
}

SignedCallInitConfiguration initConfiguration = new SignedCallInitConfiguration.Builder(initOptions)
         .setM2PConfiguration(m2pConfiguration)
         .build();

SignedCallAPI.getInstance().init(getApplicationContext(), initConfiguration, cleverTapAPI, signedCallInitListener);
```
```kotlin
val m2pConfiguration: M2PConfiguration
try {
    val m2pNotification = M2PNotification(m2pTitle, m2pSubtitle)
    m2pNotification.largeIcon = m2pLargeIcon
    m2pNotification.cancelCtaLabel = cancelCta
    m2pConfiguration = M2PConfiguration.Builder(m2pNotification)
            .build()
} catch (e: Exception) {
    e.printStackTrace()
}

val initConfiguration = SignedCallInitConfiguration.Builder(initOptions)
         .setM2PConfiguration(m2pConfiguration)
         .build()

SignedCallAPI.getInstance().init(applicationContext, initConfiguration, cleverTapAPI, signedCallInitListener)
```

The following table lists the parameters passed to the `M2PNotification` instance:

| Property            | Description                                                                                                                              | Type   | Notes    |
| :------------------ | :--------------------------------------------------------------------------------------------------------------------------------------- | :----- | :------- |
| `title`             | Title text (max 65 characters).                                                                                                          | String | Required |
| `subtitle`          | Subtitle text ( max 240 characters.                                                                                                      | String | Required |
| `largeIcon`         | ID of a drawable resource.                                                                                                               | int    | Optional |
| `setCancelCtaLabel` | Serves as an alternative for manual dismissal of the notification, ensuring users have an option if it does not disappear automatically. | String | Optional |

# Set Local Branding for Call Screen

CleverTap dashboard provides a branding tool to customize the look and feel of the call screens. By default, all applications integrated with the Signed Call SDK share the same branding set on the dashboard. 

If you want each app to have a distinct branding experience, you can override the default branding from the CleverTap dashboard by setting it locally in your app. To set up the branding locally, use the `overrideDefaultBranding(SignedCallScreenBranding branding)` method exposed via the `SignedCallInitConfiguration.Builder` class to set up the branding.

```java
SignedCallScreenBranding callScreenBranding = new SignedCallScreenBranding(bgColor, fontColor, logoUrl, buttonTheme;
callScreenBranding.setShowPoweredBySignedCall(<true/false>); //set false to hide the label from VoIP call screens. Default value is true. 

SignedCallInitConfiguration initConfiguration = new SignedCallInitConfiguration.Builder(initOptions)  
      .overrideDefaultBranding(callScreenBranding)
      .build();

SignedCallAPI.getInstance().init(getApplicationContext(), initConfiguration, cleverTapAPI, signedCallInitListener);
```
```kotlin
val callScreenBranding = SignedCallScreenBranding(bgColor, fontColor, logoUrl, buttonTheme)
callScreenBranding.setShowPoweredBySignedCall(<true/false>); //set false to hide the label from VoIP call screens. Default value is true. 

val initConfiguration = SignedCallInitConfiguration.Builder(initOptions)
    .overrideDefaultBranding(callScreenBranding)
    .build()

SignedCallAPI.getInstance().init(applicationContext, initConfiguration, cleverTapAPI, signedCallInitListener)
```

The following are the parameters to override the dashboard call screen branding:

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Description",
    "h-2": "Type",
    "h-3": "Notes",
    "0-0": "`bgColor`",
    "0-1": "Background color of the call screens.",
    "0-2": "String",
    "0-3": "<li>Required.</li><li>Use any Hex color code, for example, #000000.</li>",
    "1-0": "`fontColor`",
    "1-1": "Color of the text displayed on the call screens.",
    "1-2": "String",
    "1-3": "<li>Required.</li><li>Use any Hex color code, for example, #FFFFFF.</li>",
    "2-0": "`logoUrl`",
    "2-1": "Image URL that renders on the call screens.",
    "2-2": "String",
    "2-3": "<li>Required.</li><li> Use an HTTPS URL only.</li>",
    "3-0": "`buttonTheme`",
    "3-1": "Theme for control buttons shown on the ongoing call screen (Mute, Speaker, and Bluetooth).",
    "3-2": "`SignedCallScreenBranding.ButtonTheme.LIGHT`  \nOR `SignedCallScreenBranding.ButtonTheme.DARK`",
    "3-3": "<li>Required. </li><li>The _Light_ theme represents the white color of the buttons, whereas _Dark_ is for the black color.</li>"
  },
  "cols": 4,
  "rows": 4,
  "align": [
    "left",
    "left",
    "left",
    "left"
  ]
}
[/block]


# Permission Management

The Signed Call Android SDK requires certain permissions to support VoIP call features. Some permissions are mandatory for call functionality, while others are optional but recommended for an enhanced experience.

## Notifications

Starting from Android 13 (API level 33), apps must request runtime notification permission before sending notifications.

Signed Call Android SDK uses both local and remote notifications during VoIP calls. Therefore, notification permission is required from the user to initialize the Signed Call SDK. For more information, refer to [Push Primer for Push Notification Permission](doc:signed-call-android-sdk-for-m2p-campaigns#push-primer-for-push-notification-permission).

## Read Phone State Permission

This is an optional permission. The Signed Call Android SDK uses this permission to enable busy handling of Public Switched Telephone Network (PSTN) calls. This permission determines if the receiver is available or busy on a PSTN call. CleverTap recommends you add the required handling to request the Read Phone State permission before initiating a call.

The Signed Call Android SDK exposes a `promptReceiverReadPhoneStatePermission(boolean)` method via the `SignedCallInitConfiguration.Builder` class. Pass the boolean flag as `true` to allow the Signed Call Android SDK to prompt for the read phone state permission at the receiver's end when the receiver answers the call.

```java
SignedCallInitConfiguration initConfiguration = new SignedCallInitConfiguration.Builder(initOptions)
         .promptReceiverReadPhoneStatePermission(<pass boolean here>)
         .build();

SignedCallAPI.getInstance().init(getApplicationContext(), initConfiguration, cleverTapAPI, signedCallInitListener)
```
```kotlin
val initConfiguration = SignedCallInitConfiguration.Builder(initOptions, allowPersistSocketConnection)
        .promptReceiverReadPhoneStatePermission(<pass boolean here>)
        .build()

SignedCallAPI.getInstance().init(applicationContext, initConfiguration, cleverTapAPI, signedCallInitListener)
```

> 📘 Note
> 
> When the Read Phone State permission is enabled, the SDK checks if the recipient is on another call. If so, it automatically declines the campaign, marking the recipient as busy. When this permission is disabled, the campaign enters a waiting state. The recipient still receives campaign notification and can decide whether to end their ongoing call to accept the campaign call.

## Full-Screen Intent Permission

The Signed Call Android SDK uses the [Full-Screen Intent](https://source.android.com/docs/core/permissions/fsi-limits) permission to display full-screen notifications for incoming VoIP calls when the app is not running in the foreground. This ensures a user experience similar to other VoIP-capable apps. For more information on how to declare and manage this permission in the Google Play Console, refer to [Full-Screen Intent Permission in Android 14](doc:full-screen-intent-permission-in-android-14).

## DataSync Permission

The Signed Call Android SDK uses the [FOREGROUND_SERVICE_DATA_SYNC](https://developer.android.com/about/versions/14/changes/fgs-types-required#data-sync) permission on Android to handle the received M2P campaigns by preprocessing it by running a foreground service as mentioned in the [Configure Machine-to-Person (M2P)](doc:signed-call-android-sdk-for-m2p-campaigns#configure-machine-to-person-m2p-feature) feature. For more information on how to declare and manage this permission in the Google Play Console, refer to [Google Play Console Declaration](https://developer.clevertap.com/docs/signed-call-android-sdk-permission-declaration#google-play-console-declaration).

## Bluetooth Connect Permission

This is an optional permission but is recommended for a better user experience. The Signed Call Android SDK has built-in Bluetooth management support. However, enabling this feature on Android 12 and above requires [Bluetooth Connect](https://developer.android.com/reference/android/Manifest.permission#BLUETOOTH_CONNECT) permission. 

The Signed Call Android SDK uses this permission to enable communication with the paired Bluetooth device for audio management on Android 12 onwards. To optimize the call experience, CleverTap recommends you request [ Bluetooth Connect](https://developer.android.com/reference/android/Manifest.permission#BLUETOOTH_CONNECT) permission.

## Push Primer for Push Notification Permission

The Push Primer is a local In-App notification that informs users about the context of notifications before they request notification permission.

To initialize the Signed Call Android SDK for Android 13 and above, you can enable the Push Primer using either of the following:

- [CleverTap Android SDK](doc:signed-call-android-sdk-for-m2p-campaigns#enable-push-primer-via-clevertap-android-sdk)
- [Signed Call Android SDK](doc:signed-call-android-sdk-for-m2p-campaigns#enable-push-primer-via-signed-call-android-sdk)

### Enable Push Primer via CleverTap Android SDK

To integrate notification permission management, refer to [Android Push Primer](doc:android-in-app-notifications#android-push-primer).

### Enable Push Primer via Signed Call Android SDK

The Signed Call Android SDK enables you to display Push Primer using the `promptPushPrimer(jsonObjectConfig)` method through the `SignedCallInitConfiguration.Builder` class. It ensures the initialization happens  after the user grants notification permission using Push Primer.

To configure the Push Primer:

1. Create a Push Primer configuration using the In-App campaign's Half-Interstitial or Alert template.

```java
//Creates push primer config using Half-Interstitial template
JSONObject jsonObjectConfig = CTLocalInApp.builder()
        .setInAppType(CTLocalInApp.InAppType.HALF_INTERSTITIAL)
        .setTitleText("Get Notified")
        .setMessageText("Please enable notifications on your device to use Push Notifications.")
        .followDeviceOrientation(true)
        .setPositiveBtnText("Allow")
        .setNegativeBtnText("Cancel")
        .setBackgroundColor(Constants.WHITE)
        .setBtnBorderColor(Constants.BLUE)
        .setTitleTextColor(Constants.BLUE)
        .setMessageTextColor(Constants.BLACK)
        .setBtnTextColor(Constants.WHITE)
        .setImageUrl("https://icons.iconarchive.com/icons/treetog/junior/64/camera-icon.png")
        .setBtnBackgroundColor(Constants.BLUE)
        .build();


//Creates push primer config using Alert template
JSONObject jsonObjectConfig = CTLocalInApp.builder()
        .setInAppType(CTLocalInApp.InAppType.ALERT)
        .setTitleText("Get Notified")
        .setMessageText("Enable Notification permission")
        .followDeviceOrientation(true)
        .setPositiveBtnText("Allow")
        .setNegativeBtnText("Cancel")
        .build();
```
```kotlin
//Creates push primer config using Half-Interstitial template
val jsonObjectConfig = CTLocalInApp.builder()
            .setInAppType(InAppType.HALF_INTERSTITIAL)
            .setTitleText("Get Notified")
            .setMessageText("Please enable notifications on your device to use Push Notifications.")
            .followDeviceOrientation(true)
            .setPositiveBtnText("Allow")
            .setNegativeBtnText("Cancel")
            .setBackgroundColor(Constants.WHITE)
            .setBtnBorderColor(Constants.BLUE)
            .setTitleTextColor(Constants.BLUE)
            .setMessageTextColor(Constants.BLACK)
            .setBtnTextColor(Constants.WHITE)
            .setImageUrl("https://icons.iconarchive.com/icons/treetog/junior/64/camera-icon.png")
            .setBtnBackgroundColor(Constants.BLUE)
            .build()


//Creates push primer config using Alert template
val jsonObjectConfig = CTLocalInApp.builder()
            .setInAppType(InAppType.ALERT)
            .setTitleText("Get Notified")
            .setMessageText("Enable Notification permission")
            .followDeviceOrientation(true)
            .setPositiveBtnText("Allow")
            .setNegativeBtnText("Cancel")
            .build()
```

2. Pass the Push Primer configuration within the `promptPushPrimer(jsonObjectConfig)` method of the `SignedCallInitConfiguration.Builder` class.

```java
SignedCallInitConfiguration initConfiguration = new SignedCallInitConfiguration.Builder(initOptions)
         .promptPushPrimer(jsonObjectConfig)
         .build();

SignedCallAPI.getInstance().init(getApplicationContext(), initConfiguration, cleverTapAPI, signedCallInitListener);
```
```kotlin
val initConfiguration = SignedCallInitConfiguration.Builder(initOptions)
        .promptPushPrimer(jsonObjectConfig)
        .build()

SignedCallAPI.getInstance().init(applicationContext, initConfiguration, cleverTapAPI, signedCallInitListener)
```

> 📘 Note
> 
> - The above configuration enables the Push Primer only if the device and application both target Android 13 (API level 33) or higher.
> - To obtain the result of the push notification permission request, the Signed Call SDK registers a listener. After registration, this listener continues monitoring the permission result, even if the Push Primer prompt is displayed from the CleverTap Android SDK.
> - If the user denies permission, the Signed Call Android SDK returns `InitException.NotificationPermissionRequiredException` within the `onFailure(initException)` method.
> - The initialization of the Signed Call Android SDK with the Push Primer configuration mentioned above must be invoked within the `onResume` lifecycle method of the Activity.

## Handle Call Events

The Signed Call Android SDK provides the `SCCallOptions` class which encapsulates the information for M2P (Machine-to-Person) calls to handle the callback events.

To implement these changes, register the listener using the following code:

```java
SignedCallAPI.getInstance().registerVoIPCallStatusListener(new SCVoIPCallStatusListener() {
    @Override
    public void callStatus ( final  SCCallStatusDetails callStatusDetails){
        //App is notified on the main thread to notify the changes in the call-state
        Log.d(LOG_TAG, "callStatus is invoked with: " + callStatusDetails.toString());

        VoIPCallStatus callStatus = callStatusDetails.getCallStatus();
        SCCallOptions callOptions = callStatusDetails.getCallOptions();
  
            M2PCallOptions m2PCallOptions = (M2PCallOptions) callOptions;
            if (callStatus == VoIPCallStatus.DTMF_INPUT_RECEIVED) {
                // When a DTMF input is received from M2P keypad screen
                DTMFInput dtmfInput = m2PCallOptions.getDTMFInput();
                if (dtmfInput != null) {
                    Toast.makeText(this, dtmfInput.getInputKey() + " is pressed!", Toast.LENGTH_SHORT).show();
                }
            } else if (callStatus == VoIPCallStatus.CALL_IS_PLACED) {
                // When the call is successfully placed
            } else if (callStatus == VoIPCallStatus.CALL_DECLINED) {
                // When the call is declined from the receiver's end
            } else if (callStatus == VoIPCallStatus.CALL_MISSED) {
                // When the call is missed at the receiver's end
            } else if (callStatus == VoIPCallStatus.CALL_ANSWERED) {
                // When the call is picked up by the receiver
            } else if (callStatus == VoIPCallStatus.CALL_IN_PROGRESS) {
                // When the connection to the receiver is established
            } else if (callStatus == VoIPCallStatus.CALL_OVER) {
                // When the call has been disconnected
                List<DTMFInput> dtmfInputList = m2PCallOptions.getDtmfInputList();
                if (dtmfInputList != null) {
                    Toast.makeText(this, "list of DTMF inputs: " + dtmfInputList.size(), Toast.LENGTH_SHORT).show();
                }
            } else if (callStatus == VoIPCallStatus.CALL_CANCELLED_DUE_TO_CAMPAIGN_NOTIFICATION_CANCELLED) {
                // When the M2P call is cancelled by clicking on cancel CTA from campaign's notification
            } else if (callStatus == VoIPCallStatus.CALLEE_BUSY_ON_ANOTHER_CALL) {
                // When the receiver is busy on another call(includes both VoIP or PSTN)
            } else if (callStatus == VoIPCallStatus.CALL_DECLINED_DUE_TO_LOGGED_OUT_CUID) {
                // When the receiver's cuid is logged out and logged in with different cuid  
            } else if (callStatus == VoIPCallStatus.CALL_DECLINED_DUE_TO_NOTIFICATIONS_DISABLED) {
                // When the receiver's Notifications Settings are disabled from application settings
     }
});
```
```kotlin
SignedCallAPI.getInstance().registerVoIPCallStatusListener(object : SCVoIPCallStatusListener {
    override fun callStatus(callStatusDetails: SCCallStatusDetails) {
        //App is notified on the main thread to notify the changes in the call-state
        Log.d(LOG_TAG, "callStatus is invoked with: ${callStatusDetails.toString()}")

        val callStatus: VoIPCallStatus = callStatusDetails.callStatus
        val callOptions: SCCallOptions = callStatusDetails.callOptions

            val m2PCallOptions = callOptions as M2PCallOptions
            when (callStatus) {
                VoIPCallStatus.DTMF_INPUT_RECEIVED -> {
                    // When a DTMF input is received from M2P keypad screen
                    val dtmfInput: DTMFInput? = m2PCallOptions.dtmfInput
                    dtmfInput?.let {
                        Toast.makeText(this, "${it.inputKey} is pressed!",Toast.LENGTH_SHORT)
                
            .show()
                }
                }
                VoIPCallStatus.CALL_IS_PLACED  -> {
                    // When the call is successfully placed
                }
                VoIPCallStatus.CALL_DECLINED -> {
                    // When the call is declined from the receiver's end
                }
                VoIPCallStatus.CALL_MISSED -> {
                    // When the call is missed at the receiver's end
                }
                VoIPCallStatus.CALL_ANSWERED -> {
                    // When the call is picked up by the receiver
                }
                VoIPCallStatus.CALL_IN_PROGRESS -> {
                    // When the connection to the receiver is established
                }
                VoIPCallStatus.CALL_OVER -> {
                    // When the call has been disconnected
                    val dtmfInputList: List<DTMFInput>? = m2PCallOptions.dtmfInputList
                    dtmfInputList?.let {
                        Toast.makeText(this, "list of DTMF inputs: ${it.size}", 
                    Toast.LENGTH_SHORT)
                .show()
                }
            }
        
                VoIPCallStatus.CALL_CANCELLED_DUE_TO_CAMPAIGN_NOTIFICATION_CANCELLED -> {
                    // When the M2P call is cancelled by clicking on cancel CTA from campaign's notification
                }
                VoIPCallStatus.CALLEE_BUSY_ON_ANOTHER_CALL -> {
                    // When the receiver is busy on another call (includes both VoIP or PSTN)
                }
                VoIPCallStatus.CALL_DECLINED_DUE_TO_LOGGED_OUT_CUID -> {
                    // When the receiver's CUID is logged out and logged in with different CUID
                }
                VoIPCallStatus.CALL_DECLINED_DUE_TO_NOTIFICATIONS_DISABLED -> {
                    // When the receiver's Notifications Settings are disabled from application settings
                
            }
        }
    }
})

```

# Log Out Signed Call Android SDK

When the Signed Call Android SDK initializes, it maintains the `init` configuration in a local session. Use the `logout(context)` method to reset the active session and disable the Signed Call functionality (call initiation and reception).  
To log out of the Signed Call Android SDK:

```java
SignedCallAPI.getInstance().logout(getApplicationContext());
```
```kotlin
SignedCallAPI.getInstance().logout(applicationContext)
```

# Debugging

Signed Call Android SDK logs are, by default, set to the `SignedCallAPI.LogLevel.INFO` level. CleverTap recommends you set the Signed Call Android SDK to VERBOSE mode to log warnings or other important messages to the Android logging system during development. To do so, set the debug level to `SignedCallAPI.LogLevel.VERBOSE`. To disable the Signed Call Android SDK logs for the production environment, you can set the debug level to `SignedCallAPI.LogLevel.OFF`.

To debug your application with the Signed Call Android SDK:

1. Set the debug level for the Signed Call Android SDK.

```java
SignedCallAPI.setDebugLevel(SignedCallAPI.LogLevel.INFO);    //Default Log level

SignedCallAPI.setDebugLevel(SignedCallAPI.LogLevel.DEBUG);   //Set Log level to DEBUG log warnings or other important messages

SignedCallAPI.setDebugLevel(SignedCallAPI.LogLevel.VERBOSE); //Set Log level to VERBOSE

SignedCallAPI.setDebugLevel(SignedCallAPI.LogLevel.OFF);     //Switch off the logs for Production environment
```
```kotlin
SignedCallAPI.setDebugLevel(SignedCallAPI.LogLevel.INFO)    //Default Log level

SignedCallAPI.setDebugLevel(SignedCallAPI.LogLevel.DEBUG)   //Set Log level to DEBUG log warnings or other important messages

SignedCallAPI.setDebugLevel(SignedCallAPI.LogLevel.VERBOSE) //Set Log level to VERBOSE

SignedCallAPI.setDebugLevel(SignedCallAPI.LogLevel.OFF)     //Switch off the logs for Production environment
```

2. Search for **[CT]\:[SignedCall]** after setting the debug level to `SignedCallAPI.LogLevel.VERBOSE`. The logcat window displays the handshakes between the Signed Call Android SDK and your application.

# Error Handling

The Signed Call Android SDK provides error reporting and handling. The `onFailure(InitException)` of the `SignedCallInitResponse` reports all the initialization-related errors.

## Initialization Errors

The following is the list of the error objects that you may receive when initializing the Signed Call Android SDK:

| Error Object                            | Error Code | Error Description                                                        |
| :-------------------------------------- | :--------- | :----------------------------------------------------------------------- |
| NoInternetException                     | 1000       | No internet connection.                                                  |
| AppContextRequiredException             | 2000       | The application context is missing.                                      |
| CleverTapApiInstanceRequiredException   | 2001       | The `CleverTapApi` instance is missing.                                  |
| InitConfigRequiredException             | 2002       | The `initOptions` is missing.                                            |
| SdkNotInitializedException              | 2003       | The Signed Call Android SDK is not initialized.                          |
| MissingAccountIdOrApiKeyException       | 2004       | The `accountId` and `apiKey` parameters are missing.                     |
| MissingCuIdException                    | 2005       | The `cuid` is missing.                                                   |
| InvalidCuidLengthException              | 2006       | The `cuid` length is invalid.                                            |
| InvalidCuidException                    | 2007       | Invalid `cuid` due to violation of valid `cuid` rules.                   |
| InvalidNameLengthException              | 2008       | The length of the `name` parameter is invalid.                           |
| InvalidAppIdException                   | 2009       | The `appId` is invalid.                                                  |
| InvalidBrandingConfigException          | 2010       | The branding configuration is invalid.                                   |
| NotificationPermissionRequiredException | 2013       | The notification permission was not given during the SDK initialization. |
| FCMTokenMissingException                | 2014       | FCM token is missing. Please try again                                   |

# FAQs

### Is Signed Call `accountId` and `apiKey` the same as CleverTap `accountId` and `token`?

No. Signed Call `accountId` and `apiKey` is different from CleverTap `accountId` and `token.` You can find these details in your dashboard's [Signed Call Settings](https://docs.clevertap.com/docs/signed-call#set-up-signed-call-integration).

### Does the Signed Call Android SDK support In-App calls over Bluetooth?

Yes. The Signed Call Android SDK has built-in Bluetooth support. It requires a runtime [BLUETOOTH_CONNECT](https://developer.android.com/reference/android/Manifest.permission#BLUETOOTH_CONNECT) permission for Android 12 and above.
