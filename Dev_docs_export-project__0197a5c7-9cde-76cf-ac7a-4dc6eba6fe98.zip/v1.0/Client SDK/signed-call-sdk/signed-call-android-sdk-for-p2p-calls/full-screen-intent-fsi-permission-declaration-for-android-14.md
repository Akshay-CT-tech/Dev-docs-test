---
title: "Full-Screen Intent Permission in Android 14"
slug: "full-screen-intent-fsi-permission-declaration-for-android-14"
excerpt: "Learn how to declare Full-Screen Intent (FSI) permission in Android 14."
hidden: true
createdAt: "Thu Aug 22 2024 12:13:54 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 03 2025 10:17:55 GMT+0000 (Coordinated Universal Time)"
---
# Overview

When targeting Android 14 with the Signed Call™ Android SDK, Google Play Console now mandates a declaration for using the _Full-Screen Intent (FSI)_ permission. Unlike previous versions of Android, where this permission was automatically granted, you must explicitly declare the usage before submitting the app to the Play Store. The Google team then evaluates your declaration and determines whether to approve or reject the app build.

For more information, refer to  [Full-Screen Intent Limits](https://source.android.com/docs/core/permissions/fsi-limits).

# FSI Permission Usage

The Signed Call Android SDK utilizes the FSI permission to display full-screen notifications for incoming VoIP calls when the app is not running in the foreground, ensuring a user experience comparable to other VoIP-capable apps.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/04a925d3b4741aa83d8c4e38dd674d6ed63cb4ce105afffa221c9707a97f1d0d-fsi_declaration_page.png",
        "",
        "FSI Declaration "
      ],
      "align": "center",
      "border": true,
      "caption": "FSI Declaration "
    }
  ]
}
[/block]


# Methods to Declare FSI Permission Usage

The following are the two ways to declare FSI Permission Usage:

- [Method 1: Opt for _Making and receiving calls_ category](doc:full-screen-intent-permission-in-android-14#opt-for-making-and-receiving-calls-category)
- [Method 2: Opt for _Other_ category](doc:full-screen-intent-permission-in-android-14#opt-for-other-category)

## Opt for Making and Receiving Calls Category

To declare FSI Permission Usage using the _Making and receiving calls_ option:

1. Select the _Making and receiving calls_ option in the _About your app_ section.
2. When prompted, choose ‘Yes’ for Install behavior.
3. Save your changes and submit them for review.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0e5f7a312531e6b66995d4dc63e1489c463c4552cf2c1d96e58aadff3fa63e45-opt_1.png",
        "",
        "App behavior"
      ],
      "align": "center",
      "border": true,
      "caption": "App Behavior"
    }
  ]
}
[/block]


> 📘 Best Practices
> 
> - If you are planning to release your app with the Signed Call SDK, CleverTap recommends creating a release in the internal test track with the build at least one week before the planned release date, and follow the steps listed in this section.
> - If your application is rejected, you can appeal the decision.

## Opt for Other Category

To declare FSI Permission Usage using the _Other_ option:

1. Select _Other_ option from the _About your app_ section.
2. Save your changes and submit them for review. The Google team usually takes about 24 hours to review the changes.

> 📘 Best Practices
> 
> - If your app release is time-sensitive and you want to avoid potential rejections, opt for Option 2.
> - After the release is live in production, you can change the Full-screen intent permission preferences anytime by navigating to _App Content > Actioned Declarations > Full-screen intent._

# App Rejection

If the Google team cannot verify that the FSI permission is used for the VoIP call feature, they may reject your build. In such cases, you will receive an app rejection email. The following image represents a Sample Rejection Email.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/67dc19e761292e8450c6a742d675ded0d0f6d63621e3fb5bced4027ecc9fc994-rejection.png",
        "",
        "Sample Rejection Mail."
      ],
      "align": "center",
      "border": true,
      "caption": "Sample Rejection Email"
    }
  ]
}
[/block]


## Address App Rejection

To address the app rejection, follow the steps listed in the rejection email:

1. **Create a Recording**  
   Create a video demonstrating the exact process of receiving a call, highlighting the Signed Call functionality. Clearly indicate the part of the app where the VoIP call is initiated. This will help the Google team understand how the _Full-screen Intent_ permission is utilized for the VoIP feature.
2. **Submit the Recording **  
   Provide the video link along with a brief description of the flow shown in the video. Explain how revoking the _Full-screen Intent_  permission could negatively impact your users. Submit this information in response to the rejection email.
3. **Google Team Review**  
   The Google team will review your submission. If they approve your request, follow _Step 2_ included in the rejection email, to upload the build and send it for review.

# SDK Behavior Demonstration

- [Video Demonstrating SDK Behavior When Permission is Granted](https://drive.google.com/file/d/1u2V722njpGjlwnjDk2lkWwpyl33xf66i/view?usp=drive_link)
- [Video Demonstrating SDK Behavior When Permission is Not Granted](https://drive.google.com/file/d/1KH1Tme_mGqJb1I-7G8KHcRZ6C6aEjX2L/view?usp=drive_link)
