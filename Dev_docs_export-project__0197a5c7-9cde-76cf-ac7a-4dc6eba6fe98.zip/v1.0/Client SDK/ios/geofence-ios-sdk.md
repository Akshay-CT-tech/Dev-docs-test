---
title: "iOS Geofence SDK"
slug: "geofence-ios-sdk"
excerpt: ""
hidden: false
createdAt: "Thu Sep 15 2022 15:26:12 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:43 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://developer.clevertap.com/docs/geofence-ios"
---
