---
title: "CleverTap Expo Plugin"
slug: "clevertap-expo-plugin"
excerpt: "Learn how to integrate the CleverTap SDK into your Expo React Native application."
hidden: false
createdAt: "Thu Apr 03 2025 10:48:10 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon May 26 2025 11:44:15 GMT+0000 (Coordinated Universal Time)"
---
# Overview

The CleverTap Expo Plugin enables developers to integrate CleverTap’s powerful user engagement features into React Native apps using Expo without modifying native code.

This is ideal for teams using Expo’s managed workflow who want to avoid ejecting their app while still leveraging the CleverTap SDK to deliver personalized messaging, analytics, and user segmentation.

Before starting, refer to [Expo Plugin Quick Start Guide](doc:expo-plugin-quick-start-guide) for more details.

> 📘 Public Beta
> 
> This feature is released in Public Beta. it is fully functional, and we are actively fine-tuning it based on your feedback to ensure the best experience.
> 
> For questions or to report issues, refer to the [CleverTap Developer Documentation](doc:getting-started) or contact our Support team via the Support section in the CleverTap Dashboard.

# Prerequisites

Ensure you have the following prerequisites to integrate CleverTap Expo Plugin with your app:

- CleverTap account
- Integrated Development Environment (IDE) for React Native development, such as VS Code, Atom, or WebStorm

# Supported Versions

To ensure smooth integration of the CleverTap Expo plugin, please reference the following compatibility matrix. This table outlines the supported versions of CleverTap Expo Plugin, Expo SDK, React Native, and the CleverTap React Native SDK that work together effectively.

| CleverTap Expo Plugin Version | Expo SDK Version | React Native Version | CleverTap React Native SDK Version |
| ----------------------------- | ---------------- | -------------------- | ---------------------------------- |
| 0.0.2                         | 52.0.0           | 0.77                 | 3.2.0                              |

# Expo Plugin Size

The following table outlines the code size for the current version of the CleverTap Expo Plugin:

| Plugin                | Version | Code Size |
| :-------------------- | :------ | :-------- |
| CleverTap Expo Plugin | 0.0.2   | 254 KB    |

# Integrate the CleverTap Expo Plugin

Follow these steps to integrate the CleverTap Expo Plugin into your application:

| Steps  | Procedure                                                                                      |
| :----- | :--------------------------------------------------------------------------------------------- |
| Step 1 | [Set Up CleverTap in Expo App](doc:expo-plugin-quick-start-guide#set-up-clevertap-in-expo-app) |
| Step 2 | [Android Integration](doc:expo-plugin-quick-start-guide#android-specific-configuration)        |
| Step 3 | [iOS Integration](doc:expo-plugin-quick-start-guide#ios-specific-configuration)                |

> 📘 Note:
> 
> These steps are detailed in the [Expo Plugin Quick Start Guide](doc:expo-plugin-quick-start-guide). Refer to it for complete instructions and examples.

# CleverTap Expo Plugin Resources

The following table lists resources to support your integration and testing efforts:

| Resources                                                                                    | Description                                                                          |
| :------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------- |
| [CleverTap Expo Plugin](https://github.com/CleverTap/clevertap-expo-plugin)                  | Provides source code and documentation for the plugin.                               |
| [Sample Application](https://github.com/CleverTap/clevertap-expo-plugin/tree/main/CTExample) | A sample working app that demonstrates the integration of the CleverTap Expo Plugin. |
| [Go Live Checklist](doc:go-live-checklist)                                                   | Lists critical steps to complete before launching your application.                  |
| [Changelog](doc:changelog)                                                                   | Details of recent SDK updates, new features, and bug fixes.                          |

# Additional References

Refer to the following for additional CleverTap Expo Plugin references:

- [CleverTap React Native SDK](doc:react-native)
- [CleverTap Expo Plugin on npm](https://www.npmjs.com/package/@clevertap/clevertap-expo-plugin)
