---
title: "Google Tag Manager"
slug: "google-tag-manager"
excerpt: ""
hidden: false
createdAt: "Mon Aug 22 2022 10:49:21 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:42 GMT+0000 (Coordinated Universal Time)"
---
Google Tag Manager, a free and simple tag management system, allows businesses to deploy and update marketing tags and tracking pixels on their website or mobile app without modifying the code.

After adding a small segment of Tag Manager code to the project, businesses can safely and quickly deploy analytics and measurement tag configurations from a web-based user interface.

To learn more about GTM, watch the following video that highlights the key features of GTM: 

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2F9A-i7EWXzjs%3Ffeature%3Doembed%26start%3D1&display_name=YouTube&url=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D9A-i7EWXzjs&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2F9A-i7EWXzjs%2Fhqdefault.jpg&key=f2aa6fc3595946d0afc3d76cbbd25dc3&type=text%2Fhtml&schema=youtube\" width=\"854\" height=\"480\" scrolling=\"no\" title=\"YouTube embed\" frameborder=\"0\" allow=\"autoplay; fullscreen\" allowfullscreen=\"true\"></iframe>",
  "url": "https://www.youtube.com/watch?v=9A-i7EWXzjs",
  "title": "Key Features of Google Tag Manager",
  "favicon": "https://www.google.com/favicon.ico",
  "image": "https://i.ytimg.com/vi/9A-i7EWXzjs/hqdefault.jpg",
  "provider": "youtube.com",
  "href": "https://www.youtube.com/watch?v=9A-i7EWXzjs"
}
[/block]


You can use GTM to send data from your website and mobile apps to your CleverTap account.  
Here are some quick links to get you started:

- [Android App Integration](https://developer.clevertap.com/docs/gtm-android)
- [iOS App Integration](https://developer.clevertap.com/docs/gtm-ios)
- [Website Integration](https://developer.clevertap.com/docs/gtm-web)
