---
title: "SDK Endpoints"
slug: "sdk-endpoints"
excerpt: ""
hidden: false
createdAt: "Tue Aug 17 2021 12:29:11 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:42 GMT+0000 (Coordinated Universal Time)"
---
CleverTap SDK uses domains and sub-domains of the following endpoints:

- wzrkt.com
- clevertap-prod.com

> 📘 Note
> 
> For CleverTap iOS SDK 3.10.0 and above, we have changed the endpoint from _wzrkt.com_ to _clevertap-prod.com_.
