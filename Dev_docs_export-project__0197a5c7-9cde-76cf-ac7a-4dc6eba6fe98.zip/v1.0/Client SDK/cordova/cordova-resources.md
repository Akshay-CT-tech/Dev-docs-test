---
title: "Cordova Resources"
slug: "cordova-resources"
excerpt: "View our sample app, usage document, and changelog for Cordova."
hidden: false
createdAt: "Mon Dec 13 2021 14:06:44 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:42 GMT+0000 (Coordinated Universal Time)"
---
# Sample Apps

To see how to use the CleverTap SDK in your app, refer to the following example projects:

- [Starter Cordova project](https://github.com/CleverTap/clevertap-cordova/blob/master/Samples/Cordova/ExampleProject/www/js/index.js)
- [Starter Ionic project](https://github.com/CleverTap/clevertap-cordova/blob/master/Samples/IonicCordova/IonicAngularProject/src/app/app.component.ts)
- [Starter Ionic Capacitor Angular](https://github.com/CleverTap/clevertap-cordova/blob/master/Samples/IonicCapacitorAngular/src/app/app.component.ts)

# Changelog

Refer to the [CleverTap Cordova SDK Change Log](https://github.com/CleverTap/clevertap-cordova/blob/master/CHANGELOG.md).
