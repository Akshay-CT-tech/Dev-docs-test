---
title: "SDKs"
slug: "clevertap-sdks"
excerpt: ""
hidden: false
createdAt: "Tue Jan 09 2018 15:54:09 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:42 GMT+0000 (Coordinated Universal Time)"
---
## Overview

CleverTap's mobile and web SDKs provide the capability to integrate CleverTap into your mobile apps and websites. The server-side libraries make it easy to call the CleverTap API. This page lists CleverTap’s official mobile and web SDKs, server-side libraries, partner integrations, and community-supported projects. 

> 📘 GDPR Compliance
> 
> The current version of CleverTap's iOS and Android SDKs are GDPR compliant. 
> 
> Please review [the GDPR compliance SDK updates](https://developer.clevertap.com/docs/sdk-changes-for-gdpr-compliance) which describe the changes you need to make for GDPR compliance to the installation of the Android and iOS SDKs in your application.

# Mobile SDKs

The following list provides a list of GitHub repositories for mobile SDKs:

## Android

- [Android SDK GitHub repo](https://github.com/CleverTap/clevertap-android-sdk)
- [Android SDK direct download link](https://github.com/CleverTap/clevertap-android-sdk/releases/download/core-v4.0.1/clevertap-android-sdk-4.0.1.aar)

## Cordova

- [Cordova SDK GitHub repo](https://github.com/CleverTap/clevertap-cordova)

## Flutter

- [Flutter SDK GitHub repo](https://github.com/CleverTap/clevertap-flutter)

## iOS

- [iOS SDK GitHub repo](https://github.com/CleverTap/clevertap-ios-sdk)
- [iOS SDK direct download link](https://github.com/CleverTap/clevertap-ios-sdk/archive/3.7.0.zip)

## KaiOS

- [Firefox OS SDK](https://github.com/CleverTap/clevertap-fxos)

## React Native

- [React Native SDK GitHub repo](https://github.com/CleverTap/clevertap-react-native)

## Unity

- [Unity SDK GitHub repo](https://github.com/CleverTap/clevertap-unity-sdk)

# Web SDK

This section covers the web SDK.

## JavaScript

- Installation instructions are in the [Web Quick Start Guide](doc:web-quickstart-guide). 

# Partner Integrations

This section covers partner integrations. 

## CleverTap/Segment Android Integration

- [CleverTap/Segment Android Integration GitHub repo](https://github.com/CleverTap/clevertap-segment-android)

## CleverTap/Segment iOS Integration

- [CleverTap/Segment iOS Integration GitHub repo](https://github.com/CleverTap/clevertap-segment-ios)

# Server-Side Libraries and Examples

This section covers server-side libraries and examples.

## Node.js

- [CleverTap API Node Wrapper](https://github.com/CleverTap/clevertap-node)

## Python

- [CleverTap API Python Wrapper](https://github.com/CleverTap/clevertap-server-api-examples)
- [CSV Upload of User Profile and Events](https://github.com/CleverTap/clevertap-csv-upload)
- [CSV Download of User Profile and Events](https://github.com/CleverTap/clevertap-csv-download)

# Community-Built Libraries

This section covers community-built libraries.

## Ruby

- [CleverTap API Ruby Wrapper built by Tradeo](https://github.com/tradeo/clevertap-ruby)
