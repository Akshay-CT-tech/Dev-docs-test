---
title: "Unity Advanced Features"
slug: "unity-advanced-features"
excerpt: "Learn how to enable debugging, personalization, GDPR controls, and native display units using CleverTap’s Unity SDK."
hidden: false
createdAt: "Mon May 02 2022 10:11:31 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 04 2025 23:17:34 GMT+0000 (Coordinated Universal Time)"
---
# Advanced Features

Access advanced configuration options in the CleverTap Unity SDK to fine-tune logging, event tracking, personalization, attribution, and privacy settings.

This document covers Unity SDK features that help enhance:

- [Debugging](doc:unity-advanced-features#debugging): Diagnose SDK activity during development.
- [Native Display](doc:unity-advanced-features#native-display): Track and render In-App banners or cards.
- [App Personalization](doc:unity-advanced-features#app-personalization): Deliver tailored experiences to users.
- [Install Attribution](doc:unity-advanced-features#install-attribution): Measure campaign effectiveness using UTM data.
- [GDPR Controls](doc:unity-advanced-features#gdpr-controls): Manage data privacy and opt-out preferences.

## Debugging

Enable CleverTap’s DEBUG mode during development to log SDK activity and troubleshoot integration issues. You can control this by setting the debug level as shown below.

### Set Debug Level

Set the debug level to control the verbosity of CleverTap logs during development:

- `-1`: Disables all debugging. You can set the `debugLevel` to -1 if you want to disable CleverTap logs for the production environment.
- `0`: Default, shows minimal SDK integration related logging.
- `2`: Shows debug output.
- `3`: Shows verbose output.

```csharp
CleverTap.SetDebugLevel(debugLevel);
```

> 🚧 Platform Specific Logs
> 
> To view SDK logs when the app is in the killed state, refer to:
> 
> - For Android platform, refer to [Android Debugging](doc:android-advanced-features#debugging).
> - For iOS platform, refer to [iOS Debugging](doc:advanced-options-ios#debugging).

## Native Display

Native Display Units are customizable In-App banners or cards triggered by user behavior or campaign logic.

### On Display Units Loaded

Registers a callback to listen for when Native Display Units are loaded from CleverTap.

```csharp
CleverTap.addListener(CleverTap.CleverTapDisplayUnitsLoaded, (event) => {
        _handleCleverTapDisplayUnitsLoaded(CleverTap.CleverTapDisplayUnitsLoaded, event);
    });

function _handleCleverTapDisplayUnitsLoaded(eventName, event) {
    console.log('CleverTap Display Unit Event - ', eventName, event);
}
```

### Get All Display Units

Fetches all available Native Display Units currently loaded in the app session.

```csharp
function _handleCleverTapDisplayUnitsLoaded(eventName, event) {
    console.log('CleverTap Display Unit Event - ', eventName, event);
    CleverTap.getAllDisplayUnits((err, res) => {
        console.log('All Display Units: ', res, err);
    });
}
```

### Display Unit Viewed Event for ID

Tracks when a specific Native Display Unit is viewed by the user.

```csharp
CleverTap.pushDisplayUnitViewedEventForID('Display Unit Id');
```

### Display Unit Clicked Event for ID

Tracks when a specific Native Display Unit is clicked by the user. Use this method to track engagement if your app uses a custom UI to render display units.

```csharp
CleverTap.pushDisplayUnitClickedEventForID('Display Unit Id');
```

## App Personalization

Enable or disable user-level personalization based on CleverTap recommendations and segmentation.

### Enable Personalization

Activates CleverTap’s personalization engine to tailor content and recommendations for the user.

```csharp
CleverTap.enablePersonalization();
```

### Disable Personalization

Turns off personalized recommendations and message targeting for the current user.

```csharp
CleverTap.disablePersonalization();
```

> 📘 Note
> 
> Toggle this setting after login, logout, or consent updates.

## Install Attribution

Track install attribution using UTM parameters to measure the effectiveness of acquisition campaigns.

### Push Install Referrer

Pass campaign parameters (source, medium, campaign) to attribute installs accurately.

```csharp
CleverTap.pushInstallReferrer("source", "medium", "campaign");
// Call this after capturing campaign parameters using attribution SDKs like InstallReferrerClient for Android.
```

## GDPR Controls

Manage user privacy preferences to comply with GDPR and related data regulations.

### Set Opt Out

Allows users to opt out of CleverTap tracking by disabling data collection.

```csharp
CleverTap.setOptOut(true); ///Will opt out the user to send data to CleverTap
CleverTap.setOptOut(false); ///Will opt in the user to send data to CleverTap
```

### Enable Device Networking Info Reporting

Control whether network-related device info (for example, carrier, connection type) is sent to CleverTap.

```csharp
// Will opt out the user to send Device Network data to CleverTap
CleverTap.enableDeviceNetworkInfoReporting(false);
// Will opt in the user to send Device Network data to CleverTap
CleverTap.enableDeviceNetworkInfoReporting(true);
```

### Set Offline

Temporarily disables CleverTap networking while preserving user actions locally.

```csharp
// Will set the user online
CleverTap.setOffline(false);
// Will set the user offline
CleverTap.setOffline(true);
```
