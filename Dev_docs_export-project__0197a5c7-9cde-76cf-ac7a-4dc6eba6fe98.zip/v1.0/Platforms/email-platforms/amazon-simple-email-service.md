---
title: "Amazon Simple Email Service"
slug: "amazon-simple-email-service"
excerpt: ""
hidden: false
createdAt: "Mon Sep 03 2018 05:50:24 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:42 GMT+0000 (Coordinated Universal Time)"
type: "link"
link_url: "https://docs.clevertap.com/docs/amazon-simple-email-service"
---
