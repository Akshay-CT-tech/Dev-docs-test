---
title: "RudderStack"
slug: "rudderstack"
excerpt: "Customer Data Platforms"
hidden: false
createdAt: "Tue Oct 25 2022 11:01:39 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jan 20 2025 10:18:03 GMT+0000 (Coordinated Universal Time)"
---
RudderStack, a customer data platform for developers, helps you deploy efficient pipelines to collect customer data and send it to your warehouse, business, and marketing tools. CleverTap supports integrating your app with RudderStack and making the most of both platforms. This section provides information about the following:

- [RudderStack Native Android Integration](doc:rudderstack-in-android) 
- [RudderStack Native iOS Integration](doc:rudderstack-in-ios) 
- [RudderStack React Native Integration](doc:clevertap-rudderstack-react-native-integration)
