---
title: "Coupon APIs"
slug: "coupon-apis"
excerpt: "Learn how to seamlessly enable coupon functionality using CleverTap's Coupon APIs."
hidden: false
createdAt: "Wed Feb 26 2025 13:31:21 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jun 12 2025 09:24:08 GMT+0000 (Coordinated Universal Time)"
---
# Overview

Coupon APIs enable businesses to seamlessly manage coupon-based promotions and discounts, enhancing customer engagement and retention. These APIs allow you to create, distribute, validate, and redeem coupons, providing a versatile framework for running targeted promotional campaigns.

For example, an e-commerce application can leverage Coupon APIs to offer personalized discounts to a customer who frequently buys electronics, such as a 10% discount coupon for their next purchase.

# Coupon APIs

The Coupon APIs suite consists of the following APIs:

- [Fetch Coupon](doc:fetch-coupon)  
- [Validate Coupon](doc:validate-coupon)  
- [Redeem/Revert Coupon](doc:redeemrevert-coupon)
