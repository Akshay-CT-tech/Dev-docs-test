---
title: "Get Wallet Details"
slug: "get-wallet-details"
excerpt: "Learn how to use the Get Wallet Details API to access user wallet information."
hidden: false
createdAt: "Wed Feb 26 2025 12:46:58 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jun 12 2025 09:24:08 GMT+0000 (Coordinated Universal Time)"
---
# Overview

The Get Wallet Details API fetches user wallet information, including the wallet balance, reward points, and pending/expired points. This API can be integrated into your application at key touch points to provide seamless access to wallet data within your application user interface.

This API is designed to offer the following two key components:

- **Wallet Definition**: Provides the following essential wallet configuration details necessary for accurate wallet identification and display within your application:
  - Wallet Name
  - Loyalty Points Name
  - Wallet ID
- **Wallet Ledger Balance**: Provides a detailed breakdown of the user's wallet activity for display within the application user interface, as follows:
  - Active Points
  - Promised Points
  - Credited Points
  - Expired Points
  - Redeemed Points

Using these insights, you can present an up-to-date and transparent view of the user's wallet activity within your application.

# Base URL

Here is an example base URL from the account in the India region:

<https://in1.api.clevertap.com/1/promo/wallets>

## Region

To identify the API endpoint for the region of your account, refer to [Region](doc:common-api-components#region).

# Headers

For more information about API headers used while processing API requests, refer to [Headers](doc:common-api-components#headers).

# HTTP Method

GET

# Query Parameters

| Parameter  | Description                                     | Type   | Sample Value | Required/Optional |
| :--------- | :---------------------------------------------- | :----- | :----------- | :---------------- |
| `identity` | Identifies the user associated with the wallet. | String | `KMN@123`    | Required          |

# Sample Request

Here is an example HTTP request to the Get Wallet Details API showing the headers needed to authenticate the request:

```http
GET /https://in1.api.clevertap.com/1/promo/wallets?identity=User-2 HTTP/1.1
Authorization: Basic {API Key: Secret Key}
```

# Sample Response

The sample request returns an array of wallet objects, as shown in the following sample JSON response:

```json
{
    "status": "success",
    "records": [
        {
            "walletId": 1000,
            "walletName": "Super wallet",
            "loyaltyPointsName": "Coin",
            "totalRedeemedPoints": 1000,
            "totalCreditedPoints": 2000,
            "activePoints": 500,
            "totalPromisedPoints": 500,
            "expiredPoints": 500
    }
  ]
}
```

On a successful API call, the system fetches the API response and provides the following response fields passed in the request body:

| Key                   | Definition                                                                                                                 | Type    | Sample Value                 |
| --------------------- | -------------------------------------------------------------------------------------------------------------------------- | ------- | ---------------------------- |
| `walletId`            | Unique wallet ID assigned by CleverTap for a specific wallet created on your CleverTap dashboard.                          | String  | `waty_XbgBcerLwjoMhAGcmAHhZ` |
| `walletName`          | Name of the wallet.                                                                                                        | String  | `Super wallet`               |
| `loyaltyPointsName`   | Name of the currency associated with the wallet.                                                                           | String  | `Coin`                       |
| `totalRedeemedPoints` | Total points redeemed from the user wallet via the [Debit Wallet API](doc:debitcredit-wallet) and the CleverTap dashboard. | Numeric | `20`                         |
| `totalCreditedPoints` | Total points rewarded to the user from all sources.                                                                        | Numeric | `20`                         |
| `activePoints`        | Current active wallet points held by a given user.                                                                         | Numeric | `40`                         |
| `totalPromisedPoints` | Total points rewarded to a user but not yet credited to the user’s wallet.                                                 | Numeric | `10`                         |
| `expiredPoints`       | Total number of unused points expired in the user's wallet.                                                                | Numeric | `5`                          |

# Errors

To know the errors applicable to the Get Wallet Details API, refer to [API Error Cases](docs:api-error-cases#wallet-api-errors).
