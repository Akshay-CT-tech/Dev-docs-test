---
title: "Get Campaign Report"
slug: "get-campaign-report-api"
excerpt: ""
hidden: false
createdAt: "Tue Jan 09 2018 16:43:21 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:43 GMT+0000 (Coordinated Universal Time)"
---
# Overview

The Get Campaign Report API lets you get campaign metrics.

To get a campaign report, you specify the id of the report needed. If the campaign has not completed yet, you will receive an error message indicating that status.

## Base URL

Here is an example base URL from the account in the India region:  
<https://in1.api.clevertap.com/1/targets/result.json>

### Region

Refer [Region](https://developer.clevertap.com/docs/common-api-components#region) for more details.

## HTTP Method

POST

## Headers

Refer [Headers](https://developer.clevertap.com/docs/common-api-components#headers) for more details.

## Body Parameter

The body is uploaded as a JSON payload.

| Parameter | Description                                                                                                                                   | Type | Example Value |
| :-------- | :-------------------------------------------------------------------------------------------------------------------------------------------- | :--- | :------------ |
| id        | CleverTap campaign id of the campaign whose metrics you want to view. You can find this id in your CleverTap dashboard under the Push section | int  | 1457432766    |

Below is an example payload.

```json
{
    "id": 1457432766
}
```

## Example Request

Here is an example cURL request to the _Get Campaign Report_ API showing the headers needed to authenticate the request from the account in the India region:

```curl
curl -X POST -d '{ "id": 1457432766}' "https://in1.api.clevertap.com/1/targets/result.json" \
-H "X-CleverTap-Account-Id: ACCOUNT_ID" \
-H "X-CleverTap-Passcode: PASSCODE" \
-H "Content-Type: application/json"
```
```ruby
require 'net/http'
require 'uri'
require 'json'

uri = URI.parse("https://in1.api.clevertap.com/1/targets/result.json")
request = Net::HTTP::Post.new(uri)
request.content_type = "application/json"
request["X-Clevertap-Account-Id"] = "ACCOUNT_ID"
request["X-Clevertap-Passcode"] = "PASSCODE"
request.body = JSON.dump({
  "id" => 1457432766
})

req_options = {
  use_ssl: uri.scheme == "https",
}

response = Net::HTTP.start(uri.hostname, uri.port, req_options) do |http|
  http.request(request)
end
```
```python
import requests

headers = {
    'X-CleverTap-Account-Id': 'ACCOUNT_ID',
    'X-CleverTap-Passcode': 'PASSCODE',
    'Content-Type': 'application/json',
}

data = '{ "id": 1457432766}'

response = requests.post('https://in1.api.clevertap.com/1/targets/result.json', headers=headers, data=data)
```
```php
<?php
include('vendor/rmccue/requests/library/Requests.php');
Requests::register_autoloader();
$headers = array(
    'X-CleverTap-Account-Id' => 'ACCOUNT_ID',
    'X-CleverTap-Passcode' => 'PASSCODE',
    'Content-Type' => 'application/json'
);
$data = '{ "id": 1457432766}';
$response = Requests::post('https://in1.api.clevertap.com/1/targets/result.json', $headers, $data);
```
```javascript Node.js
var request = require('request');

var headers = {
    'X-CleverTap-Account-Id': 'ACCOUNT_ID',
    'X-CleverTap-Passcode': 'PASSCODE',
    'Content-Type': 'application/json'
};

var dataString = '{ "id": 1457432766}';

var options = {
    url: 'https://in1.api.clevertap.com/1/targets/result.json',
    method: 'POST',
    headers: headers,
    body: dataString
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
        console.log(body);
    }
}

request(options, callback);
```

## Example Response

```json
{
    "result": {
        "clicked": 28,
        "sent": 82
    },
    "status": "success"
}
```

## Notes

If the campaign has not been completed yet, you will receive the error response below.

```json
{
    "error": "This target hasn't been completed",
    "status": "fail"
}
```

For more information on request limit, refer to [API Request Limit](doc:api-request-limit). To understand the common queries and concerns related to CleverTap APIs, refer to [API FAQs](doc:api-faqs).
