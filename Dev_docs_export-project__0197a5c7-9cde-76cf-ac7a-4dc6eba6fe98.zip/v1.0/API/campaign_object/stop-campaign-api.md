---
title: "Stop Scheduled Campaign"
slug: "stop-campaign-api"
excerpt: ""
hidden: false
createdAt: "Tue Jan 09 2018 16:43:09 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:42 GMT+0000 (Coordinated Universal Time)"
---
# Overview

The Stop Scheduled Campaign API lets you stop a scheduled/running campaign.

## Base URL

Here is an example base URL from the account in the India region:  
<https://in1.api.clevertap.com/1/targets/stop.json>

### Region

Refer [Region](https://developer.clevertap.com/docs/common-api-components#region) for more details.

## HTTP Method

POST

## Headers

Refer [Headers](https://developer.clevertap.com/docs/common-api-components#headers) for more details.

## Body Parameter

The body is uploaded as a JSON payload.

| Parameter | Description                                                                                                                       | Type | Example Value |
| :-------- | :-------------------------------------------------------------------------------------------------------------------------------- | :--- | :------------ |
| id        | CleverTap ID of the scheduled campaign you want to stop. You can find this id in your CleverTap dashboard under the push section. | int  | 1457432766    |

Below is an example payload.

```json
{
    "id": 1457432766
}
```

## Example Request

Here is an example cURL request to the _Stop Scheduled Campaign_ API showing the headers needed to authenticate the request from the account in the India region:

```curl
curl -X POST -d '{ "id": 1457432766}' "https://in1.api.clevertap.com/1/targets/stop.json" \
-H "X-CleverTap-Account-Id: ACCOUNT_ID" \
-H "X-CleverTap-Passcode: PASSCODE" \
-H "Content-Type: application/json"
```
```ruby
require 'net/http'
require 'uri'
require 'json'

uri = URI.parse("https://in1.api.clevertap.com/1/targets/stop.json")
request = Net::HTTP::Post.new(uri)
request.content_type = "application/json"
request["X-Clevertap-Account-Id"] = "ACCOUNT_ID"
request["X-Clevertap-Passcode"] = "PASSCODE"
request.body = JSON.dump({
  "id" => 1457432766
})

req_options = {
  use_ssl: uri.scheme == "https",
}

response = Net::HTTP.start(uri.hostname, uri.port, req_options) do |http|
  http.request(request)
end
```
```python
import requests

headers = {
    'X-CleverTap-Account-Id': 'ACCOUNT_ID',
    'X-CleverTap-Passcode': 'PASSCODE',
    'Content-Type': 'application/json',
}

data = '{ "id": 1457432766}'

response = requests.post('https://in1.api.clevertap.com/1/targets/stop.json', headers=headers, data=data)
```
```php
<?php
include('vendor/rmccue/requests/library/Requests.php');
Requests::register_autoloader();
$headers = array(
    'X-CleverTap-Account-Id' => 'ACCOUNT_ID',
    'X-CleverTap-Passcode' => 'PASSCODE',
    'Content-Type' => 'application/json'
);
$data = '{ "id": 1457432766}';
$response = Requests::post('https://in1.api.clevertap.com/1/targets/stop.json', $headers, $data);
```
```javascript Node.js
var request = require('request');

var headers = {
    'X-CleverTap-Account-Id': 'ACCOUNT_ID',
    'X-CleverTap-Passcode': 'PASSCODE',
    'Content-Type': 'application/json'
};

var dataString = '{ "id": 1457432766}';

var options = {
    url: 'https://in1.api.clevertap.com/1/targets/stop.json',
    method: 'POST',
    headers: headers,
    body: dataString
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
        console.log(body);
    }
}

request(options, callback);
```

## Example Response

```json
{
    "status": "success"
}
```

For more information on request limit, refer to [API Request Limit](doc:api-request-limit). To understand the common queries and concerns related to CleverTap APIs, refer to [API FAQs](doc:api-faqs).
