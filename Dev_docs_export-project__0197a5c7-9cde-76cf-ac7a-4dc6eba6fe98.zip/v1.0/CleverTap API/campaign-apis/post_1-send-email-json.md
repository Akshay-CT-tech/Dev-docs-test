---
title: "Create Campaign - Target Users by their Identities(EMAIL)"
slug: "post_1-send-email-json"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 17 2023 07:41:17 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jan 17 2023 07:41:17 GMT+0000 (Coordinated Universal Time)"
---
