---
title: "Get User Profiles by Events"
slug: "post_1-profiles-json"
excerpt: "https://developer.clevertap.com/docs/get-user-profiles-api#section-step-1-get-cursor-by-specifying-events-for-user-profiles"
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 17 2023 07:41:17 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jan 17 2023 07:41:17 GMT+0000 (Coordinated Universal Time)"
---
