---
title: "Get Cursor by Specifying Events Needed"
slug: "post_1-events-json"
excerpt: "Get Events API Step 1"
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jan 17 2023 07:41:17 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jan 17 2023 07:41:17 GMT+0000 (Coordinated Universal Time)"
---
