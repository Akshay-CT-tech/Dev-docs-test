---
title: "February 2023"
slug: "changelog-february-2023"
excerpt: ""
hidden: false
createdAt: "Thu Feb 02 2023 07:27:50 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:43 GMT+0000 (Coordinated Universal Time)"
---
We are excited to share the CleverTap SDK changelog for February!

> 📘 Note
> 
> Click each SDK header to view the corresponding GitHub repository for release details.

# February 28

## [Web 1.4.1](https://github.com/CleverTap/clevertap-web-sdk/releases/tag/v1.4.1)

- **Fixed** rendering issues for Web Native Display banner and carousel.
- **Fixed** user interface issues for Web Inbox. 

# February 27

## [Signed Call Web 0.0.3](https://www.npmjs.com/package/clevertap-signed-call)

- **Added** handling for the unregistered event on Session Initiation Protocol (SIP).
- **Added** logger for debugging.
- **Added** `sigsock` configuration from the authorization response.

# February 21

## [Signed Call iOS 0.0.2](https://github.com/CleverTap/clevertap-signedcall-ios-sdk/releases/tag/0.0.2)

- **Added** the Signed Call iOS SDK compatibility for [CleverTap iOS SDK 4.2.0](https://github.com/CleverTap/clevertap-ios-sdk/releases/tag/4.2.0) and higher versions.
- **Added** the public API `disconnectSignallingSocket()` to close the signalling socket connection. For more details, refer to [Close Socket Connection](https://developer.clevertap.com/docs/signed-call-ios-sdk#close-socket-connection).
- **Added** the _Objective-C_ language support for Signed Call iOS SDK.

## [Signed Call Flutter 0.0.2](https://github.com/CleverTap/clevertap-signedcall-flutter-sdk/releases/tag/0.0.2)

- **Added** the Signed Call Flutter SDK compatibility for [Signed Call Android SDK 0.0.2](https://repo1.maven.org/maven2/com/clevertap/android/clevertap-signedcall-sdk/0.0.2/) and [Signed Call iOS SDK 0.0.2](https://github.com/CleverTap/clevertap-signedcall-ios-sdk/releases/tag/0.0.2) versions.
- **Added** the Push Primer support for the [Android 13 notification runtime permission](https://developer.android.com/develop/ui/views/notifications/notification-permission). For more details, refer to [Android 13 Changes](doc:signed-call-flutter-sdk#android-13-changes).
- **Added** the public API `disconnectSignallingSocket()` to close the signalling socket connection. For more details, refer to [Close Socket Connection](https://developer.clevertap.com/docs/signed-call-flutter-sdk#close-socket-connection-all-platforms).
- **Fixed** the Voice over Internet Protocol (VoIP) call screen distortion issue in iOS.

# February 15

## [Signed Call Android 0.0.2](https://repo1.maven.org/maven2/com/clevertap/android/clevertap-signedcall-sdk/0.0.2/)

- **Added** the Signed Call Android SDK compatibility for [CleverTap Android SDK 4.7.4](https://github.com/CleverTap/clevertap-android-sdk/releases/tag/corev4.7.4) and higher versions.
- **Added** the public API `promptPushPrimer(jsonObject)` to support Android 13 [runtime notification permission](https://developer.android.com/develop/ui/views/notifications/notification-permission). For more details, refer to [Android 13 Changes](doc:signed-call-android-sdk#android-13-changes).
- **Added** the public API `disconnectSignallingSocket()` to close the signalling socket connection. For more details, refer to [Close Socket Connection](doc:signed-call-android-sdk#close-socket-connection).
- **Added** the support for the click action on the device's Power button. It allows you to stop the sound and vibration of incoming calls.
- **Added** support for the small icon displayed in call notifications by the Signed Call SDK. You can configure it from the `AndroidManifest.xml` file in the same way you configure it for CleverTap Android SDK. For more details, refer to [Set the Small Notification Icon](https://developer.clevertap.com/docs/android-push#set-the-small-notification-icon).
- **Added** a slight shake animation to the call accept and decline buttons.
- **Fixed** the `logout()` method issue to not use an invalidated session post re-initialization.

# February 14

## [Flutter 1.6.0](https://github.com/CleverTap/clevertap-flutter/releases/tag/1.6.0)

- **Added ** the following new push permission public APIs to support core [Android SDK v4.7.4](https://github.com/CleverTap/clevertap-android-sdk/releases/tag/corev4.7.4) and [iOS SDK v4.2.0](https://github.com/CleverTap/clevertap-ios-sdk/releases/tag/4.2.0) versions: 

  - `getPushNotificationPermissionStatus()`
  - `promptPushPrimer(object)`
  - `promptForPushNotification(boolean)`

   For more information, refer to the [Flutter Push Primer](doc:flutter-push-notification#push-primer) document.

- **Added** the `setCleverTapPushPermissionResponseReceivedHandler` push permission callback method, which returns _true_ or _false_ depending on the user's notification permissions.

- **Added** the `setCleverTapInAppNotificationShowHandler` method to handle InApp notifications for Android.

- **Updated** the format of the Native Display payload for both Android and iOS platforms.

- **Fixed** the FCM Plugin's [onBackgroundMessage handler](https://github.com/CleverTap/clevertap-flutter/commit/8db6f34eec83e7f14990359f88c65a50e966acb3) bug that failed sending the method calls from Android.
