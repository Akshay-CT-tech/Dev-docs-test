---
title: "November 2023"
slug: "november-2023"
excerpt: ""
hidden: false
createdAt: "Thu Nov 09 2023 09:09:19 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 11:56:43 GMT+0000 (Coordinated Universal Time)"
---
We are excited to share the November SDK changelog for our product!

> 📘 Note
> 
> Click each SDK header to view the corresponding GitHub repository for release details.

# November 29

## [Xamarin 3.0.0](https://github.com/CleverTap/clevertap-xamarin/releases/tag/3.0.0)

- **Added** support for Android 13.
- **Added** support for the latest [CleverTap Android SDK v5.2.1](https://github.com/CleverTap/clevertap-android-sdk/releases/tag/corev5.2.1_xpsv1.5.4).

# November 21

## [iOS 5.2.2](https://github.com/CleverTap/clevertap-ios-sdk/releases/tag/5.2.2)

**Fixed**

- **Fixed** compilation warnings while building the SDK
- **Mitigated** a potential crash when apps move to the background.

# November 9

## [Web 1.6.8](https://www.npmjs.com/package/clevertap-web-sdk)

**Added** handling for email unsubscribe.
