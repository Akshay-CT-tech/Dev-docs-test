---
title: "March 2025"
slug: "march-2025"
excerpt: ""
hidden: false
createdAt: "Tue Mar 11 2025 06:20:05 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 03 2025 10:56:22 GMT+0000 (Coordinated Universal Time)"
---
We are excited to share the March SDK changelog for our product!

> 📘 Note
> 
> Click each SDK header to view the corresponding GitHub repository for release details.

# March 31

## [Unity 5.2.0](https://github.com/CleverTap/clevertap-unity-sdk/releases/tag/5.2.0)

### Enhancements

- Supports Unity Native Variables, allowing users to define and sync variables directly within the Unity Editor and across builds. This simplifies configuration management between development and production environments.
- Enhances compatibility with Unity version 2021 for native features.

### Bug Fixes

- Fixes WebGL compatibility issues for Unity version 6000.

# March 27

## [React Native 3.4.0](https://github.com/CleverTap/clevertap-react-native/releases)

### What's New

#### Android

- Supports [CleverTap Android SDK v7.3.1](https://github.com/CleverTap/clevertap-android-sdk/blob/master/docs/CTCORECHANGELOG.md#version-731-march-27-2025).

#### iOS

- Supports [CleverTap iOS SDK v7.1.1](https://github.com/CleverTap/clevertap-ios-sdk/blob/master/CHANGELOG.md#version-711-march-17-2024).

### Important API Changes

- Adds the following new APIs to register push tokens:
  - Use `pushRegistrationToken(your_token, pushType)` to register tokens for providers other than FCM. For more information, refer to [Registering Baidu Huawei Token](https://github.com/CleverTap/clevertap-react-native/blob/3.4.0/docs/usage.md#registering-hpsbaidu-token) for example usage.
    > 🚧 Note
    > 
    > For revised integration steps on Android, refer to [Huawei Push integration](doc:clevertap-huawei-push-integration).
  - Use `setFCMPushToken(your_token)` specifically for FCM token registration. For more information, refer to [Registering FCM Token ](https://github.com/CleverTap/clevertap-react-native/blob/3.4.0/docs/usage.md#registering-fcm-token) for example usage.

- Removes the legacy API:
  - Removes `setPushToken(value, type)` to support injectable push providers. Use the updated APIs listed above instead.

## [Flutter 3.3.0](https://github.com/CleverTap/clevertap-flutter/releases)

### What's New

- Supports [CleverTap Android SDK v7.3.1](https://github.com/CleverTap/clevertap-android-sdk/blob/master/docs/CTCORECHANGELOG.md#version-731-march-27-2025).
- Adds the following new API to register to push tokens for non-FCM providers:
  - `pushRegistrationToken(String value, Map<String, String> pushType)` registers the token based on the push provider. For example usage, refer to [Registering FCM Baidu Huawei Token](https://github.com/CleverTap/clevertap-flutter/blob/3.3.0/doc/Usage.md#registering-fcm-baidu-huawei-token).
    > 🚧 Note
    > 
    > For revised integration steps on Android, refer to [Huawei Push integration](doc:clevertap-huawei-push-integration).

### Important API Changes

#### Android

- Removes the following legacy push token registration APIs to enable injectable push providers:
  - `setBaiduPushToken(String value)`
  - `setHuaweiPushToken(String value)`

## [Android 7.3.1](https://github.com/CleverTap/clevertap-android-sdk/releases/tag/corev7.3.1)

### Bug Fixes

- Fixes an issue that prevented In-App messages from displaying after the app was upgraded.

# March 20

## [Unity 5.1.0](https://github.com/CleverTap/clevertap-unity-sdk/releases/tag/5.1.0)

### What’s New

#### Android

- Adds support for setting a custom CleverTapAPI instance to iOS `CleverTapUnityManager`.
- Replaces `Handler` with `Timer` in the Android plugin for more efficient scheduling.

#### iOS

- Supports [CleverTap iOS SDK v7.1.1](https://github.com/CleverTap/clevertap-ios-sdk/releases/tag/7.1.1).
- Adds support for setting a custom CleverTap instance to Android `CleverTapUnityPlugin`.
- Adds macro to disable `UnityAppController` subclass for iOS.

### Enhancements

- Improves variable callback handling for better reliability.

# March 17

## [iOS 7.1.1](https://github.com/CleverTap/clevertap-ios-sdk/releases/tag/7.1.1)

### What's New

- Adds support for the `dismissInAppNotification` action to enable smooth dismissal of custom HTML In-App notifications.

### Bug Fixes

- Fixes an issue with device orientation checks for custom In-App notifications to ensure accurate rendering.

## [React Native 3.3.0](https://github.com/CleverTap/clevertap-react-native/releases/tag/3.3.0)

> ❗️ Upgrade Alert
> 
> We recommend upgrading to [CleverTap React Native 3.4.0](doc:march-2025#react-native-340) or above if using In-App.

### What's New

#### Android Platform

- Supports [CleverTap Android SDK v7.2.2](https://github.com/CleverTap/clevertap-android-sdk/blob/master/docs/CTCORECHANGELOG.md#version-722-january-21-2025).
- Adds support for Android 15, ensuring compliance with the latest platform requirements. For more information, refer to [Android 15](https://developer.android.com/about/versions/15/summary).
- Enhances the [encryption algorithm for PII data](https://github.com/CleverTap/clevertap-android-sdk/blob/master/docs/EXAMPLES.md#encryption-of-pii-data-), aligning it with [OWASP Mobile Application Security Guidelines](https://mas.owasp.org/MASTG/0x04g-Testing-Cryptography/). On devices running API 23 and above, the encryption key is now securely backed up using [Android Key Store](https://developer.android.com/privacy-and-security/keystore).
- Updates the ` minSdkVersion` to API 21 (Android 5.0).

> 🚧 Upgrade Help for 3.3.0
> 
> If you run into any issues during the upgrade, refer to the [troubleshooting guide](https://github.com/CleverTap/clevertap-react-native/blob/master/docs/install.md#troubleshooting-1) for step-by-step help.

# March 12

## [Web 1.13.5](https://github.com/CleverTap/clevertap-web-sdk/releases/tag/v1.13.5)

### Bug Fixes

- Adds validations to prevent errors caused by `null` values in campaign objects.  

- Addresses runtime issues affecting WebInbox functionality.  

- Skips WebInbox retries when configuration is not present to prevent unnecessary API calls.  

- Corrects inconsistencies in the custom event payload structure for Web Native Display.  

- Improves session storage validation for `WZRK_D` with fallback mechanism and error handling.

## [Signed Call Android SDK 0.0.8.0](https://repo1.maven.org/maven2/com/clevertap/android/clevertap-signedcall-sdk/0.0.8.0/)

### What's New

**Edge-to-Edge Support** 

Supports edge-to-edge enforcement introduced in Android 15, ensuring proper inset handling for the call screen.

**Custom Request ID Support** 

Adds a new public API `overrideRequestId(boolean)`, accessible via `SignedCallInitConfiguration.Builder` instance. Set this parameter to `true` to allow passing a custom `requestId` during call initiation in the overloaded `signedCallInstance.call()` method. The Request ID feature enables call grouping and unique identification of all calls within a transaction. You can pass an order ID, a transaction-specific identifier, or any other relevant ID. Additionally, the SDK supports hashes and UUIDs in the `requested` field, allowing you to hash/encrypt sensitive identifiers before passing them if required. For more information, refer to [Configure Request ID (P2P Feature)](signed-call-android-sdk#configure-request-id-p2p-feature).

**Connection Timeout Handling**

 Introduces a connection timeout mechanism during the call setup phase when a call is answered but not yet ready for voice exchange. If the timeout occurs, the SDK triggers the `VoIPCallStatus.CALL_OVER_DUE_TO_NETWORK_DELAY_IN_CONNECTION_SETUP` event in the `callStatus(SCCallStatusDetails callDetails)` callback.

### Important Changes

**Detailed Call Exceptions** 

The `CallException.ContactNotReachableException` has been split into more detailed call-specific exceptions, improving clarity for:

- Local reporting in the `onFailure(callException)` callback 
- Remote reporting in the `SCEnd` system event

### Enhancements

**Improved Event Reporting** 

Ensures that the `callId` parameter is always available within the `callStatus(callStatusDetails` callback. Since ended call callbacks are reported asynchronously while cleanup runs in the background, there may be cases where callId is unavailable due to premature cleanup. If `callStatusDetails.getCallDetails().callId` returns `Unknown`, CleverTap recommends using the `callId` from the previous callback event for consistency.

### Fixes

**Audio Routing Issue on Android 15**

Resolves an issue where calls defaulted to the loudspeaker upon answering.

**Ping Latency Tracking NPE Fix**

Fixes an issue that caused an NPE while tracking ping latency drops during an ongoing call, ensuring reliable remote tracking in the SCEnd system event.

**Foreground Service Crash on Android 10 and 11**

Fixes a `RemoteServiceException` crash that occurred when a foreground service started processing an incoming call. This issue was caused by a race condition and was reproducible when the initiator placed and immediately canceled the call.

# March 11

## [Android 7.3.0](https://github.com/CleverTap/clevertap-android-sdk/blob/master/docs/CTCORECHANGELOG.md)

> ❗️ Upgrade Alert
> 
> We recommend upgrading to [CleverTap Android SDK 7.3.1](doc:march-2025#android-731) or above if using In-App.

### Important API Changes

- **Updates Huawei Push Integration**
  - Updates Huawei Push integration process to improve reliability and simplify setup. If you have integrated CleverTap Huawei Push SDK, you must follow the new steps listed under [Huawei Push Integration](doc:clevertap-huawei-push-integration) to ensure continued functionality.
- **Updates Baidu Push Integration**  
  Updates Baidu Push integration steps for better performance. To ensure compatibility, refer to the new steps listed under [Baidu Push Integration](doc:baidu-push-notifications).
- **Updates Unified Push Registration**  
  Removes `pushBaiduRegistrationId()` and `pushHuaweiRegistrationId()` methods removed from `CleverTapAPI` to simplify push registration. Use the appropriate `PushType` constant to identify the push provider (Huawei or Baidu). For more information about implementation updates, refer to [Huawei Push Integration](doc:clevertap-huawei-push-integration) and [Baidu Push Integration](doc:baidu-push-notifications).

> ❗️ Critical Update
> 
> Migrate to `pushRegistrationToken()` to ensure Push Notifications continue to function.

### Bug Fixes

- Fixes an issue in `CleverTapAPI.getCleverTapID()` where a missing listener caused a Null Pointer Exception (NPE).
- Fixed an issue where device font size settings caused In-App message text to overflow. Messages now resize dynamically for improved layout.

## [Push Templates 1.4.0](https://github.com/CleverTap/clevertap-android-sdk/blob/master/docs/CTPUSHTEMPLATESCHANGELOG.md)

### What's new

- Supports [CleverTap Android SDK v7.3.0](doc:march-2025#android-sdk-730).

## [Huawei Push 1.5.0](https://github.com/CleverTap/clevertap-android-sdk/blob/master/docs/CTHUAWEIPUSHCHANGELOG.md)

### Important API Changes

- **Updates Huawei Push Integration**  
  The integration process for Huawei Push has been significantly updated. If you have previously integrated the CleverTap Huawei Push SDK, you must now follow the new steps outlined under [CleverTap Huawei Push Integration](doc:clevertap-huawei-push-integration) to ensure continued functionality.
- **Pluggable Huawei Push Integration**  
  Huawei Push is now available as a pluggable component, providing more flexibility and removing reliance on reflection-based initialization in the core SDK.

## [Expo 0.0.1](https://github.com/CleverTap/clevertap-expo-plugin/releases/tag/0.0.1)

> 📘 Public Beta
> 
> This feature is released in Public Beta. it is fully functional, and we are actively fine-tuning it based on your feedback to ensure the best experience.

### What’s New

- Introduces the new Expo plugin to integrate the `clevertap-react-native` SDK in Expo managed workflow apps.
- Adds support for CleverTap core features in Expo-managed environments.
- Configures native code for both Android and iOS, so no manual changes are needed.

# March 10

## [Web 1.13.4](https://github.com/CleverTap/clevertap-web-sdk/releases/tag/v1.13.4)

### What's New

- Supports preview in custom HTML templates for Web Native Display campaigns, using a `post message proxy` for seamless preview functionality.  

### Bug Fixes

- Fixes an issue where web pop-ups displayed an unintended white background, ensuring a cleaner and consistent visual experience.

## [Signed Call React Native SDK v0.8.0](https://www.npmjs.com/package/@clevertap/clevertap-signed-call-react-native/v/0.8.0)

### What's New

#### Android Platform

- Supports Signed Call Android SDK v0.0.7.7, which is compatible with CleverTap Android SDK v7.0.2.
- Adds `SignedCall.isInitialized()`, the new public API to retrieve the initialization status.
- Adds `SignedCall.dismissMissedCallNotification()`, the new public API to dismiss the missed call notification.

#### iOS Platform

Supports Signed Call iOS SDK v0.0.9, which is compatible with CleverTap iOS SDK v7.0.2 and higher.

#### Android and iOS Platform

- Migrates the bridge to a backward-compatible New Architecture Turbo Module.
- Compatible with both the Old and the New Architecture.

### Enhancements

#### Android Platform

- Addresses the limitations related to microphone access during ongoing calls when the user moves the app to the background. Google Play Console prompts you to declare the permission usage and submit a demo video link. For more information, refer to [Signed Call Android SDK permission](doc:signed-call-android-sdk-permission-declaration).
- Enforces the network quality checks during call initiation and reception and captures the network latency.

### Bug Fixes

#### Android Platform

- Fixes the [Notification trampoline restrictions](https://developer.android.com/about/versions/12/behavior-changes-12#notification-trampolines) introduced in Android 12 and above. These restrictions block activity launches from the SignedCall.SignedCallOnMissedCallActionClicked callback. The callback is triggered when clicking the missed call CTA.
- Fixes an issue where the call notification disappears upon clicking the back button on certain devices.

# March 06

## [Web 1.13.3](https://github.com/CleverTap/clevertap-web-sdk/releases/tag/v1.13.3)

### What's New

- Introduces priority support for Web Native Display campaigns, allowing better control over message selection and delivery.  

### Bug Fixes

- Combines multiple Web Native Display events into a single event with different `campaignSource` values. 

### Important API Changes

- Changes in the structure of `CustomEvents` payloads and `listener keys`, requiring modifications in user implementations.

# March 05

## [Web 1.13.2](https://github.com/CleverTap/clevertap-web-sdk/releases/tag/v1.13.2)

### What's New

- **VAPID Migration and APNS Support**
  - Supports Apple Push Notification Service (APNS) in the new soft prompt. 
  - Sends prompt configurations on every page refresh.  

### Bug Fixes

- Fixes race conditions when `notifications.push` is called before web push configuration is available.  
- Improves error handling for notification subscriptions.  
- Ensures proper prompt closure when users grant permissions via the bell icon.  
- Enhances prompt rendering logic to handle missing configurations or initialization delays.  
- **Improved Web Push Handling**
  - Enhances web push notification handling with improved configuration management.
  - Introduces structured methods for setting up and processing soft prompts.

### Important API Changes

This update improves stability, simplifies API usage, and enhances push notification reliability.

- **Deprecated `notifications.enable` API**
  - `notifications.push` API now handles both old and new soft prompts, including the bell icon rendering.  
- **Updated `notifications.push` API**
  - Manages the entire web push prompt flow.  
  - Ensures correct rendering based on the received web push configuration.  
  - Handles race conditions when the SDK is not yet initialized, or the application server key is unavailable.
- **Refactored Notification Handler Methods**
  - Adds `setupWebPush`, `processSoftPrompt`, `parseDisplayArgs`, and `setNotificationHandlerValues` for better modularity.  
  - Updates `processWebPushConfig`, `enable`, and `push` methods to improve prompt logic.
  - Improves notification subscription flow and error handling.

# March 03

## [Flutter 3.2.0](https://github.com/CleverTap/clevertap-flutter/releases/tag/3.2.0)

> ❗️ Upgrade Alert
> 
> We recommend upgrading to [CleverTap Flutter 3.3.0](doc:march-2025#flutter-330) or above if using In-App.

### What's New

This release brings Android 15 support, enhanced encryption, and updated SDK compatibility for a more secure and optimized experience.

> ⚠️ Downgrade Advisory
> 
> After upgrading to Flutter 3.2.0, avoid downgrading in subsequent app releases. If you face any issue after upgrading to this version, contact the [CleverTap Support](https://help.clevertap.com/hc/en-us/requests/new) team for assistance.

#### Android

- Supports [CleverTap Android SDK v7.2.2](https://github.com/CleverTap/clevertap-android-sdk/blob/master/docs/CTCORECHANGELOG.md#version-722-january-21-2025).
- Supports Android 15. For more information, refer to [Android 15](https://developer.android.com/about/versions/15/summary).
- Updates the minimum supported Android SDK version to API level 21 (Android 5.0).
- Enhances the [encryption algorithm for PII data](https://github.com/CleverTap/clevertap-android-sdk/blob/master/docs/EXAMPLES.md#encryption-of-pii-data-), aligning it with [OWASP guidelines](https://mas.owasp.org/MASTG/0x04g-Testing-Cryptography/). The encryption key is securely backed up using [Android Key Store](https://developer.android.com/privacy-and-security/keystore). This encryption is supported for API level 23 (Android 6.0 and above).
- Upgrades Android Gradle Plugin (A.G.P) to 8.6.1 as [recommended for Android 15](https://developer.android.com/about/versions/15/setup-sdk#:~:text=Update%20your%20app's%20build%20configuration,-Warning%3A%20If%20your&text=1%20or%20higher%2C%20first%20run,1.).

## [Flutter 3.1.0](https://github.com/CleverTap/clevertap-flutter/releases/tag/3.1.0)

### What's New

This release introduces key improvements to Android and iOS, including enhanced event tracking and In-App campaign triggers.

#### Android

- Supports [CleverTap Android SDK v7.1.2](https://github.com/CleverTap/clevertap-android-sdk/blob/master/docs/CTCORECHANGELOG.md#version-712-january-29-2025).
- Supports Flutter 3.29 by removing deprecated Embedding v1. If your project uses Embedding v1, update it using the [migration guide](https://github.com/flutter/flutter/blob/main/docs/platforms/android/Upgrading-pre-1.12-Android-projects.md).
- Supports hiding the large icon in Android notifications using the `wzrk_hide_large_icon` key in the payload.

#### iOS

- Supports [CleverTap iOS SDK v7.1.0](https://github.com/CleverTap/clevertap-ios-sdk/blob/master/CHANGELOG.md#version-710-january-21-2024).

#### Android and iOS

- Supports triggering In-App campaigns based on a combination of recurring and first-time events. For example, trigger a campaign every time the _Charged_ event occurs or the _App Launched_ event occurs for the first time.
- Supports user-level event log tracking system with the help of the following new APIs:
  - `getUserEventLog()`: Retrieves specific event details.
  - `getUserEventLogCount()`: Retrieves the count of times an event occurred.
  - `getUserLastVisitTs()`: Retrieves the timestamp of a user's most recent app visit.
  - `getUserAppLaunchCount()`: Retrieves the total number of times a user launched the app.
  - `getUserEventLogHistory()`: Retrieves the complete event history for the current user.

### Important API Changes

The following event tracking APIs previously logged events at the device level, making user-specific tracking inaccurate, especially in multi-user scenarios. They are now deprecated in favor of new user-level APIs and will be removed in future versions with prior notice.

- `eventGetDetail()`: Use `getUserEventLog()`instead.
- `eventGetFirstTime()`: Use `getUserEventLog()` instead.
- `eventGetLastTime()`: Use `getUserEventLog()` instead.
- `eventGetOccurrences()`: Use `getUserEventLogCount()` instead.
- `sessionGetPreviousVisitTime()`: Use `getUserLastVisitTs()` instead.
- `sessionGetTotalVisits()`: Use `getUserAppLaunchCount()` instead.
- `getEventHistory()`: Use `getUserEventLogHistory()` instead.
