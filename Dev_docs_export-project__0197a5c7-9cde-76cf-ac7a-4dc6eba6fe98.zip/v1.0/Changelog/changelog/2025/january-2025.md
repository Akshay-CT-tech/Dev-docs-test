---
title: "January 2025"
slug: "january-2025"
excerpt: ""
hidden: false
createdAt: "Tue Jan 07 2025 06:17:12 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 28 2025 12:11:17 GMT+0000 (Coordinated Universal Time)"
---
We are excited to share the January SDK changelog for our product!

> 📘 Note
> 
> Click each SDK header to view the corresponding GitHub repository for release details.

# January 31

## [Unity 5.0.0](https://github.com/CleverTap/clevertap-unity-sdk/blob/master/CHANGELOG.md#version-500-31-january-2025)

### Enhancements

- Improved integration and SDK initialization for Android and iOS.

#### Android

- Supports CleverTap [Android SDK v7.1.2](https://github.com/CleverTap/clevertap-android-sdk/releases/tag/corev7.1.2).
- Adds missing bindings for Android `GetUnreadInboxMessages` and `GetInboxMessageForId`.

#### iOS

- Supports CleverTap [iOS SDK v7.1.0](https://github.com/CleverTap/clevertap-ios-sdk/releases/tag/7.1.0).
- Adds `OnCleverTapPushNotificationPermissionStatusCallback` callback for iOS.
- Implements `CleverTapInAppNotificationShowCallback` callback on iOS.

#### Android and iOS

- Supports triggering In-App campaigns based on a combination of recurring and first-time events. For example, trigger a campaign every time the _App Launched_ event occurs or the _Charged_ event occurs for the first time.
- Supports [Custom Code Templates](https://developer.clevertap.com/docs/unity-custom-code-in-app-templates).
- Adds `CleverTapInboxMessage` model and new methods: `GetAllInboxMessagesParsed`, `GetUnreadInboxMessagesParsed`, and `GetInboxMessageForIdParsed`.
- Adds UserEventLog methods: `GetUserEventLog`, `GetUserEventLogCount`, `GetUserAppLaunchCount`, `GetUserEventLogHistory`, and `GetUserLastVisitTs`.
- Deprecates the following methods: `EventGetDetail`, `EventGetFirstTime`, `EventGetLastTime`, `EventGetOccurrences`, `UserGetEventHistory`, `UserGetPreviousVisitTime`, and `UserGetTotalVisits`.
- Deprecates Product Config and Feature Flags methods.

### Bug Fixes

- Fixes iOS Push Permission Response Received message.

# January 28

## [Web 1.12.0](https://github.com/CleverTap/clevertap-web-sdk/releases/tag/v1.12.0)

### What's New

- **Safari Web Push Support**
  - Supports Web Push notifications on Safari browsers using Voluntary Application Server Identification (VAPID). 
  - Enables Web Push on Safari iOS Browsers.

### Enhancements

- Replaces hard-coded browser version checks with API-based logic for Web Push, ensuring compatibility across all browsers.
- Adds a sticky header to Web Inbox for improved navigation, making it easier to close the inbox while scrolling through message content.

### Bug Fixes

- Fixes an issue in the Web Inbox where unread message counts were inaccurate for mobile users, ensuring only opened messages are marked as read.
- Resolves Web Inbox badge update issues in Single Page Applications (SPAs) by implementing a timeout-based mechanism to handle route changes more reliably, including native browser navigation.

# January 21

## [iOS 7.1.0](https://github.com/CleverTap/clevertap-ios-sdk/releases/tag/7.1.0)

### What's New

- Supports triggering In-App campaigns based on a combination of recurring and first-time events. For example, trigger a campaign every time the _App Launched_ event occurs or the _Charged_ event occurs for the first time.
- Supports user-level event log tracking system with the help of the following new APIs:
  - `getUserEventLog()`: Retrieves specific event details.
  - `getUserEventLogCount()`: Retrieves the count of times an event occurred.
  - `getUserLastVisitTs()`: Retrieves the timestamp of the most recent app visit by a user.
  - `getUserAppLaunchCount()`: Retrieves the total number of times a user launched the app.
  - `getUserEventLogHistory()`: Retrieves the complete event history for the current user.
- Adds `inAppNotificationDidShow` to the `CleverTapInAppNotificationDelegate`.

### Important API Changes

The following event tracking APIs previously tracked events at the device level, which made it difficult to maintain accurate user-specific event logs, especially in multi-user scenarios. These APIs have now been deprecated in favor of new user-specific APIs. The deprecated methods will be removed in future versions with a prior notice:

- `eventGetDetail()`: Use `getUserEventLog()`instead.
- `eventGetFirstTime()`: Use `getUserEventLog()` instead.
- `eventGetLastTime()`: Use `getUserEventLog()` instead.
- `eventGetOccurrences()`: Use `getUserEventLogCount()` instead.
- `userGetPreviousVisitTime()`: Use `getUserLastVisitTs()` instead.
- `userGetTotalVisits()`: Use `getUserAppLaunchCount()` instead.
- `userGetEventHistory()`: Use `getUserEventLogHistory()` instead.

## [Android 7.2.2](https://github.com/CleverTap/clevertap-android-sdk/releases/tag/corev7.2.2)

> ❗️ Upgrade Alert
> 
> We recommend upgrading to [CleverTap Android SDK 7.3.1](doc:march-2025#android-731) or above if using In-App.

> 📘 Hotfix Release
> 
> This hotfix release fixes the critical issue in CleverTap Android SDK [7.1.0](doc:december-2024#android-710), [7.2.0](doc:january-2025#android-720), and [7.2.1](doc:january-2025#january-16).

### Bug Fixes

- Fixes an issue that prevents the `Notification Clicked` event from being raised.

# January 16

## [Android 7.2.1](https://github.com/CleverTap/clevertap-android-sdk/releases/tag/corev7.2.1)

> ❗️ Upgrade Alert
> 
> We strongly recommend upgrading to the [CleverTap Android SDK 7.2.2](doc:january-2025#january-21) version because it contains fixes for critical issues in 7.1.0, 7.2.0, and 7.2.1 versions.

### Bug Fixes

- Fixes the `ClassCastException` error that occurs during server-side In-App delivery.

# January 14

## [Web 1.11.15](https://github.com/CleverTap/clevertap-web-sdk/releases/tag/v1.11.15)

### Bug Fixes

- **Improves click tracking for Web Push Notifications**: Separates event tracking from the redirection URL, ensuring silent event logging without affecting the user’s redirection flow.
- **Resolves Web Inbox initialization failure**: Adds a retry mechanism to check for the Inbox element and initializes it when available.

# January 7

## [Signed Call React Native SDK 0.7.6](https://www.npmjs.com/package/@clevertap/clevertap-signed-call-react-native)

### What's New

#### Android

- Supports [Signed Call Android SDK v0.0.7.6](https://repo1.maven.org/maven2/com/clevertap/android/clevertap-signedcall-sdk/0.0.7.6/), compatible with [CleverTap Android SDK 6.2.1](https://github.com/CleverTap/clevertap-android-sdk/blob/master/docs/CTCORECHANGELOG.md#version-620-april-3-2024).
- **CallStyle Notifications on Android 12 and Above**:
  - Replaces regular call notifications with CallStyle notifications for incoming, outgoing, and ongoing calls. These notifications are given top priority in the notification tray. The update adheres to the Android's non-dismissible notifications standards, as listed under [Android 14 Behavior Changes](https://developer.android.com/about/versions/14/behavior-changes-all#non-dismissable-notifications). 
- **Call Quality Control Enhancements**
  - Introduces network quality checks at both the initiator and receiver ends to provide optimal call quality.
    - Initiator SIde: Network latency checks before call processing. Returns a `5004` error code within the `SignedCallResponse` promise object if latency exceeds the benchmark.
    - Receiver Side: Network quality checks before showing the incoming call screen. A quality score (ranging from -1 to 100) is provided via the `onNetworkQualityResponse(int score)` callback. This allows the app to decide whether to proceed with or decline the call. For more information, refer to [Receiver Side](doc:signed-call-react-native-sdk#receiver-side).
  - New parameters in `initProperties` object for initialization:
    - `fcmProcessingMode` and `fcmProcessingNotification`: The SDK supports the following two modes for processing FCM calls: `FcmProcessingMode.foreground` and `FcmProcessingMode.background`. These modes control how the SDK handles incoming calls, whether in the background or foreground service, depending on whether the app is actively running or is running in the background. The `FcmProcessingMode.background` is the default mode. for more details on overriding the default mode, refer to [Configure FCM Processing Mode](doc:signed-call-react-native-sdk#configure-fcm-processing-mode).
    - `callScreenOnSignalling`: A Boolean property to control when the outgoing call screen appears relative to the signaling process. By default, the SDK immediately displays the outgoing call screen upon a call request and performs the validations in the background. For more information, refer to [Control Call Screen Display Timing](doc:signed-call-react-native-sdk#control-call-screen-display-timing).
  - New Call Events in `SignedCall.SignedCallOnCallStatusChanged` handler:
    - `CallEvent.AppInitiatedDeclinedDueToNetworkQuality`: Enables identification of cases where the app declines a call based on the network quality score provided through the `onNetworkQualityResponse(int score)` callback.
    - `CallEvent.EndedDueToLocalNetworkLoss`: Enables identification of call disconnection caused by network loss on the initiator end.
    - `CallEvent.EndedDueToRemoteNetworkLoss`: Enables detection of call disconnections caused by network loss on the receiver end.  
      <br />
      > 📘 Note
      > 
      > The `CallEvent.EndedDueToLocalNetworkLoss` and `CallEvent.EndedDueToRemoteNetworkLoss` events are reported alongside the existing `CallEvent.Ended` event to maintain backward compatibility.  
      > <br />
  #### iOS
  - Supports [Signed Call iOS SDK v0.0.9](https://github.com/CleverTap/clevertap-signedcall-ios-sdk/blob/main/CHANGELOG.md#version-009-november-19-2024), compatible with[ CleverTap iOS SDK v7.0.2](https://github.com/CleverTap/clevertap-ios-sdk/blob/master/CHANGELOG.md#version-702-october-10-2024) and higher.

#### Android and iOS

- **Remote Context Configuration for Call Screen**:  
  Adds support for setting a `remoteContext` parameter within `callProperties` object during call initiation, enabling custom context for the receiver's call screen.

### Enhancements

#### Android

- Reduces delay in heads-up behavior for call notifications when exiting the call screen.
- Adds a fallback to the regular notifications template for the call notifications when using the CallStyle template in case the full-screen intent permission is not granted.
- Prevents call notification popups when the SDK requests microphone permissions after call acceptance.
- Local branding configured during SDK initialization is now interoperable with the remote branding configured via the CleverTap dashboard, allowing overriding of the specific branding properties without requiring all properties to be set at once.

### Bug Fixes

#### iOS

- Fixes `sa_family_t` declaration issue for Xcode 16 compatibility.
- Resolves `EXC_BAD_ACCESS` error that occurs when clicking the mute button on the CallKit screen (observed only in debugging mode).
- Fixes synchronization issues for Mute and Speaker controllers between CallKit and native screens.

### Behavior Changes

#### Android

- **Optimizes Outgoing Call Screen Launch**
  - Launches immediately without waiting for signaling confirmation. 
  - Introduces a countdown `ProgressBar` around the cancel button until signaling is completed. 
  - Customizable `cancelCountdownColor`parameter within the `overrideDefaultBranding`. The default color is yellow (#F5FA55). For more information, refer to [`overrideDefaultBranding` (All Platforms)](doc:signed-call-react-native-sdk#overridedefaultbranding-all-platforms).

## [Android 7.2.0](https://github.com/CleverTap/clevertap-android-sdk/releases/tag/corev7.2.0_ptv1.3.0_hmsv1.4.0_geofencev1.4.0)

> ❗️ Upgrade Alert
> 
> We strongly recommend upgrading to the [CleverTap Android SDK 7.2.2](doc:january-2025#january-21) version because it contains fixes for critical issues in 7.1.0, 7.2.0, and 7.2.1 versions.

### What's New

- Supports Android 15. For more information, refer to [Android 15](https://developer.android.com/about/versions/15/summary).
- Updates the minimum supported Android SDK version to API level 21 (Android 5.0).
- Enhances the [encryption algorithm for PII data](https://github.com/CleverTap/clevertap-android-sdk/blob/master/docs/EXAMPLES.md#encryption-of-pii-data-), aligning it with [OWASP guidelines](https://mas.owasp.org/MASTG/0x04g-Testing-Cryptography/). The encryption key is securely backed up using [Android Key Store](https://developer.android.com/privacy-and-security/keystore). This encryption is supported for API level 23 (Android 6.0 and above).

> 🚧 Downgrade Advisory
> 
> After upgrading to Android SDK v7.2.0, avoid downgrading in subsequent app releases. If you face any issue after upgrading to this version, contact the [CleverTap Support](https://help.clevertap.com/hc/en-us/requests/new) team for assistance.

## [Android Push Templates 1.3.0](https://github.com/CleverTap/clevertap-android-sdk/releases/tag/corev7.2.0_ptv1.3.0_hmsv1.4.0_geofencev1.4.0)

### What's New

- Supports Android 15. For more information, refer to [Android 15](https://developer.android.com/about/versions/15/summary).
- Updates the minimum supported Android SDK version to API level 21 (Android 5.0).

## [Android Geofence 1.4.0](https://github.com/CleverTap/clevertap-android-sdk/releases/tag/corev7.2.0_ptv1.3.0_hmsv1.4.0_geofencev1.4.0)

### What's New

- Supports Android 15. For more information, refer to [Android 15](https://developer.android.com/about/versions/15/summary).
- Updates the minimum supported Android SDK version to API level 21 (Android 5.0).

## [Android Huawei Push 1.4.0](https://github.com/CleverTap/clevertap-android-sdk/releases/tag/corev7.2.0_ptv1.3.0_hmsv1.4.0_geofencev1.4.0)

### What's New

- Supports Android 15. For more information, refer to [Android 15](https://developer.android.com/about/versions/15/summary).
- Updates the minimum supported Android SDK version to API level 21 (Android 5.0).

# January 2

## [Signed Call Android 0.0.7.6](https://repo1.maven.org/maven2/com/clevertap/android/clevertap-signedcall-sdk/0.0.7.6/)

### What's New

- **Enhanced Call Disconnection Details**
  - The `callStatus(SCCallStatusDetails callDetails)` callback now provides detailed reasons for call disconnection through the following new events:
    - `VoIPCallStatus.CALL_OVER_DUE_TO_LOCAL_NETWORK_LOSS`: Triggered when the call disconnects due to network loss at the initiator's end.
    - `VoIPCallStatus.CALL_OVER_DUE_TO_REMOTE_NETWORK_LOSS`: Triggered when the call disconnects due to network loss at the receiver's end.  
        <br />
      > 📘 Note
      > 
      > The above events are reported alongside the existing `VoIPCallStatus.CALL_OVER` event for seamless integration with older implementation.
- **Customized Branding**
  - Local and remote branding settings are now interoperable. Use the `SignedCallScreenBranding.builder` class to customize specific branding properties locally while leveraging remote branding settings configured on the CleverTap dashboard. For more information on setting the local branding, refer to [Set Local Branding for Call Screen](doc:signed-call-android-sdk#set-local-branding-for-call-screen).

### Enhancements

- **SCEnd System Event Updates**
  - Adds a new boolean property `hangup_initiator` to indicate which party initiated the hangup.
  - Captures the cause of disconnection for `over` call-status events through the reason property, with the following possible values:
    - `network_lost`: Indicates that the hangup occurred due to the network loss on the call initiator's end (corresponds to `VoIPCallStatus.CALL_OVER_DUE_TO_LOCAL_NETWORK_LOSS`).
    - `network_dropped`: Indicates that the hangup occurred due to the network loss on the receiver's end (corresponds to `VoIPCallStatus.CALL_OVER_DUE_TO_REMOTE_NETWORK_LOSS`).
    - `user_initiated`: Indicates that the hangup was initiated by the user (corresponds to `VoIPCallStatus.CALL_OVER`).

### Bug Fixes

- Resolves an issue where the `channel` property in SCEnd system events was incorrectly recorded as `socket` at the initiator end instead of `fcm`.
