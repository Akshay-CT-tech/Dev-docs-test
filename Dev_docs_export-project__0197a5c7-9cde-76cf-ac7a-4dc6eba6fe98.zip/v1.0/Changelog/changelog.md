---
title: "Changelog"
slug: "changelog"
excerpt: ""
hidden: false
createdAt: "Thu Feb 02 2023 07:20:40 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jan 07 2025 10:05:35 GMT+0000 (Coordinated Universal Time)"
---
Welcome to CleverTap's Developer Changelog! 

Here, you can find information about the most recent changes that have been made to our SDKs, including bug fixes, new features, and other improvements.

## [2025](doc:2025)

## [2024](doc:2024)

## [2023](doc:2024)

## [2022 and Earlier](doc:changelog-2022-and-earlier)

> 👍 Product Releases
> 
> For product and user interface (UI) release details, refer to our [What's New](https://docs.clevertap.com/docs/whats-new) page.

[block:html]
{
  "html": "<style>\n  .rm-Guides .content-body, .rm-Guides #content-head .col-xs-9 {\n      max-width: 100%;\n      width: 1000px;\n  }\n  .markdown-body summary {\n  font-size: 20px;\n  font-weight: bold; \n  text-transform: camelcase;\n}\n</style>"
}
[/block]
